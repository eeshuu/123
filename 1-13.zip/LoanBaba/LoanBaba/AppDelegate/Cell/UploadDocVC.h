//
//  UploadDocVC.h
//  LoanBaba
//
//  Created by Nilesh Pal on 04/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UploadDocVC : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

- (IBAction)action_Upload:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIImageView *imgPan;
@property (weak, nonatomic) IBOutlet UIImageView *imgIncome;
@property (weak, nonatomic) IBOutlet UIImageView *imgSalary;
@property (strong, nonatomic) NSString *strApplicationId;
@property (nonatomic) BOOL isSlide;

@end
