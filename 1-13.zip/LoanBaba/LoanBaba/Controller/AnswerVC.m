//
//  AnswerVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 29/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "AnswerVC.h"
#import "AppDelegate.h"
#import "QuestionVC.h"
#import "CellType1.h"
#import "CellType2.h"
#import "CellType3.h"
#import "CellType4.h"
#import "CellType5.h"
#import "BankListVc.h"
@interface AnswerVC ()
{
    AppDelegate *appDelegate;
    NSMutableArray *arrayQuestion,*arrayAnswer;
}
@property (weak, nonatomic) IBOutlet UITableView *tblAnswer;
@property (weak, nonatomic) IBOutlet UIButton *btnContinue;
@end

@implementation AnswerVC

- (void)viewDidLoad {
    self.title=@"Review";
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    arrayQuestion=[[NSMutableArray alloc]initWithArray:appDelegate.arrayQuestion];
    arrayAnswer=[[NSMutableArray alloc]initWithArray:appDelegate.arrayAnswer];
    [_tblAnswer setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    _btnContinue.layer.cornerRadius=_btnContinue.frame.size.height/2;
    
    _btnContinue.layer.borderWidth=1.0;
    
    _btnContinue.layer.borderColor=[[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1] CGColor];
    
    
    NSLog(@"Ques %@",arrayQuestion);
    NSLog(@"Asn %@",arrayAnswer);
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return appDelegate.arrayQuestion.count;
   
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    NSMutableDictionary *dictCurrentQuestion=[[NSMutableDictionary alloc]initWithDictionary:[appDelegate.arrayQuestion objectAtIndex:indexPath.row]];
    int typeInt=[[dictCurrentQuestion  objectForKey:@"TypeId"] intValue];
    
    CellType1 *type1Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType1"];
    
    if (typeInt == 2 || typeInt == 3 || typeInt == 4 || typeInt == 5) {
        CGSize possibleSize = [dictCurrentQuestion[@"Title"] sizeWithFont:[UIFont fontWithName:FONT_REGULAR size:19] //font you are using
                                                        constrainedToSize:CGSizeMake(type1Cell.lblQuestionType1.frame.size.width-20,9999)
                                                            lineBreakMode:NSLineBreakByWordWrapping];
        
        return possibleSize.height+80;
    }else{
        return 100;
    }
    
//    switch (typeInt) {
//        case 1:
//        {
//            CellType1 *type1Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType1"];
//            CGSize possibleSize = [dictCurrentQuestion[@"Title"] sizeWithFont:[type1Cell.lblQuestionType1 font] //font you are using
//                                                                             constrainedToSize:CGSizeMake(type1Cell.lblQuestionType1.frame.size.width,9999)
//                                                                                 lineBreakMode:NSLineBreakByWordWrapping];
//            
//            
//            if (possibleSize.height+23 >90) {
//                return possibleSize.height+60;
//            }
//            else{
//                return 100;
//            }
//
//        }
//            break;
//        case 2:
//        {
//            CellType2 *type2Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType2"];
//            CGSize possibleSize = [dictCurrentQuestion[@"Title"] sizeWithFont:[type2Cell.lblQuestionType2 font] //font you are using
//                                                                     constrainedToSize:CGSizeMake(type2Cell.lblQuestionType2.frame.size.width,9999)
//                                                                         lineBreakMode:NSLineBreakByWordWrapping];
//            
//            
//            if (possibleSize.height+23 >90) {
//                return possibleSize.height+60;
//            }
//            else{
//                return 100;
//            }
//        }
//            break;
//        case 3:
//        {
//            CellType3 *type3Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType3"];
//            CGSize possibleSize = [dictCurrentQuestion[@"Title"] sizeWithFont:[type3Cell.lblQuestionType3 font] //font you are using
//                                                                     constrainedToSize:CGSizeMake(type3Cell.lblQuestionType3.frame.size.width,9999)
//                                                                         lineBreakMode:NSLineBreakByWordWrapping];
//            
//            
//            if (possibleSize.height+23 >90) {
//                return possibleSize.height+60;
//            }
//            else{
//                return 100;
//            }
//
//        }
//            break;
//        case 4:
//        {
//            CellType4 *type4Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType4"];
//            CGSize possibleSize = [dictCurrentQuestion[@"Title"] sizeWithFont:[type4Cell.lblQuestionType4 font] //font you are using
//                                                                     constrainedToSize:CGSizeMake(type4Cell.lblQuestionType4.frame.size.width,9999)
//                                                                         lineBreakMode:NSLineBreakByWordWrapping];
//            
//            
//            if (possibleSize.height+23 >90) {
//                return possibleSize.height+40;
//            }
//            else{
//                return 100;
//            }
//            
//        }
//            break;
//        case 5:
//        {
//            CellType5 *type5Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType5"];
//            CGSize possibleSize = [dictCurrentQuestion[@"Title"] sizeWithFont:[type5Cell.lblQuestionType5 font] //font you are using
//                                                                     constrainedToSize:CGSizeMake(type5Cell.lblQuestionType5.frame.size.width,9999)
//                                                                         lineBreakMode:NSLineBreakByWordWrapping];
//            
//            
//            if (possibleSize.height+23 >90) {
//                return possibleSize.height+60;
//            }
//            else{
//                return 100;
//            }
//
//        }
//            break;
//            
//        default:
//            break;
//    }
//    
//    
//    return 90;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSMutableDictionary *dictCurrentQuestion=[[NSMutableDictionary alloc]initWithDictionary:[appDelegate.arrayQuestion objectAtIndex:indexPath.row]];
    int typeInt=[[dictCurrentQuestion  objectForKey:@"TypeId"] intValue];
    
    QuestionVC *vc=(QuestionVC *)[appDelegate.arrayAnswer objectAtIndex:indexPath.row];
    
    NSDictionary *answer=[appDelegate.arrayFinalAnswer objectAtIndex:indexPath.row];
    
    switch (typeInt) {
        case 1:
        {
            CellType1 *type1Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType1"];
            [type1Cell.lblQuestionType1 setText:[answer objectForKey:@"question"]];
            [type1Cell.lblRadioButtonTitle setText:[answer objectForKey:@"answer"]];
            [type1Cell setupIU];
            [type1Cell setBackgroundColor:[UIColor clearColor]];
            return type1Cell;
        }
            break;
        case 2:
        {
            CellType2 *type2Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType2"];
            [type2Cell.TxtQuestionType2 setText:[answer objectForKey:@"answer"]];
            [type2Cell.lblQuestionType2 setText:[answer objectForKey:@"question"]];
            [type2Cell setupIU];
            [type2Cell setBackgroundColor:[UIColor clearColor]];
            return type2Cell;
        }
            break;
        case 3:
        {
            CellType3 *type3Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType3"];
            [type3Cell.TxtQuestionType3 setText:[answer objectForKey:@"answer"]];
            [type3Cell.lblQuestionType3 setText:[answer objectForKey:@"question"]];
            [type3Cell setupIU];
            [type3Cell setBackgroundColor:[UIColor clearColor]];
            return type3Cell;
        }
            break;
        case 4:
        {
            CellType4 *type4Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType4"];
            [type4Cell.lblQuestionType4 setText:[answer objectForKey:@"question"]];
            [type4Cell.TxtQuestionType4 setText:[answer objectForKey:@"answer"]];
            [type4Cell setupIU];
            [type4Cell setBackgroundColor:[UIColor clearColor]];
            return type4Cell;
        }
            break;
        case 5:
        {
            CellType5 *type5Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType5"];
            [type5Cell.TxtQuestionType5 setText:[answer objectForKey:@"answer"]];
            [type5Cell.lblQuestionType5 setText:[answer objectForKey:@"question"]];
            [type5Cell setupIU];
            [type5Cell setBackgroundColor:[UIColor clearColor]];
            return type5Cell;
        }
            break;
            
        default:
            break;
    }
    

    
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}
- (IBAction)btnActionContinue:(id)sender {
    
    if ([SharedInstance isNetworkConnected])
    {
        
        [self callPostQuestionAnswerService:appDelegate.strCatId];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    
    
    
}

- (void)callPostQuestionAnswerService:(NSString *)catId {
    
    NSMutableArray *tempArr= [NSMutableArray new];
    for (int i = 0; i<appDelegate.arrayFinalAnswer.count; i++) {
        NSDictionary *tempDict = @{@"strQuestionId": appDelegate.arrayFinalAnswer[i][@"question_id"],@"strAnswer":appDelegate.arrayFinalAnswer[i][@"answer"]};
        [tempArr addObject:tempDict];
    }
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:tempArr options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostQuestionAnswer>\n"
                             "<tem:strCategoryId>%@</tem:strCategoryId>\n"
                             "<tem:objQuestionAnswer>%@</tem:objQuestionAnswer>\n"
                             "</tem:PostQuestionAnswer>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",catId,jsonString];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostQuestionAnswer_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostQuestionAnswerResponse"] objectForKey:@"PostQuestionAnswerResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            appDelegate.strCatId = @"";
          
            BankListVc *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"BankListVc"];
            vc.strRequestId = arr[0][@"ReqId"];
            [self.navigationController pushViewController:vc animated:YES];

        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
