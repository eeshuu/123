//
//  BankDetail.h
//  iFishPocket
//
//  Created by cis on 10/3/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BankDetail : UIViewController
@property(nonatomic,retain)NSMutableDictionary *dictBankData;


@property (nonatomic,strong)NSDictionary *dict;
@property (nonatomic,strong)NSString *strRequestId;


@end
