//
//  LoanInfoVC.m
//  iFishPocket
//
//  Created by cis on 10/3/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import "BankListVc.h"
#import "CellBankList.h"
#import "BankDetail.h"
@interface BankListVc ()
{
    NSMutableArray *arrayBankList;
}
@property (strong, nonatomic) IBOutlet UIButton *btnMenu;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *heightConstrainTopView;
@property (strong, nonatomic) IBOutlet UIImageView *imgMenuIcon;
@property (strong, nonatomic) IBOutlet UILabel *lblLoanAmount;
@property (strong, nonatomic) IBOutlet UILabel *lblTenure;
@property (strong, nonatomic) IBOutlet UITextField *txtLoanAmount;
@property (strong, nonatomic) IBOutlet UITextField *txtTenure;
@property (strong, nonatomic) IBOutlet UISlider *sliderLoadAmount;
@property (strong, nonatomic) IBOutlet UISlider *sliderTenure;
@property (strong, nonatomic) IBOutlet UITableView *tblBankList;

@end

@implementation BankListVc
@synthesize strRequestId;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    arrayBankList=[[NSMutableArray alloc]initWithObjects:@{@"Title":@"Temp 1"},@{@"Title":@"Temp 1"},@{@"Title":@"Temp 1"},@{@"Title":@"Temp 1"},@{@"Title":@"Temp 1"}, nil];
    _tblBankList.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    [_txtLoanAmount.layer setBorderWidth:1.0f];
    [_txtTenure.layer setBorderWidth:1.0f];
    [_txtLoanAmount.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_txtTenure.layer setBorderColor:[[UIColor grayColor] CGColor]];

    arrayBankList=[[NSMutableArray alloc] init];
    
    if ([SharedInstance isNetworkConnected])
    {
        [self callGetSliderValuesService:self.strRequestId];
        
        [self callGetListOfBankWithDetailsService:self.strRequestId];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Collection View DataSource & Delegate
#pragma mark - UITableView DataSource & Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayBankList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentiFire = @"CellBankList";
    CellBankList *cell = (CellBankList *)[tableView dequeueReusableCellWithIdentifier:cellIdentiFire forIndexPath:indexPath];
    NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithDictionary:[arrayBankList objectAtIndex:indexPath.row]];
    [cell setData:dict];
    return cell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    BankDetail *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"BankDetail"];
    vc.dict = arrayBankList[indexPath.row];
    vc.strRequestId = self.strRequestId;
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
#pragma mark -Action
- (IBAction)btnMenu:(UIButton *)sender {
    if ([sender isSelected]) {
        [sender setSelected:NO];
        [_heightConstrainTopView setConstant:150];
        
        [_imgMenuIcon setImage:[UIImage imageNamed:@"upIcon.png"]];
    }
    else{
        [sender setSelected:YES];
        [_heightConstrainTopView setConstant:30];
        [_imgMenuIcon setImage:[UIImage imageNamed:@"downIcon.png"]];
    }
    
}
- (IBAction)sliderLoanAmountChange:(id)sender {
     _txtLoanAmount.text =[NSString stringWithFormat:@"%.0f", _sliderLoadAmount.value];
}
- (IBAction)sliderTenureChange:(id)sender {
    [_sliderTenure setValue:((int)((_sliderTenure.value + 0.5) /1) * 1) animated:NO];
    _txtTenure.text =[NSString stringWithFormat:@"%.0f", _sliderTenure.value];
}


- (IBAction)sliderEndOnExit:(id)sender {
    
    if ([SharedInstance isNetworkConnected])
    {
        [self callGetListOfBankWithDetailsAmtService:self.strRequestId andLoanAmount:[NSString stringWithFormat:@"%.0f", _sliderLoadAmount.value] andTenure:[NSString stringWithFormat:@"%.0f", _sliderTenure.value]];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}




- (void)callGetListOfBankWithDetailsService:(NSString *)requestId {

    
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetListOfBankWithDetails>\n"
                             "<tem:strQuotRequestId>%@</tem:strQuotRequestId>\n"
                             "</tem:GetListOfBankWithDetails>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",requestId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetListOfBankWithDetails_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetListOfBankWithDetailsResponse"] objectForKey:@"GetListOfBankWithDetailsResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            

            NSLog(@"Data bank detail %@",arr);
            
            
            arrayBankList = [NSMutableArray arrayWithArray:arr];
            [_tblBankList reloadData];

        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}


- (void)callGetSliderValuesService:(NSString *)requestId {
    
    
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetSliderValues>\n"
                             "<tem:strQuotRequestId>%@</tem:strQuotRequestId>\n"
                             "</tem:GetSliderValues>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",requestId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetSliderValues_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetSliderValuesResponse"] objectForKey:@"GetSliderValuesResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data slider %@",arr);
            
            if (arr.count>0) {
                _txtLoanAmount.text = arr[0][@"strAmount"];
                _txtTenure.text = arr[0][@"strTenuer"];
                _sliderLoadAmount.maximumValue = [arr[0][@"strAmountMax"] floatValue];
                _sliderLoadAmount.minimumValue = [arr[0][@"strAmountMin"] floatValue];
                _sliderLoadAmount.value = [arr[0][@"strAmount"]floatValue];
                _sliderTenure.maximumValue = [arr[0][@"strTenuerMax"] floatValue];
                _sliderTenure.minimumValue = [arr[0][@"strTenuerMin"] floatValue];
                _sliderTenure.value = [arr[0][@"strTenuer"]floatValue];
            }
            
//            arrayBankList = [NSMutableArray arrayWithArray:arr];
//            [_tblBankList reloadData];
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}


- (void)callGetListOfBankWithDetailsAmtService:(NSString *)requestId andLoanAmount:(NSString *)strloan andTenure:(NSString *)strTen{
    
    
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetListOfBankWithDetailsAmt>\n"
                             "<tem:strQuotRequestId>%@</tem:strQuotRequestId>\n"
                             "<tem:strLoanAmount>%@</tem:strLoanAmount>\n"
                             "<tem:strTenuer>%@</tem:strTenuer>\n"
                             "</tem:GetListOfBankWithDetailsAmt>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",requestId,strloan,strTen];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetListOfBankWithDetailsAmt_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetListOfBankWithDetailsAmtResponse"] objectForKey:@"GetListOfBankWithDetailsAmtResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data bank detail %@",arr);
            
            
            arrayBankList = [NSMutableArray arrayWithArray:arr];
            [_tblBankList reloadData];
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}
@end
