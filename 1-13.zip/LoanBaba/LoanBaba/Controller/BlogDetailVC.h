//
//  BlogDetailVC.h
//  workly
//
//  Created by Nilesh Pal on 01/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlogDetailVC : UIViewController


@property (strong, nonatomic) NSString *strBlogId;
@property (nonatomic, weak)IBOutlet UITextField *txtName;
@property (nonatomic, weak)IBOutlet UITextField *txtEmail;
@property (nonatomic, weak)IBOutlet UITextView *txtComments;
@property (weak, nonatomic) IBOutlet UILabel *lblDetail;
@property (weak, nonatomic) IBOutlet UIImageView *imgBlog;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
@property (weak, nonatomic) IBOutlet UITableView *tblComment;
@property (weak, nonatomic) IBOutlet UIScrollView *seg3ScrollView;



@end
