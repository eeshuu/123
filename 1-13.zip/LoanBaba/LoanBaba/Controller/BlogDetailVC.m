//
//  BlogDetailVC.m
//  workly
//
//  Created by Nilesh Pal on 01/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "BlogDetailVC.h"
#import "UIImageView+WebCache.h"
#import "CellComment.h"
@interface BlogDetailVC ()
{
    NSMutableArray *arrayComment;
}
@property (weak, nonatomic) IBOutlet UIScrollView *seg1ScrollView;
@property (weak, nonatomic) IBOutlet UIView *seg2CommentView;
@end

@implementation BlogDetailVC
@synthesize strBlogId;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    if ([SharedInstance isNetworkConnected])
    {
        [self callGetBlogDetails];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    
    // Do any additional setup after loading the view.
    
    arrayComment=[[NSMutableArray alloc]init];
    [_tblComment setTableFooterView:[[UIView alloc]initWithFrame:CGRectZero]];
    [_seg1ScrollView setHidden:NO];
    [_seg2CommentView setHidden:YES];
    [_seg3ScrollView setHidden:YES];
    
    self.txtComments.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtComments.layer.borderWidth=1.0f;
    self.txtName.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtName.layer.borderWidth=1.0f;
    self.txtEmail.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtEmail.layer.borderWidth=1.0f;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [_segment setWidth:_segment.frame.size.width/4 forSegmentAtIndex:0];
     [_segment setWidth:_segment.frame.size.width/4 forSegmentAtIndex:1];
     [_segment setWidth:_segment.frame.size.width/2 forSegmentAtIndex:2];
}
#pragma mark - UITextField delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayComment count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellComment *cell = [tableView dequeueReusableCellWithIdentifier:@"CellComment"];
    
    NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithDictionary:[arrayComment objectAtIndex:indexPath.row]];
    
    [cell setData:dict];
    
    [cell layoutIfNeeded];
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellComment *cell = [tableView dequeueReusableCellWithIdentifier:@"CellComment"];
    CGSize possibleSize = [arrayComment[indexPath.row][@"Comment"] sizeWithFont:[cell.lblComment font] //font you are using
                                                                     constrainedToSize:CGSizeMake(cell.lblComment.frame.size.width-20,9999)
                                                                         lineBreakMode:NSLineBreakByWordWrapping];
    
    
    if (possibleSize.height+23 >44) {
        return possibleSize.height+23;
    }
    else{
        return 69;
    }
    
    
}



#pragma mark-Action
- (void)callGetBlogDetails {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetBlogDetails>\n"
                             "<tem:strBlogId>%@</tem:strBlogId>\n"
                             "</tem:GetBlogDetails>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",self.strBlogId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetBlogDetails_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetBlogDetailsResponse"] objectForKey:@"GetBlogDetailsResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            /*get detail*/
            NSMutableDictionary *dictDetail=[arr objectAtIndex:0];
            
            if (dictDetail) {
                [_imgBlog sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://loanbaba.com/images/blog/%@",[dictDetail objectForKey:@"ImageFiles"]]] placeholderImage:[UIImage imageNamed:@"no_image.png"]];
                [_lblDetail setText:[dictDetail objectForKey:@"LongDescp"]];
                [_lblTitle setText:[dictDetail objectForKey:@"Title"]];
            }
            
            NSLog(@" Blog DEtails %@",arr);
            [self callGetBlogComments];
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

- (void)callGetBlogComments {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetBlogComments>\n"
                             "<tem:strBlogId>%@</tem:strBlogId>\n"
                             "</tem:GetBlogComments>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",self.strBlogId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetBlogComments_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetBlogCommentsResponse"] objectForKey:@"GetBlogCommentsResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            arrayComment=[[NSMutableArray alloc]initWithArray:arr];
            [_tblComment reloadData];
            
            NSLog(@" Blog comment %@",arr);
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}


- (void)callPostBlogComment {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostBlogComment>\n"
                             "<tem:strName>%@</tem:strName>\n"
                             "<tem:strEmail>%@</tem:strEmail>\n"
                             "<tem:strComment>%@</tem:strComment>\n"
                             "<tem:strBlogId>%@</tem:strBlogId>\n"
                             "</tem:PostBlogComment>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",_txtName.text,_txtEmail.text,_txtComments.text,self.strBlogId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostBlogComment_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostBlogCommentResponse"] objectForKey:@"PostBlogCommentResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            NSDictionary *dict=[arr objectAtIndex:0];
            if (dict) {
                [SharedInstance showAlert:[dict objectForKey:@"Reason"] andTitle:alertTitle];
                if ([[dict objectForKey:@"Status"] boolValue]) {
                    [_txtComments setText:@""];
                    [_txtName setText:@""];
                    [_txtEmail setText:@""];
                    [self callGetBlogComments];
                }
                
            }
            
            NSLog(@" Blog Post %@",arr);

            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}
- (IBAction)btnSegmentAction:(id)sender {
    
    if ([_segment selectedSegmentIndex]==0) {
        [_seg1ScrollView setHidden:NO];
        [_seg2CommentView setHidden:YES];
        [_seg3ScrollView setHidden:YES];
    }
    if ([_segment selectedSegmentIndex]==1) {
        [_seg1ScrollView setHidden:YES];
        [_seg2CommentView setHidden:NO];
        [_seg3ScrollView setHidden:YES];
     }
    if ([_segment selectedSegmentIndex]==2) {
        [_seg1ScrollView setHidden:YES];
        [_seg2CommentView setHidden:YES];
        [_seg3ScrollView setHidden:NO];
    }
    
}

-(BOOL)isValidate
{
    
    _txtName.text =[_txtName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtEmail.text =[_txtEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtComments.text =[_txtComments.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (!_txtName.text.length) {
        [SharedInstance showAlert:@"Please Enter Name." andTitle:alertTitle];
        return NO;
    }
    else if (![SharedInstance emailAddressIsValid:_txtEmail.text]) {
        [SharedInstance showAlert:@"Please Enter Email_Id." andTitle:alertTitle];
        return NO;
    }
    else if (![SharedInstance emailAddressIsValid:_txtEmail.text]) {
        [SharedInstance showAlert:@"Please Enter Valid Email_Id." andTitle:alertTitle];
        return NO;
    }
    else if (!_txtComments.text.length) {
        [SharedInstance showAlert:@"Please Enter Comment." andTitle:alertTitle];
        return NO;
    }
    else{
        return true;
    }
    return NO;
}
- (IBAction)btnSubmitCommecnt:(id)sender {
    
    if ([self isValidate]) {
        [self callPostBlogComment];
    }
}

@end
