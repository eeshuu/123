//
//  CellBlog.m
//  workly
//
//  Created by Nilesh Pal on 30/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "CellBlog.h"

@implementation CellBlog

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
