//
//  TrackVC.h
//  LoanBaba
//
//  Created by Nilesh Pal on 04/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrackVC : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txtLoanNo;
- (IBAction)action_Submit:(id)sender;
@end
