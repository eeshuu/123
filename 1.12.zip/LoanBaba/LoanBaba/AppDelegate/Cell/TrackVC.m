//
//  TrackVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 04/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "TrackVC.h"

@interface TrackVC ()

@end

@implementation TrackVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}


#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)action_Submit:(id)sender {
    if (_txtLoanNo.text.length>0) {
        if ([SharedInstance isNetworkConnected])
        {
            [self callTrakLoanAppService];
        }
        else {
            [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
        }
    }
    else {
        
    }
}


- (void)callTrakLoanAppService {

    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:TrakLoanApp>\n"
                             "<tem:strUserId>%@</tem:strUserId>\n"
                             "</tem:TrakLoanApp>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",_txtLoanNo.text];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:TrakLoanApp_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        [self.view endEditing:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"TrakLoanAppResponse"] objectForKey:@"TrakLoanAppResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            if (arr.count > 0) {
                if ([arr[0][@"Status"] isEqualToString:@"true"]) {
                    
                    [SharedInstance showAlert:arr[0][@"ApplicationStatus"] andTitle:alertTitle];
                }
                else {
                    [SharedInstance showAlert:arr[0][@"ApplicationStatus"] andTitle:alertTitle];
                }
            }
            
            NSLog(@"Data track loan %@",arr);
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
