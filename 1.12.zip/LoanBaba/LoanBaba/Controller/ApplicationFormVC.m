//
//  ApplicationFormVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 04/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ApplicationFormVC.h"
#import "UploadDocVC.h"
#import "SAMenuDropDown.h"
@interface ApplicationFormVC ()<SAMenuDropDownDelegate>
{
    NSMutableDictionary *dictFormData;
    UIDatePicker *datePicker;
    SAMenuDropDown *dropDowngender,*dropDownNature;
    NSArray *arrayGender,*arrayNature;
}
@property (weak, nonatomic) IBOutlet UILabel *lblHeading;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview1;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview2;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview3;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview4;
@property (weak, nonatomic) IBOutlet UIView *view4;
@property (weak, nonatomic) IBOutlet UIView *viewSegment3;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *heightSegment3;

@property (weak, nonatomic) IBOutlet UITextField *seg4txtNatureOfOccupant;

@property (weak, nonatomic) IBOutlet UITextField *seg4txtNatureOfBusiness;
@property (weak, nonatomic) IBOutlet UITextField *seg4txtBusinessName;
@property (weak, nonatomic) IBOutlet UIButton *seg4BtnNatureOfOccupant;

@property (weak, nonatomic) IBOutlet UIButton *seg4BtnSubmit;
@property (weak, nonatomic) IBOutlet UIView *seg4Viewmiddle;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *seg4ViewMiddleConst;
@property (weak, nonatomic) IBOutlet UIButton *seg4BtnNature;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *seg4viewButtomConst;

@property (weak, nonatomic) IBOutlet UIView *seg4BottmView;

@property (weak, nonatomic) IBOutlet UITextView *seg4txtViewAddressEmployer;
@property (weak, nonatomic) IBOutlet UITextField *se4txtTotalExp;
@property (weak, nonatomic) IBOutlet UITextField *se4txtPresentJob;
@property (weak, nonatomic) IBOutlet UITextField *se4txtPreviousJob;
@property (weak, nonatomic) IBOutlet UITextField *se4txtNameEmployer;
@property (weak, nonatomic) IBOutlet UITextField *se4txtWorkEmail;




@property (weak, nonatomic) IBOutlet UITextField *seg1TxtName;
@property (weak, nonatomic) IBOutlet UITextField *seg1TxtFName;
@property (weak, nonatomic) IBOutlet UITextField *seg1TxtSpouseName;
@property (weak, nonatomic) IBOutlet UITextField *seg1TxtGender;
@property (weak, nonatomic) IBOutlet UITextField *seg1TxtDOB;
@property (weak, nonatomic) IBOutlet UITextField *seg1TxtEmailID;
@property (weak, nonatomic) IBOutlet UITextField *seg1TxtMobileNO;
@property (weak, nonatomic) IBOutlet UITextField *seg1TxtPanNO;
@property (strong, nonatomic) IBOutlet UIButton *seg1BtnGender;


@property (weak, nonatomic) IBOutlet UITextField *seg2Name;
@property (weak, nonatomic) IBOutlet UITextField *seg2street;
@property (weak, nonatomic) IBOutlet UITextField *seg2area;
@property (weak, nonatomic) IBOutlet UITextField *seg2landmark;
@property (weak, nonatomic) IBOutlet UITextField *seg2city;
@property (weak, nonatomic) IBOutlet UITextField *seg2State;
@property (weak, nonatomic) IBOutlet UITextField *seg2Pincode;


@property (weak, nonatomic) IBOutlet UITextField *seg3Name;
@property (weak, nonatomic) IBOutlet UITextField *seg3street;
@property (weak, nonatomic) IBOutlet UITextField *seg3area;
@property (weak, nonatomic) IBOutlet UITextField *seg3landmark;
@property (weak, nonatomic) IBOutlet UITextField *seg3city;
@property (weak, nonatomic) IBOutlet UITextField *seg3State;
@property (weak, nonatomic) IBOutlet UITextField *seg3Pincode;
@property (weak, nonatomic) IBOutlet UIButton *seg3BtnSameAction;


@end

@implementation ApplicationFormVC
@synthesize strRequestId;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Application Form";
    _scrollview2.hidden=_scrollview3.hidden=_scrollview1.hidden=YES;
  
    for(id aSubView in [self.view subviews])
    {
        if([aSubView isKindOfClass:[UIScrollView class]] )
        {
            for (id bSubView in [aSubView subviews]) {
                if([bSubView isKindOfClass:[UIView class]] ){
                    for (id cSubView in [bSubView subviews]) {
                        if([cSubView isKindOfClass:[UITextField class]] ){
                            UITextField *textField=(UITextField*)cSubView;
                            [textField.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
                            [textField.layer setBorderWidth:1.0f];
                            [textField setBorderStyle:UITextBorderStyleNone];
                            UIView *leftFirst=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
                            textField.leftView=leftFirst;
                            [textField setLeftViewMode:UITextFieldViewModeAlways];
                        }
                    }
                }
            }
        }
    }


    [_scrollview1 bringSubviewToFront:self.view];
    
    [_scrollview4 bringSubviewToFront:self.view];
    
    dictFormData=[[NSMutableDictionary alloc] init];
    
    [self setupUI];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - SADropDown delegate
#pragma mark-SAMenuDropDown Deligate
- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex
{
    if (dropDowngender==menuSender) {
        [_seg1TxtGender setText:[[arrayGender objectAtIndex:buttonIndex] objectForKey:@"Title"]];
        [dropDowngender hideSADropDownMenu];
    }
    
    if (dropDownNature==menuSender) {
        [_seg4txtNatureOfOccupant setText:[[arrayNature objectAtIndex:buttonIndex] objectForKey:@"Title"]];
        [dropDownNature hideSADropDownMenu];
        
        
        if (buttonIndex == 0) {
            [_seg4viewButtomConst setConstant:0];
            [_seg4BottmView setHidden:YES];
            
            [_seg4Viewmiddle setHidden:NO];
            [_seg4ViewMiddleConst setConstant:489];
        }
        else{
            [_seg4viewButtomConst setConstant:144];
            [_seg4BottmView setHidden:NO];
            
            [_seg4Viewmiddle setHidden:YES];
            [_seg4ViewMiddleConst setConstant:0];
        }
    }
    
}



#pragma mark - UITextField delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
     return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    return YES;
}


#pragma mark-Action

-(void)setupUI
{
    
    
    /////*******------1---------********///////////////
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.seg1TxtDOB.frame.size.height)];
    [rightView setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"cal.png"]];
    [rightView addSubview:imageloanAmmount];
    [self.seg1TxtDOB setRightViewMode:UITextFieldViewModeAlways];
    self.seg1TxtDOB.rightView=rightView ;
    
    datePicker = [[UIDatePicker alloc]init];
    [datePicker setDate:[NSDate date]];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker addTarget:self action:@selector(dateTextField:) forControlEvents:UIControlEventValueChanged];
    [self.seg1TxtDOB setInputView:datePicker];
    UIToolbar *timePickerToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    
    NSMutableArray *buttonsArray = [[NSMutableArray alloc] init];
    UIBarButtonItem *Done=[[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(doneDatePicker:)];
    [buttonsArray addObject:Done];
    
    UIBarButtonItem *flex = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    [buttonsArray addObject:flex];
    
    UIBarButtonItem *Cancel = [[UIBarButtonItem alloc] initWithTitle:@"Cancel " style:UIBarButtonItemStylePlain target:self action:@selector(cancelDatePicker:)];
    [buttonsArray addObject:Cancel];
    [timePickerToolBar setItems:buttonsArray];
    
    self.seg1TxtDOB.inputAccessoryView = timePickerToolBar;
    
    
    UIView *rightViewGender=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.seg1TxtGender.frame.size.height)];
    [rightViewGender setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmountGender=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmountGender setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmountGender setImage:[UIImage imageNamed:@"Expand_Arrow.png"]];
    [rightViewGender addSubview:imageloanAmmountGender];
    [self.seg1TxtGender setRightViewMode:UITextFieldViewModeAlways];
    self.seg1TxtGender.rightView=rightViewGender ;
    
    
    UIView *rightViewnature=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.seg4txtNatureOfOccupant.frame.size.height)];
    [rightViewnature setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmountnature=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmountnature setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmountnature setImage:[UIImage imageNamed:@"Expand_Arrow.png"]];
    [rightViewnature addSubview:imageloanAmmountnature];
    [self.seg4txtNatureOfOccupant setRightViewMode:UITextFieldViewModeAlways];
    self.seg4txtNatureOfOccupant.rightView=rightViewnature ;
    
    arrayGender=@[@{@"Title":@"Male"},@{@"Title":@"Female"}];
    dropDowngender=[[SAMenuDropDown alloc] initWithWithSource:_seg1BtnGender menuHeight:80 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropDowngender setDelegate:self];
    [dropDowngender setUpItemDataSourceWithNames:arrayGender subtitles:nil imageNames:nil];
    
    arrayNature=@[@{@"Title":@"Salaried"},@{@"Title":@"Self Employed"}];
    dropDownNature=[[SAMenuDropDown alloc] initWithWithSource:_seg4BtnNature menuHeight:80 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropDownNature setDelegate:self];
    [dropDownNature setUpItemDataSourceWithNames:arrayNature subtitles:nil imageNames:nil];
    
     [_seg4txtNatureOfOccupant setText:[[arrayNature objectAtIndex:0] objectForKey:@"Title"]];
     [_seg4viewButtomConst setConstant:0];
     [_seg4BottmView setHidden:YES];
   
    [_seg4txtViewAddressEmployer.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
    [_seg4txtViewAddressEmployer.layer setBorderWidth:1.0f];
   
    
    /////*******------1---------********///////////////
    
}
- (IBAction)btnGenderAction:(id)sender {
    [dropDowngender showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}
- (IBAction)btnNatureAction:(id)sender {
     [dropDownNature showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}






-(void) cancelDatePicker:(id)sender
{
    [self.seg1TxtDOB setText:@""];
   [self.seg1TxtDOB resignFirstResponder];
    
}

-(void) doneDatePicker:(id)sender
{
    [self.seg1TxtDOB resignFirstResponder];
    
}


-(void) dateTextField:(id)sender
{
    UIDatePicker *picker = (UIDatePicker*)self.seg1TxtDOB.inputView;
    [picker setMaximumDate:[NSDate date]];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDate *eventDate = picker.date;
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    
    NSString *dateString = [dateFormat stringFromDate:eventDate];
    self.seg1TxtDOB.text = [NSString stringWithFormat:@"%@",dateString];
    
}


- (IBAction)btnContiueSegment1:(id)sender {
    
    if (self.seg1TxtFName.text.length > 0 &&
        self.seg1TxtSpouseName.text.length > 0 &&
        self.seg1TxtGender.text.length > 0 &&
        self.seg1TxtDOB.text.length > 0 &&
        self.seg1TxtMobileNO.text.length > 0 &&
        self.seg1TxtPanNO.text.length > 0 ) {
        
        if ([SharedInstance emailAddressIsValid:self.seg1TxtEmailID.text]) {
            
            [_segment setSelectedSegmentIndex:1];
            [_lblHeading setText:@"PRESENT ADDRESS"];
            [_scrollview1 setHidden:YES];
            _scrollview1.hidden=_scrollview3.hidden=_view4.hidden=YES;
            [_scrollview2 setHidden:NO];
            [_scrollview2 bringSubviewToFront:self.view];
            
            
            
            NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
            [dict setObject:_seg1TxtName.text forKey:@"Name"];
            [dict setObject:self.seg1TxtFName.text forKey:@"FName"];
            [dict setObject:self.seg1TxtSpouseName.text forKey:@"SpouseName"];
            [dict setObject:self.seg1TxtGender.text forKey:@"Gender"];
            [dict setObject:self.seg1TxtDOB.text forKey:@"DOB"];
            [dict setObject:self.seg1TxtEmailID.text forKey:@"EmailID"];
            [dict setObject:self.seg1TxtMobileNO.text forKey:@"MobileNO"];
            [dict setObject:self.seg1TxtPanNO.text forKey:@"PanNO"];
            
            [dictFormData setObject:dict forKey:@"1"];
        }
        else {
            [SharedInstance showAlert:@"Please enter valid EmailId." andTitle:alertTitle] ;
        }
        
    }
    else {
       [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
    }
    
    
    
}
- (IBAction)btnContiueSegment2:(id)sender {
    
    if (self.seg2Name.text.length > 0 &&
        self.seg2street.text.length > 0 &&
        self.seg2area.text.length > 0 &&
        self.seg2landmark.text.length > 0 &&
        self.seg2city.text.length > 0 &&
        self.seg2State.text.length > 0 &&
        self.seg2Pincode.text.length > 0) {
        [_segment setSelectedSegmentIndex:2];
        [_lblHeading setText:@"PERMANENT ADDRESS"];
        _scrollview1.hidden=_scrollview2.hidden=_view4.hidden=YES;
        [_scrollview3 setHidden:NO];
        [_scrollview3 bringSubviewToFront:self.view];
        
        
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
        [dict setObject:self.seg2Name.text forKey:@"Name"];
        [dict setObject:self.seg2street.text forKey:@"Street"];
        [dict setObject:self.seg2area.text forKey:@"Area"];
        [dict setObject:self.seg2landmark.text forKey:@"Landmark"];
        [dict setObject:self.seg2city.text forKey:@"City"];
        [dict setObject:self.seg2State.text forKey:@"State"];
        [dict setObject:self.seg2Pincode.text forKey:@"Pincode"];
        
        
        [dictFormData setObject:dict forKey:@"2"];
    }
    else {
        [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
    }
    
    
    
    
    
}
- (IBAction)btnContiueSegment3:(id)sender {
    
    
    
    
    NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
    if ([self.seg3BtnSameAction isSelected]) {
//        [dict objectForKey:@"2"];
        [dict setObject:self.seg2Name.text forKey:@"PAName"];
        [dict setObject:self.seg2street.text forKey:@"PAStreet"];
        [dict setObject:self.seg2area.text forKey:@"PAArea"];
        [dict setObject:self.seg2landmark.text forKey:@"PALandmark"];
        [dict setObject:self.seg2city.text forKey:@"PACity"];
        [dict setObject:self.seg2State.text forKey:@"PAState"];
        [dict setObject:self.seg2Pincode.text forKey:@"PAPincode"];
        
        [_segment setSelectedSegmentIndex:3];
        [_lblHeading setText:@"EMPLOYMENT & INCOME DETAILS"];
        _scrollview1.hidden=_scrollview2.hidden=_scrollview3.hidden=YES;
        [_scrollview4 setHidden:NO];
        [_scrollview4 bringSubviewToFront:self.view];
        
         [dictFormData setObject:dict forKey:@"3"];
        
    }
    else{
        
        if (self.seg3Name.text.length > 0 &&
            self.seg3street.text.length > 0 &&
            self.seg3area.text.length > 0 &&
            self.seg3landmark.text.length > 0 &&
            self.seg3city.text.length > 0 &&
            self.seg3State.text.length > 0 &&
            self.seg3Pincode.text.length > 0) {
            [_segment setSelectedSegmentIndex:3];
            [_lblHeading setText:@"EMPLOYMENT & INCOME DETAILS"];
            _scrollview1.hidden=_scrollview2.hidden=_scrollview3.hidden=YES;
            [_view4 setHidden:NO];
            [_view4 bringSubviewToFront:self.view];
            
            
            [dict setObject:self.seg3Name.text forKey:@"Name"];
            [dict setObject:self.seg3street.text forKey:@"Street"];
            [dict setObject:self.seg3area.text forKey:@"Area"];
            [dict setObject:self.seg3landmark.text forKey:@"Landmark"];
            [dict setObject:self.seg3city.text forKey:@"City"];
            [dict setObject:self.seg3State.text forKey:@"State"];
            [dict setObject:self.seg3Pincode.text forKey:@"Pincode"];
            
             [dictFormData setObject:dict forKey:@"3"];
        }
        else {
            [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
        }
        
        
    }
    
   
}

- (IBAction)btnContiueSegment4:(id)sender {
    
    if (self.seg4txtNatureOfOccupant.text.length > 0 &&
        self.seg4txtNatureOfBusiness.text.length > 0 &&
        self.seg4txtBusinessName.text.length > 0) {
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
        [dict setObject:self.seg4txtNatureOfOccupant.text forKey:@"NatureOfOccupant"];
        [dict setObject:self.seg4txtNatureOfBusiness.text forKey:@"NatureOfBusiness"];
        [dict setObject:self.seg4txtBusinessName.text forKey:@"BusinessName"];
        
        [dictFormData setObject:dict forKey:@"4"];
        
        if ([SharedInstance isNetworkConnected])
        {
            [self callPostApplicationFormService:self.strRequestId];
        }
        else {
            [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
        }
    }
    else {
        [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
    }
   
}


- (IBAction)btnToggalSegment3:(UIButton *)sender {
    if ([sender isSelected]) {
        [sender setSelected:NO];
        [_heightSegment3 setConstant:418.0f];
        [_viewSegment3 setHidden:NO];
  }
    else{
        [sender setSelected:YES];
        [_heightSegment3 setConstant:0];
        [_viewSegment3 setHidden:YES];
            }
    [self.view updateConstraintsIfNeeded];
}



- (void)callPostApplicationFormService:(NSString *)requestId {
    
    
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostApplicationForm>\n"
                             "<tem:strUserId>%@</tem:strUserId>\n"
                             "<tem:strQuotRequestId>%@</tem:strQuotRequestId>\n"
                             "<tem:strName>%@</tem:strName>\n"
                             "<tem:strFatherName>%@</tem:strFatherName>\n"
                             "<tem:strSpouseName>%@</tem:strSpouseName>\n"
                             "<tem:strGender>%@</tem:strGender>\n"
                             "<tem:strDOB>%@</tem:strDOB>\n"
                             "<tem:strPanNo>%@</tem:strPanNo>\n"
                             "<tem:strAptName>%@</tem:strAptName>\n"
                             "<tem:strRoad>%@</tem:strRoad>\n"
                             "<tem:strArea>%@</tem:strArea>\n"
                             "<tem:strLandMark>%@</tem:strLandMark>\n"
                             "<tem:strState>%@</tem:strState>\n"
                             "<tem:strCity>%@</tem:strCity>\n"
                             "<tem:strPincode>%@</tem:strPincode>\n"
                             "<tem:strAptNamePA>%@</tem:strAptNamePA>\n"
                             "<tem:strRoadPA>%@</tem:strRoadPA>\n"
                             "<tem:strAreaPA>%@</tem:strAreaPA>\n"
                             "<tem:strLandMarkPA>%@</tem:strLandMarkPA>\n"
                             "<tem:strStatePA>%@</tem:strStatePA>\n"
                             "<tem:strCityPA>%@</tem:strCityPA>\n"
                             "<tem:strPincodePA>%@</tem:strPincodePA>\n"
                             "<tem:strOccupation>%@</tem:strOccupation>\n"
                             "<tem:strExperience>%@</tem:strExperience>\n"
                             "<tem:strYearsPresentJob>%@</tem:strYearsPresentJob>\n"
                             "<tem:strYearsPrvJob>%@</tem:strYearsPrvJob>\n"
                             "<tem:strEmployer>%@</tem:strEmployer>\n"
                             "<tem:strWorkEmail>%@</tem:strWorkEmail>\n"
                             "<tem:strEmployerAddress>%@</tem:strEmployerAddress>\n"
                             "<tem:strNatureBusiness>%@</tem:strNatureBusiness>\n"
                             "<tem:strBusinessName>%@</tem:strBusinessName>\n"
                             "<tem:strEmailId>%@</tem:strEmailId>\n"
                             "<tem:strMobile>%@</tem:strMobile>\n"
                             "</tem:PostApplicationForm>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",[USER_PREF valueForKey:@"RId"],requestId,dictFormData[@"1"][@"Name"],dictFormData[@"1"][@"FName"],dictFormData[@"1"][@"SpouseName"],dictFormData[@"1"][@"Gender"],dictFormData[@"1"][@"DOB"],dictFormData[@"1"][@"PanNO"],dictFormData[@"2"][@"Name"],dictFormData[@"2"][@"Street"],dictFormData[@"2"][@"Area"],dictFormData[@"2"][@"Landmark"],dictFormData[@"2"][@"State"],dictFormData[@"2"][@"City"],dictFormData[@"2"][@"Pincode"],dictFormData[@"3"][@"PAName"],dictFormData[@"3"][@"PAStreet"],dictFormData[@"3"][@"PAArea"],dictFormData[@"3"][@"PALandmark"],dictFormData[@"3"][@"PAState"],dictFormData[@"3"][@"PACity"],dictFormData[@"3"][@"PAPincode"],dictFormData[@"4"][@"NatureOfOccupant"],@"",@"",@"",@"",@"",@"",dictFormData[@"4"][@"NatureOfBusiness"],dictFormData[@"4"][@"BusinessName"],dictFormData[@"1"][@"EmailID"],dictFormData[@"1"][@"MobileNO"]];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostApplicationForm_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostApplicationFormResponse"] objectForKey:@"PostApplicationFormResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data application form %@",arr);
            
            if (arr.count>0) {
                if ([arr[0][@"Status"] isEqualToString:@"true"]) {
                    UploadDocVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"UploadDocVC"];
                    vc.strApplicationId = arr[0][@"ApplicationId"];
                    vc.isSlide = NO;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                else {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                }
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}
@end
