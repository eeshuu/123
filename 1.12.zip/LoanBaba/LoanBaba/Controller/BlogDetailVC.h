//
//  BlogDetailVC.h
//  workly
//
//  Created by Nilesh Pal on 01/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlogDetailVC : UIViewController


@property (strong, nonatomic) NSString *strBlogId;
@end
