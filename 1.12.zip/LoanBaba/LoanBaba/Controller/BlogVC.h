//
//  BlogVC.h
//  workly
//
//  Created by Nilesh Pal on 29/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlogVC : UIViewController

@property (weak, nonatomic) IBOutlet UISearchBar *searchBlog;
@property (weak, nonatomic) IBOutlet UITableView *tblBlog;
@property (nonatomic)BOOL isSlide;

@end
