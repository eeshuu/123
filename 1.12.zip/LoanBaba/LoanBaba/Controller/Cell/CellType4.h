//
//  CellType4.h
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellType4 : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblQuestionType4;
@property (strong, nonatomic) IBOutlet UITextField *TxtQuestionType4;
@end
