//
//  CellBlog.h
//  workly
//
//  Created by Nilesh Pal on 30/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellBlog : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgBlog;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UIButton *btnDate;

@property (weak, nonatomic) IBOutlet UIButton *btnCount;
@end
