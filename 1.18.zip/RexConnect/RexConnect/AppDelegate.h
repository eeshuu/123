//
//  AppDelegate.h
//  RexConnect
//
//  Created by Dheerendra on 5/31/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property BOOL is_login;
@property BOOL is_search;
@property (strong, nonatomic)  NSString *id_user_login;
@property (strong, nonatomic)  UIImage *image_profile;
+ (AppDelegate*)sharedInstance;
-(UIImage *) resizeImage:(UIImage *)orginalImage resizeSize:(CGSize)size;

@end

