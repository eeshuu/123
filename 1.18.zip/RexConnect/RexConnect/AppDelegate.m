//
//  AppDelegate.m
//  RexConnect
//
//  Created by Dheerendra on 5/31/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "AppDelegate.h"
#import "LeftMenuVC.h"
#import "Constant.h"
#import "UIImageView+WebCache.h"
#import <CometChatSDK/CometChat.h>
#import "NativeKeys.h"
@interface AppDelegate ()
{
      CometChat *cometChat;
}
@end

@implementation AppDelegate
@synthesize is_login,id_user_login,image_profile,is_search;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    id_user_login=@"";
    NSUserDefaults *defaultUser=[NSUserDefaults standardUserDefaults];
    NSDictionary *loginInfo=[defaultUser objectForKey:USERDEFAULT_LOGININFO];
    if (loginInfo) {
        is_login=YES;
        id_user_login= [[defaultUser objectForKey:USERDEFAULT_LOGININFO] objectForKey:@"id"];
        
      
        
        [[NSUserDefaults standardUserDefaults] setObject:@[LOGIN_TYPE_USERNAME,[[[NSUserDefaults standardUserDefaults] objectForKey:@"loginInfo"] objectForKey:@"login_email"],[[[NSUserDefaults standardUserDefaults] objectForKey:@"loginInfo"] objectForKey:@"password"]] forKey:LOGIN_DETAILS];
        
         
    }
    else{
        is_login=NO;
        id_user_login=@"";
    }
    
    
    
     [[NSUserDefaults standardUserDefaults] setObject:COMET_CHAT_URL forKey:@"websiteURL"];
    
    
    [self setUpRevealView];
    
    return YES;
}

- (void)handleLogin {
    
    /* Handle Login success event in this block */
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Success"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"com.sdkdemo.logsview.refreshLogs" object:nil];
    
    
}

- (void)handleLoginError:(NSArray *)array {
    
    
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Failure"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"com.sdkdemo.logsview.refreshLogs" object:nil];
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGIN_DETAILS];
    
    NSString *message = @"Error message";
    
    switch ([[array objectAtIndex:1] code]) {
        case 10:
            message = [NSString stringWithFormat:@"Please check your internet connection"];
            break;
        case 11:
            message = [NSString stringWithFormat:@"Error in connection"];
            break;
        case 20:
            message = [NSString stringWithFormat:@"Plsease check username or password"];
            break;
        case 21:
            message = [NSString stringWithFormat:@"Invalid user details"];
            break;
        case 22:
            message = [NSString stringWithFormat:@"Invalid URL"];
            break;
        case 23:
            message = [NSString stringWithFormat:@"CometChat needs to be upgraded on the site"];
        case 24:
            message = [NSString stringWithFormat:@"Invalid credentials OR Server not configured. Please contact the administrator"];
            break;
    }
    
    [[ApplicationManager sharedManagerInstance] showAlert:@"Message" andTitle:message];
    
    message = nil;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
#pragma mark ---- Shared Instance ----

+(AppDelegate*)sharedInstance {
    AppDelegate *appDelegateObj = (AppDelegate *)[UIApplication sharedApplication].delegate;
    return appDelegateObj;
}


-(void) setUpRevealView {
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    LeftMenuVC *leftMenu = (LeftMenuVC *)[mainStoryboard
                                          instantiateViewControllerWithIdentifier: @"LeftMenuVC"];
    
    [SlideNavigationController sharedInstance].leftMenu = leftMenu;
    
    // Creating a custom bar button for right menu
    UIButton *button  = [[UIButton alloc] initWithFrame:CGRectMake(-20, 0, 39, 44)];
    ;

 
    [button setImage:[[UIImage imageNamed:@"right_menu"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
     [button setTintColor:[UIColor whiteColor]];
    [button addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleLeftMenu) forControlEvents:UIControlEventTouchUpInside];
   
    UIBarButtonItem *leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    [SlideNavigationController sharedInstance].leftBarButtonItem = leftBarButtonItem;
    
    
    if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
        
        // do stuff for iOS 7 and newer
        [[SlideNavigationController sharedInstance].navigationBar setBarTintColor:COLOR_RGBA(24,155,149,1)];
    }
    else {
        
        // do stuff for older versions than iOS 7
        [[SlideNavigationController sharedInstance].navigationBar setTintColor:COLOR_RGBA(24,155,149,1)];
    }
    
    
    [[NSNotificationCenter defaultCenter] addObserverForName:SlideNavigationControllerDidClose object:nil queue:nil usingBlock:^(NSNotification *note) {
        NSString *menu = note.userInfo[@"menu"];
        //  NSLog(@"Closed %@", menu);
    }];
    
    [[NSNotificationCenter defaultCenter] addObserverForName:SlideNavigationControllerDidOpen object:nil queue:nil usingBlock:^(NSNotification *note) {
        NSString *menu = note.userInfo[@"menu"];
        //  NSLog(@"Opened %@", menu);
    }];
    
    [[NSNotificationCenter defaultCenter] addObserverForName:SlideNavigationControllerDidReveal object:nil queue:nil usingBlock:^(NSNotification *note) {
        NSString *menu = note.userInfo[@"menu"];
        //  NSLog(@"Revealed %@", menu);
    }];
    
    NSUserDefaults *defaultUser=[NSUserDefaults standardUserDefaults];
    NSDictionary *loginInfo=[defaultUser objectForKey:USERDEFAULT_LOGININFO];
    UIImageView *imgProfile=[[UIImageView alloc]init];
    
    [imgProfile sd_setImageWithURL:[NSURL URLWithString:[loginInfo objectForKey:@"profile_img"]] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        image_profile=image;
    }];
}

-(UIImage *) resizeImage:(UIImage *)orginalImage resizeSize:(CGSize)size
{
    CGFloat actualHeight = orginalImage.size.height;
    CGFloat actualWidth = orginalImage.size.width;
    //  if(actualWidth <= size.width && actualHeight<=size.height)
    //  {
    //      return orginalImage;
    //  }
    float oldRatio = actualWidth/actualHeight;
    float newRatio = size.width/size.height;
    if(oldRatio < newRatio)
    {
        oldRatio = size.height/actualHeight;
        actualWidth = oldRatio * actualWidth;
        actualHeight = size.height;
    }
    else
    {
        oldRatio = size.width/actualWidth;
        actualHeight = oldRatio * actualHeight;
        actualWidth = size.width;
    }
    
    CGRect rect = CGRectMake(0.0,0.0,actualWidth,actualHeight);
    UIGraphicsBeginImageContext(rect.size);
    [orginalImage drawInRect:rect];
    orginalImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return orginalImage;
}

@end
