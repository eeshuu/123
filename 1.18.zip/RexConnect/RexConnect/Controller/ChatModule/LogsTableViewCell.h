//
//  LogsTableViewCell.h
//  SDKTestApp
//
//  Created by Inscripts on 03/10/14.
//  Copyright (c) 2014 inscripts. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *logText;

@end
