//
//  MainViewController.m
//  SDKTestApp
//
//  Created by Inscripts on 03/10/14.
//  Copyright (c) 2014 inscripts. All rights reserved.
//

#import "MainViewController.h"
#import <CometChatSDK/CometChat.h>
#import "NativeKeys.h"
#import "OneOnOneViewController.h"
#import "ChatroomViewController.h"
#import "LogsViewController.h"
#import "ApplicationManager.h"
#import "Constant.h"

@interface MainViewController () {
    
    CometChat *cometChat;
    NSString *siteURL;
    UIBarButtonItem *moreButton;
}

@property (weak, nonatomic) IBOutlet UILabel *lblStatus;
@property (weak, nonatomic) IBOutlet UIImageView *imgStatus;
@end

@implementation MainViewController

@synthesize oneOnOneButton;
@synthesize chatroomButton;
@synthesize logButton;
@synthesize logoutButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    /* Variable Initialization */
    cometChat = [[CometChat alloc] init];
    
    /* Navigation bar settings */
    
    self.navigationItem.hidesBackButton = YES;


    self.navigationItem.title = @"REX Connect";
    
    moreButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"ic_custom_menu"] style:UIBarButtonItemStylePlain target:self action:@selector(showOptions)];
    [moreButton setStyle:UIBarButtonItemStylePlain];
    self.navigationItem.rightBarButtonItems = @[moreButton];
    
    //Settings for buttons
   
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:BUDDY_LIST];
    
    /* Remove previous log from user defaults */
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:LOG_LIST];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGGED_IN_USER];
    
    /* Subscribe to One On One Chat ONLY AFTER successful login.  Set mode argument to YES if you want to strip html elements */
    
    [_imgStatus setImage:[UIImage imageNamed:@"ic_user_available.png"]];
    [_lblStatus setText:ONLINE_STATUS_AVAILABLE];
    
    
}
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

-(void)viewWillAppear:(BOOL)animated
{
     self.navigationController.navigationBarHidden=NO;
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [cometChat loginWithURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"websiteURL"]] username:[[[NSUserDefaults standardUserDefaults] objectForKey:@"loginInfo"] objectForKey:@"login_email"] password:[[[NSUserDefaults standardUserDefaults] objectForKey:@"loginInfo"] objectForKey:@"password"] success:^(NSDictionary *response) {
        
        NSLog(@"SDK log : Username/Password Login Success %@",response);
        
        [self handleLogin];
        [[NSUserDefaults standardUserDefaults] setObject:@[LOGIN_TYPE_USERNAME,[[[NSUserDefaults standardUserDefaults] objectForKey:@"loginInfo"] objectForKey:@"login_email"],[[[NSUserDefaults standardUserDefaults] objectForKey:@"loginInfo"] objectForKey:@"password"]] forKey:LOGIN_DETAILS];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        
        
        
        
        
        
    } failure:^ (NSError *error) {
        
        NSLog(@"SDK log : Username/Password Login Error%@",error);
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        
        [self handleLoginError:@[@0,error]];
        
    }];

}

-(void)viewDidDisappear:(BOOL)animated{
    [self viewDidAppear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:@"com.inscripts.oneononeview.refreshBuddyList"];
    [[NSNotificationCenter defaultCenter] removeObserver:@"com.inscripts.logsview.refreshLogs"];
    [[NSNotificationCenter defaultCenter] removeObserver:@"com.inscripts.oneononechat.messagereceived"];
    
}


- (void)handleLogin {
    
    /* Handle Login success event in this block */
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Success"];
    [cometChat subscribeWithMode:YES onMyInfoReceived:^(NSDictionary *response) {
        
        NSLog(@"SDK log : OneOnOne MYInfo %@",response);
        
        if ([response objectForKey:ID]) {
            
            [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%@",[response objectForKey:ID]] forKey:LOGGED_IN_USER];
            
            if ([[response objectForKey:@"m"] isEqualToString:ONLINE_STATUS_AVAILABLE]) {
                [_imgStatus setImage:[UIImage imageNamed:@"ic_user_available.png"]];
                [_lblStatus setText:[response objectForKey:@"m"]];
                
            }
            else if ([[response objectForKey:@"m"] isEqualToString:ONLINE_STATUS_AWAY]) {
                [_imgStatus setImage:[UIImage imageNamed:@"ic_user_away.png"]];
                [_lblStatus setText:[response objectForKey:@"m"]];
                
            }
            else if ([[response objectForKey:@"s"] isEqualToString:ONLINE_STATUS_OFFLINE]) {
                [_imgStatus setImage:[UIImage imageNamed:@"ic_user_offline.png"]];
                [_lblStatus setText:[response objectForKey:@"m"]];
                
            }
            else if ([[response objectForKey:@"s"] isEqualToString:ONLINE_STATUS_BUSY]) {
                [_imgStatus setImage:[UIImage imageNamed:@"ic_user_busy.png"]];
                [_lblStatus setText:[response objectForKey:@"m"]];
                
            }
            else{
                [_imgStatus setImage:[UIImage imageNamed:@"ic_user_offline.png"]];
                [_lblStatus setText:[response objectForKey:@"m"]];
            }
           
        }
        
       
        
    } onGetOnlineUsers:^(NSDictionary *response) {
        
        /* Online users list will be received here */
        NSLog(@"SDK log : OneOnOne onGetOnlineUsers %@",response);
        
        [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"onGetOnlineUsers"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"com.inscripts.logsview.refreshLogs" object:nil];
        
        /* Update buddylist table */
        NSMutableArray *buddyList = [[NSMutableArray alloc] init];
        NSArray *users = response.allKeys;
        
        for (int i = 0 ; i < [users count]; i++) {
            
            if ([response objectForKey:[users objectAtIndex:i]]) {
                [buddyList addObject:[response objectForKey:[users objectAtIndex:i]]];
            }
        }
        
        
        /* Store buddyList in userdefaults */
        [[NSUserDefaults standardUserDefaults] setObject:buddyList forKey:BUDDY_LIST];
        
        /* Send notification to OneOnOneView to refresh buddyList */
        [[NSNotificationCenter defaultCenter] postNotificationName:@"com.inscripts.oneononeview.refreshBuddyList" object:nil];
        
    } onMessageReceived:^(NSDictionary *response) {
        /* One On One messages will be recieved in this callback */
        NSLog(@"SDK log : OneOnOne onMessageReceived %@",response);
        
        [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"onMessageReceived"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"com.inscripts.logsview.refreshLogs" object:nil];
        
        if ([[NSUserDefaults standardUserDefaults] objectForKey:CURRENT_BUDDY_ID]) {
            
            /* If message is received from current buddy (Buddy you are chatting with), then send notification to OneOnOneChatView controller */
            if ([[[NSUserDefaults standardUserDefaults] objectForKey:CURRENT_BUDDY_ID] isEqualToString:[response objectForKey:FROM]]) {
                [[NSNotificationCenter defaultCenter] postNotificationName:@"com.inscripts.oneononechat.messagereceived" object:nil userInfo:response];
            }
        }
        
    } onAnnouncementReceived:^(NSDictionary *response) {
        
        NSLog(@"SDK log : OneOnOne announcement %@",response);
        
        /* Announcements messages will be recieved in this callback */
        [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"onAnnouncementReceived"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"com.inscripts.logsview.refreshLogs" object:nil];
        
    } onAVChatMessageReceived:^(NSDictionary *response) {
        NSLog(@"SDK log : AVChat message received = %@",response);
        
        [NativeKeys getLogOType:LOG_TYPE_AVCHAT ForMessage:@"onAVChatMessageReceived"];
        
    } failure:^(NSError *error) {
        /* Subscribe failure will be handled here */
        NSLog(@"SDK log : OneOnOne subscribe error %@",error);
        [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Subscribe failure"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"com.inscripts.logsview.refreshLogs" object:nil];
        
    }];
      
}

- (void)handleLoginError:(NSArray *)array {
    
    
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Failure"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"com.sdkdemo.logsview.refreshLogs" object:nil];
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGIN_DETAILS];
    
    NSString *message = @"Error message";
    
    switch ([[array objectAtIndex:1] code]) {
        case 10:
            message = [NSString stringWithFormat:@"Please check your internet connection"];
            break;
        case 11:
            message = [NSString stringWithFormat:@"Error in connection"];
            break;
        case 20:
            message = [NSString stringWithFormat:@"Plsease check username or password"];
            break;
        case 21:
            message = [NSString stringWithFormat:@"Invalid user details"];
            break;
        case 22:
            message = [NSString stringWithFormat:@"Invalid URL"];
            break;
        case 23:
            message = [NSString stringWithFormat:@"CometChat needs to be upgraded on the site"];
        case 24:
            message = [NSString stringWithFormat:@"Invalid credentials OR Server not configured. Please contact the administrator"];
            break;
    }
    
    [[ApplicationManager sharedManagerInstance] showAlert:@"Message" andTitle:message];
    
    message = nil;
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)openOneOnOneList:(id)sender {
    [cometChat getOnlineUsersWithResponse:^(NSDictionary *response) {
        NSLog(@"SDK Log online users : %@",response);
        
        /* Update buddylist table */
        NSMutableArray *buddyList = [[NSMutableArray alloc] init];
        NSArray *users = response.allKeys;
        
        for (int i = 0 ; i < [users count]; i++) {
            
            if ([response objectForKey:[users objectAtIndex:i]]) {
                [buddyList addObject:[response objectForKey:[users objectAtIndex:i]]];
            }
        }
        
        
        /* Store buddyList in userdefaults */
        [[NSUserDefaults standardUserDefaults] setObject:buddyList forKey:BUDDY_LIST];
        
        /* Send notification to OneOnOneView to refresh buddyList */
        [[NSNotificationCenter defaultCenter] postNotificationName:@"com.inscripts.oneononeview.refreshBuddyList" object:nil];

        
    } failure:^(NSError *error) {
        NSLog(@"SDK Log online users error: %@",error);
    }];
    OneOnOneViewController *buddyListViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"oneononeviewcontroller"];
    [self.navigationController pushViewController:buddyListViewController animated:YES];
    buddyListViewController = nil;
}

- (IBAction)openChatroomList:(id)sender {
    
    ChatroomViewController *chatViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"chatroomviewcontroller"];
    [self.navigationController pushViewController:chatViewController animated:YES];
//    chatViewController = nil;
}

- (IBAction)showLogs:(id)sender {
    
    LogsViewController *logsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"logsviewcontroller"];
    [self.navigationController pushViewController:logsViewController animated:YES];
    logsViewController = nil;
}

- (IBAction)logout:(id)sender {
    
    [cometChat logoutWithSuccess:^(NSDictionary *response) {
        
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGIN_DETAILS];
        [self.navigationController popViewControllerAnimated:YES];
        
    } failure:^(NSError *error) {
        
    }];
}

- (void)showOptions {
//    moreButton.enabled = NO;
//    
//    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
//    
//    for (NSString *option in @[@"Change Status",@"Change Status message",@"Set translation language"]) {
//        [actionSheet addButtonWithTitle:option];
//    }
//    // Also add a cancel button
//    actionSheet.cancelButtonIndex = [actionSheet addButtonWithTitle:@"Cancel"];
//    
//    [actionSheet showFromBarButtonItem:moreButton animated:YES];
//    
//    actionSheet = nil;
    
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Staus ! "
                                 message:@"Select your current status"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    
    UIAlertAction* online = [UIAlertAction
                             actionWithTitle:@"Online"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 //Do some thing here
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    UIAlertAction* offline = [UIAlertAction
                              actionWithTitle:@"Offline"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  self changeStatus:<#(NSInteger)#> success:<#^(NSDictionary *response)response#> failure:<#^(NSError *error)failure#>
                                  [view dismissViewControllerAnimated:YES completion:nil];
                                  
                              }];
    UIAlertAction* doNotDistrbe = [UIAlertAction
                                   actionWithTitle:@"Do not disturb"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action)
                                   {
                                       [view dismissViewControllerAnimated:YES completion:nil];
                                       
                                   }];
    UIAlertAction* away = [UIAlertAction
                           actionWithTitle:@"Away"
                           style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * action)
                           {
                               [view dismissViewControllerAnimated:YES completion:nil];
                               
                           }];
    
    [online setValue:[[UIImage imageNamed:@"ic_user_available.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [offline setValue:[[UIImage imageNamed:@"ic_user_offline.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [doNotDistrbe setValue:[[UIImage imageNamed:@"ic_user_busy.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [away setValue:[[UIImage imageNamed:@"ic_user_away.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    
    
    [view addAction:online];
    [view addAction:away];
    [view addAction:offline];
    [view addAction:doNotDistrbe];
    [self presentViewController:view animated:YES completion:nil];
    
    
    
  
}



- (void)changeStatus:(NSInteger)status
             success:(void(^)(NSDictionary *response))response
             failure:(void(^)(NSError *error))failure
{
    
}

#pragma mark - UIActionSheetDelegate Methods
- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    moreButton.enabled = YES;
    
    if (buttonIndex == actionSheet.cancelButtonIndex){
        return;
    }
    
    switch (buttonIndex) {
        case 0:
            
            [cometChat changeStatus:STATUS_BUSY success:^(NSDictionary *response) {
                
                NSLog(@"SDK Log : Change status Response = %@",response);
                
            } failure:^(NSError *error) {
                
                NSLog(@"SDK Log : Change status Error = %@",error);
            }];
            
            break;
        case 1:
            
            [cometChat changeStatusMessage:@"I'm available" success:^(NSDictionary *response) {
                
                NSLog(@"SDK Log : Change status message Response = %@",response);
                
            } failure:^(NSError *error) {
                
                NSLog(@"SDK Log : Change status message Error = %@",error);
            }];
            
            break;
        
        case 2:
            
            [cometChat setTranslationLanguage:French success:^(NSDictionary *response) {
                
                NSLog(@"SDK Log : Set Translation language Response = %@",response);
                
            } failure:^(NSError *error) {
                
                NSLog(@"SDK Log : Set Translation language Error = %@",error);
            }];
            break;
            
    }
}


@end
