//
//  OneOnOneChatViewController.h
//  SDKTestApp
//
//  Created by Inscripts on 30/09/14.
//  Copyright (c) 2014 inscripts. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface OneOnOneChatViewController : UIViewController <UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate>

@property (strong, nonatomic) NSString *buddyID;
@property (strong,nonatomic) NSString *buddyName;
@property (weak, nonatomic) IBOutlet UITableView *buddyChatTable;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tableViewToBottom;
@property (weak, nonatomic) IBOutlet UITextField *message;
@property (weak, nonatomic) IBOutlet UIView *wrapper;
@property (weak, nonatomic) IBOutlet UIButton *sendButton;

- (IBAction)sendMessage:(id)sender;
- (void)sendImage;

@end
