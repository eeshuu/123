//
//  AreaGuideVC.m
//  RexConnect
//
//  Created by Dheerendra on 6/14/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "AreaGuideVC.h"
#import "Constant.h"
#import "CellVeiwController.h"
#import "CellAreaGuideReview.h"
#import "UIImageView+WebCache.h"
@interface AreaGuideVC ()
{
    NSMutableArray *arrayReviews;
    NSMutableArray *arrayAmnities;
    NSMutableArray *arrayImage;
    UITextView *txtReview;
}
@property (strong, nonatomic) IBOutlet UITableView *tblData;
@property (strong, nonatomic) IBOutlet UISegmentedControl *segmentControl;
@property (strong, nonatomic) IBOutlet UILabel *lblDescription;
@property (strong, nonatomic) IBOutlet UIButton *btnAddReview;
@property (strong, nonatomic) IBOutlet UITextView *txtDescription;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollImages;
@end

@implementation AreaGuideVC
@synthesize strSubcat;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Area Guide";
      self.navigationController.navigationBarHidden=NO;
    arrayAmnities=[[NSMutableArray alloc]initWithObjects:@{@"Title":@"test"},@{@"Title":@{@"Title":@"test"}},@{@"Title":@"test"},@{@"Title":@"test"},@{@"Title":@"test"},@{@"Title":@"test"},@{@"Title":@"test"}, nil];
    
    
    arrayAmnities=[[NSMutableArray alloc]init];
    arrayReviews=[[NSMutableArray alloc]init];
    arrayImage=[[NSMutableArray alloc]init];
    
    _segmentControl.layer.borderColor=[[UIColor lightGrayColor] CGColor];
    _segmentControl.layer.cornerRadius = 0.0;
    _segmentControl.layer.borderWidth = 1.0f;
    [_segmentControl setSelectedSegmentIndex:0];
    self.segmentControl.layer.masksToBounds = YES;
    [self segmentSelection:_segmentControl];
    
    self.navigationController.navigationBarHidden=NO;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark-Alert View deligate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if(alertView.tag==101)
    {
        if (buttonIndex == 1) {
           
            if ([txtReview.text length]> 0) {
                [self submitReview];
            }
            else{
                [[ApplicationManager sharedManagerInstance]showAlert:@"Please Fill Review Text Before Submit. " andTitle:@"Error!"];
            }

        }
        else{
            [alertView dismissWithClickedButtonIndex:1 animated:YES];
        }
        
    }
}

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([_segmentControl selectedSegmentIndex] == 1) {
        return [arrayReviews count];
    }
    else  if ([_segmentControl selectedSegmentIndex] == 2) {
        return [arrayAmnities count];
    }
    else{
        return 0;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_segmentControl selectedSegmentIndex] == 1) {
        return 90;
    }
    else if([_segmentControl selectedSegmentIndex] == 2){
        return 44;
    }
    else{
        return 0;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_segmentControl selectedSegmentIndex] == 1) {
        static NSString *CellIdentifier = @"CellAreaGuideReview";
        CellAreaGuideReview	*customCell = (CellAreaGuideReview *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (customCell == nil) {
            customCell = [[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
            [customCell setSelectionStyle:UITableViewCellSelectionStyleNone];
            [customCell setClipsToBounds:YES];
         }
            NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayReviews objectAtIndex:indexPath.row]];
        /*set*/
            [customCell setData:dictData];
        
        return customCell;
    }
    else if([_segmentControl selectedSegmentIndex] == 2){
        static NSString *CellIdentifier = @"CellAmenities";
         UITableViewCell *customCell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (customCell == nil) {
            customCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            [customCell setClipsToBounds:YES];
        }
       
        customCell.textLabel.text=[[arrayAmnities objectAtIndex:indexPath.row] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];;
        customCell.textLabel.textColor=[UIColor darkGrayColor];
        return customCell;
    }
    
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_segmentControl selectedSegmentIndex] == 1) {
        [[ApplicationManager sharedManagerInstance]showAlert:[[arrayReviews objectAtIndex:indexPath.row] objectForKey:@"comment"] andTitle:[NSString stringWithFormat:@"%@ Comment:",[[arrayReviews objectAtIndex:indexPath.row] objectForKey:@"user_name"]]];
    }
}


#pragma mark-Action
/**/
-(void)loadServerData_review
{
    [_tblData reloadData];
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"area_review",@"type": @"listing_area_review",@"area_id": strSubcat};
        
        NSString *strUrl=COMMON_URL(REVIEW_GUIDE);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    arrayReviews=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"listing_area_review"]];
                    [_tblData reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

-(void)submitReview
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        NSUserDefaults *defaultUser=[NSUserDefaults standardUserDefaults];
        NSDictionary *loginInfo=[defaultUser objectForKey:USERDEFAULT_LOGININFO];
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"area_review",@"type": @"post_area_review",@"area_id": strSubcat,@"comment":[txtReview.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]],@"user_id":[loginInfo objectForKey:@"id"]};
        
        NSString *strUrl=COMMON_URL(REVIEW_GUIDE);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                [[ApplicationManager sharedManagerInstance] showAlert:@"Review Successfully Submitted." andTitle:alertTitle];
                [self loadServerData_review];
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}


-(void)loadServerData_Description
{
    [_tblData reloadData];
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"singlearea",@"sub_cat_id": strSubcat};
        
        NSString *strUrl=COMMON_URL(AREA_GUIDE);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    [_lblDescription setHidden:NO];
                    [_txtDescription setHidden:NO];
                    NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithDictionary:data[@"responseData"][@"singlearea"][0]];
                    NSString *decription=[NSString stringWithFormat:@"%@",[dict objectForKey:@"discription"]];
                    if ([decription length]>0) {
                        [_txtDescription setText:decription];
                    }
                    else{
                        [_txtDescription setText:@"Not Available"];
                    }
                    
                    /*fill amanities array*/
                    arrayAmnities=[[NSMutableArray alloc]initWithArray:[dict objectForKey:@"amenities"]];
                    if ([arrayAmnities count]==1) {
                        if ([[arrayAmnities objectAtIndex:0] length]==0) {
                            arrayAmnities=[[NSMutableArray alloc]init];
                        }
                    }
                    
                    arrayImage=[[NSMutableArray alloc]initWithObjects:[dict objectForKey:@"cat_img"], nil];
                    
                    [self loadImageDescription];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

- (IBAction)segmentSelection:(id)sender {
    UIColor *selectedColor = [UIColor lightGrayColor];
    NSDictionary *segmentedControlTextAttributes = @{NSFontAttributeName:[UIFont fontWithName:@"HelveticaNeue" size:16.0], NSForegroundColorAttributeName:[UIColor whiteColor]};
    [self.segmentControl setTitleTextAttributes:segmentedControlTextAttributes forState:UIControlStateNormal];
    [self.segmentControl setTitleTextAttributes:segmentedControlTextAttributes forState:UIControlStateHighlighted];
    [self.segmentControl setTitleTextAttributes:segmentedControlTextAttributes forState:UIControlStateSelected];
    
    for (UIControl *subview in [_segmentControl subviews]) {
        if ([subview isSelected]){
            [subview setTintColor:selectedColor];
            [subview.layer setCornerRadius:0];
        }
        else{
             [subview.layer setCornerRadius:5];
        }
    }
    
    
    if (self.segmentControl.selectedSegmentIndex == 1) {
        [_lblDescription setHidden:YES];
        [_scrollImages setHidden:YES];
        [_txtDescription setHidden:YES];
        [_btnAddReview setHidden:NO];
        [_tblData setHidden:NO];

        [self loadServerData_review];
    }
    else if(self.segmentControl.selectedSegmentIndex == 2) {
        [_lblDescription setHidden:YES];
        [_txtDescription setHidden:YES];
        [_scrollImages setHidden:YES];
        [_btnAddReview setHidden:YES];
        [_tblData setHidden:NO];
        [_tblData reloadData];
    }
    else{
        [_lblDescription setHidden:NO];
        [_txtDescription setHidden:NO];
        [_scrollImages setHidden:NO];
        [_btnAddReview setHidden:YES];
        [_tblData setHidden:YES];
         [self loadServerData_Description];
    }
}
- (IBAction)addNewReview:(id)sender {
    
    if (![AppDelegate sharedInstance].is_login) {
        [[ApplicationManager sharedManagerInstance]showAlert:@"Please login first to submit your review" andTitle:@"Warring !"];
    }
    else{
    UIAlertView *testAlert = [[UIAlertView alloc] initWithTitle:@"Reviwer Name"
                                                        message:@"Please fill this review"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"Post Review", nil];
    testAlert.tag=101;
    txtReview = [UITextView new];
    [testAlert setValue:txtReview forKey:@"accessoryView"];
    [testAlert show];
    }
}



/*load scroll view images*/
-(void)loadImageDescription
{
    int X=0;
    
    for (int i=0; i<[arrayImage count]; i++) {
        
        X=(_scrollImages.frame.size.height*i)+5*i;
        UIImageView *imgView=[[UIImageView alloc]initWithFrame:CGRectMake(X, 2, _scrollImages.frame.size.height, _scrollImages.frame.size.height-4)];
//        [imgView setBackgroundColor:[UIColor redColor]];
        [imgView setImage:[UIImage imageNamed:@"not_found.png"]];
        [imgView setContentMode:UIViewContentModeScaleToFill];
        [imgView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_BASE_URL,[arrayImage objectAtIndex:i]]]];
        [_scrollImages addSubview:imgView];
    }
    
    [_scrollImages setContentSize:CGSizeMake(X+_scrollImages.frame.size.height+5, _scrollImages.frame.size.height)];
}

@end
