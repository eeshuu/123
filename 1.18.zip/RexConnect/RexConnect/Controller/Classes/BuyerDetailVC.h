//
//  BuyerDetailVC.h
//  RexConnect
//
//  Created by cis on 6/23/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
@interface BuyerDetailVC : UIViewController<MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,UINavigationControllerDelegate>
{
     NSString *strEmail,*strPhoneNumber;
}
@property(nonatomic,retain) NSMutableDictionary *dictDetail;
@end
