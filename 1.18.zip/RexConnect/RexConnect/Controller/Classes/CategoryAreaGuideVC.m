//
//  CategoryAreaGuideVC.m
//  RexConnect
//
//  Created by cis on 6/16/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CategoryAreaGuideVC.h"
#import "Constant.h"
#import "SubCatAreaGuideVC.h"
#import "CellCatTable.h"
@interface CategoryAreaGuideVC ()
{
    NSMutableArray *arrayMainArea;
}
@property (strong, nonatomic) IBOutlet UITableView *tblMainArea;

@end

@implementation CategoryAreaGuideVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
      self.navigationController.navigationBarHidden=NO;
    self.title=@"Agent Guide";
    arrayMainArea=[[NSMutableArray alloc]init];
    [self loadServerData];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - UITableView Delegate & Datasrouce -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayMainArea count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellCatTable *cell = [tableView dequeueReusableCellWithIdentifier:@"CellCatTable"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayMainArea objectAtIndex:indexPath.row]];
    /*set*/
    [cell setData:dictData];
  
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SubCatAreaGuideVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                             bundle: nil] instantiateViewControllerWithIdentifier: @"SubCatAreaGuideVC"];
    VC.strCategoryID=[[arrayMainArea objectAtIndex:indexPath.row] objectForKey:@"cat_id"];
    VC.strCategoryName=[[arrayMainArea objectAtIndex:indexPath.row] objectForKey:@"cat_name"];
    
    [self.navigationController pushViewController:VC animated:YES];
}

#pragma mark-Action
/**/
-(void)loadServerData
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"areamain",@"type": @"select_areamain"};
        
        NSString *strUrl=COMMON_URL(AREA_GUIDE);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    arrayMainArea=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"areamain"]];
                    [_tblMainArea reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];

        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}
@end
