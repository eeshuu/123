//
//  CellAgentList.h
//  RexConnect
//
//  Created by cis on 6/5/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImageView+WebCache.h"
@interface CellAgentList : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *img;
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (strong, nonatomic) IBOutlet UILabel *lblSpeciality;
@property (strong, nonatomic) IBOutlet UILabel *lblScore;
@property (strong, nonatomic) IBOutlet UIImageView *starImg1;
@property (strong, nonatomic) IBOutlet UIImageView *starImg2;
@property (strong, nonatomic) IBOutlet UIImageView *starImg3;
@property (strong, nonatomic) IBOutlet UIImageView *starImg4;
@property (strong, nonatomic) IBOutlet UIImageView *starImg5;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;
@property (strong, nonatomic) IBOutlet UIButton *btnRate;
@property (strong, nonatomic) IBOutlet UIButton *btnMessage;
@property (strong, nonatomic) IBOutlet UIButton *btnCall;
@property (strong, nonatomic) IBOutlet UIButton *btnMail;
@property (strong, nonatomic) IBOutlet UIButton *btnChat;
-(void)setData:(NSMutableDictionary *)dict;
@end
