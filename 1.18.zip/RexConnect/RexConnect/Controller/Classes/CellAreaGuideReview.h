//
//  CellAreaGuideReview.h
//  RexConnect
//
//  Created by Dheerendra on 6/14/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellAreaGuideReview : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (strong, nonatomic) IBOutlet UILabel *lblMessage;
@property (strong, nonatomic) IBOutlet UILabel *lblTime;
@property (strong, nonatomic) IBOutlet UIImageView *imgReviwer;
-(void)setData:(NSMutableDictionary *)dict;
@end
