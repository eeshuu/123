//
//  CellBuyerDetail.h
//  RexConnect
//
//  Created by Dheerendra on 6/27/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellBuyerDetail : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblHading;
@property (strong, nonatomic) IBOutlet UILabel *lblType;
@property (strong, nonatomic) IBOutlet UIImageView *imgProperty;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;
-(void)setData:(NSMutableDictionary *)dict;

@end
