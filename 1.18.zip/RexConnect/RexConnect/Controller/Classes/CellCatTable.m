//
//  CellCatTable.m
//  RexConnect
//
//  Created by Dheerendra on 6/21/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellCatTable.h"
#import "Constant.h"
#import "UIImageView+WebCache.h"
@implementation CellCatTable

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setData:(NSMutableDictionary *)dict
{
    
      NSURL *imgURL=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_BASE_URL,[dict objectForKey:@"cat_img"]]];
    
    [self.loader startAnimating];
    
    [self.imgCell sd_setImageWithURL:imgURL placeholderImage:[UIImage imageNamed:@"no_image_found.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [self.imgCell setImage:image];
        [self.loader stopAnimating];
    }];
    
    [self.lblValue setText:[dict objectForKey:@"cat_name"]];
   
}

@end
