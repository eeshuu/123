//
//  CellFindBuyer.h
//  RexConnect
//
//  Created by cis on 6/5/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellFindBuyer : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgBuyer;
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (strong, nonatomic) IBOutlet UILabel *lblType;

@property (weak, nonatomic) IBOutlet UILabel *lblDetail;
@property (weak, nonatomic) IBOutlet UILabel *lblPrice;
-(void)setData:(NSMutableDictionary *)dict;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;



@property (strong, nonatomic) IBOutlet UIButton *btnMessage,*btnMail,*btnCall,*btnChat;

@property (strong, nonatomic) IBOutlet UIImageView *star1,*star2,*star3,*star4,*star5;

@end
