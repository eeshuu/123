//
//  CellLeftMenu.h
//  Kronopress
//
//  Created by cis on 4/28/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellLeftMenu : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UIImageView *imgMenu;
-(void)setData:(NSDictionary *)dict;
@end
