//
//  CellLeftMenu.m
//  Kronopress
//
//  Created by cis on 4/28/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "CellLeftMenu.h"
#import "KPCommanClass.h"
#import "Constant.h"
@implementation CellLeftMenu

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
/*SET DATA*/
-(void)setData:(NSDictionary *)dict
{
    /*set title*/
    [self.lblTitle setText:[dict objectForKey:@"Title"]];
    /*set image*/
    [self.imgMenu setImage:[[UIImage imageNamed:[dict objectForKey:@"imageName"]] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate]];
    [self.imgMenu  setTintColor:[UIColor colorWithRed:152.0f/255.0f green:152.0f/255.0f blue:152.0f/255.0f alpha:1.0]];
   
}
@end
