//
//  CellRateAnAgent.m
//  RexConnect
//
//  Created by cis on 7/17/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellRateAnAgent.h"
#import "UIImageView+WebCache.h"
@implementation CellRateAnAgent

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
/*set data*/
-(void)setData:(NSMutableDictionary *)dict{
    
    [self.img.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
    [self.img.layer setBorderWidth:1.0f];
    
    NSURL *ImgURl=[NSURL URLWithString:[dict objectForKey:@"agent_image"]];
    if (!ImgURl) {
        [self.img setImage:[UIImage imageNamed:@"not_found.png"]];
    }
    [self.loader startAnimating];
    [self.img sd_setImageWithURL:ImgURl placeholderImage:[UIImage imageNamed:@"not_found.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [self.img setImage:image];
        [self.loader stopAnimating];
    }];
    
    [self.lblName setText:[dict objectForKey:@"name"]];
    
    [self.lblSpeciality setText:[dict objectForKey:@"company"]];
    [self.lblScore setText:[NSString stringWithFormat:@"Score : %@",[dict objectForKey:@"totalsocre"]]];
    [self setRating:[[dict objectForKey:@"ag_rate"]integerValue]];
    
}

/*set data*/
-(void)setRating:(NSInteger)val{
    if(val<1)
        [self.starImg1 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg1 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<2)
        [self.starImg2 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg2 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    if(val<3)
        [self.starImg3 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg3 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<4)
        [self.starImg4 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg4 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<5)
        [self.starImg5 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg5 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
}

@end
