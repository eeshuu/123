//
//  CellVeiwController.h
//  Kronopress
//
//  Created by cis on 4/18/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellVeiwController : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *img;
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (strong, nonatomic) IBOutlet UILabel *lblAddress;
@property (strong, nonatomic) IBOutlet UIImageView *starImg1;
@property (strong, nonatomic) IBOutlet UIImageView *starImg2;
@property (strong, nonatomic) IBOutlet UIImageView *starImg3;
@property (strong, nonatomic) IBOutlet UIImageView *starImg4;
@property (strong, nonatomic) IBOutlet UIImageView *starImg5;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;
@property (weak, nonatomic) IBOutlet UILabel *lblPropertyType;
@property (weak, nonatomic) IBOutlet UILabel *lblRefrenceNumber;
@property (weak, nonatomic) IBOutlet UILabel *lblBedRoom;
@property (weak, nonatomic) IBOutlet UILabel *lblBathRoom;
@property (weak, nonatomic) IBOutlet UILabel *lblPrice;

-(void)setData:(NSMutableDictionary *)dict;
@end
