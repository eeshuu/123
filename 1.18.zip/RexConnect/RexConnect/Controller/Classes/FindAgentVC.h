//
//  FindAgentVC.h
//  RexConnect
//
//  Created by cis on 6/5/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EDStarRating.h"
@interface FindAgentVC : UIViewController<EDStarRatingProtocol, UIAlertViewDelegate>
@property BOOL is_rate;

@end
