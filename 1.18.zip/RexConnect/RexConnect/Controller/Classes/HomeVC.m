//
//  HomeVC.m
//  RexConnect
//
//  Created by Dheerendra chaturvedi on 15/08/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "HomeVC.h"
#import "SlideNavigationController.h"
#import "ViewController.h"
#import "FindAgentVC.h"
#import "CategoryAreaGuideVC.h"
#import "RateAnAgnetVC.h"
@interface HomeVC ()<SlideNavigationControllerDelegate>

@end

@implementation HomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
     self.slideOutAnimationEnabled = YES;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO];
    self.title=@"REX Connect";
    // Do any additional setup after loading the view, typically from a nib.
}
    
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma Mark-action
-(IBAction)btnAction:(UIButton *)sender
{
    switch (sender.tag) {
        case 1:
        {
            ViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
        }
            break;

        case 2:
        {
            FindAgentVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                         bundle: nil] instantiateViewControllerWithIdentifier: @"FindAgentVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
           
            
            
            
        }
            break;

        case 3:
        {
            CategoryAreaGuideVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil] instantiateViewControllerWithIdentifier: @"CategoryAreaGuideVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;

        case 4:
        {
            RateAnAgnetVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                           bundle: nil] instantiateViewControllerWithIdentifier: @"RateAnAgnetVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;

        default:
            break;
    }
}
@end
