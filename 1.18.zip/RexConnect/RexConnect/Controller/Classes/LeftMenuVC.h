//
//  LeftMenuVC.h
//  Kronopress
//
//  Created by cis on 4/16/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"
@interface LeftMenuVC : UIViewController
@property (nonatomic, assign) BOOL slideOutAnimationEnabled;
@end
