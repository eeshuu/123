//
//  LoginVC.m
//  Kronopress
//
//  Created by cis on 4/22/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "LoginVC.h"
#import "ApplicationManager.h"
#import "Constant.h"
#import "RegisterVC.h"
#import "LeftMenuVC.h"
#import "SlideNavigationController.h"
#import "ViewController.h"

@interface LoginVC ()
{
    BOOL iskeyboardOpen;
    CGRect originalFrame;
    UITextView *txtEmail;
}
@property (weak, nonatomic) IBOutlet UITextField *txtUserName;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnLogin;

@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    /*hide navigation controller*/
    [self.navigationController setNavigationBarHidden:YES];
    
    
 
    
    UIView *leftViewUserName=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    UIImageView *imgUserName=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"email_at.png"]];
    [imgUserName setFrame:CGRectMake(5, 5, 20, 20)];
    [imgUserName setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewUserName addSubview:imgUserName];
    _txtUserName.leftViewMode = UITextFieldViewModeAlways;

    [_txtUserName setLeftView:leftViewUserName];
    
 
    
    UIView *leftViewPassword=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    UIImageView *imgPassword=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pass_lock.png"]];
    [imgPassword setFrame:CGRectMake(5, 5, 20, 20)];
    [imgPassword setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewPassword addSubview:imgPassword];
    _txtPassword.leftViewMode = UITextFieldViewModeAlways;

 
    [_txtPassword setLeftView:leftViewPassword];
    
    /* set txtfield bottom corner*/
    [_txtPassword setBorderStyle:UITextBorderStyleNone];
    [_txtUserName setBorderStyle:UITextBorderStyleNone];
    
    iskeyboardOpen = NO;
    originalFrame = self.view.frame;
    
}
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

-(void)viewWillAppear:(BOOL)animated
{
    // Register notification when the keyboard will be show
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    // Register notification when the keyboard will be hide
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)keyboardWillShow:(NSNotification *)notification {
    
    if (!iskeyboardOpen) {
        iskeyboardOpen = YES;
        
        float height = [[notification.userInfo valueForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
        float keyBoardY = self.view.frame.size.height - height;
        float buttonY = _btnLogin.frame.origin.y+_btnLogin.frame.size.height;
        
        if (keyBoardY<buttonY) {
            float temp = buttonY - keyBoardY +10 ;
            self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y - temp, self.view.frame.size.width, self.view.frame.size.height);
        }
        
    }
    
    
    // Do something with keyboard height
}



- (void)keyboardWillHide:(NSNotification *)notification {
    
    iskeyboardOpen = NO;
    //    float height = [[notification.userInfo valueForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    //    self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y + height, self.view.frame.size.width, self.view.frame.size.height);
    self.view.frame = originalFrame;
    // Do something with keyboard height
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark-Action
-(BOOL)isValidate
{
    _txtUserName.text =[_txtUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtPassword.text =[_txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (!_txtUserName.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Valid Login User Name" andTitle:alertTitle];
        return NO;
    }
    else if (!_txtPassword.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Password" andTitle:alertTitle];
        return NO;
    }
    else if (![[ApplicationManager sharedManagerInstance]emailAddressIsValid:_txtUserName.text]) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Valid email Address" andTitle:alertTitle];
        return NO;
    }

    return true;
}
- (IBAction)loginAction:(id)sender {
    [self.view endEditing:YES];
   
    
    
    if ([self isValidate]) {
        if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
            
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];

            NSDictionary *parameters=@{@"tag":@"agentlogin",@"login_email": _txtUserName.text,@"login_pass":_txtPassword.text};

            NSString *urlStr=COMMON_URL(LONGIN_URL);
           [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:urlStr] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
                
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                if (data) {
                    if ([data[@"success"] boolValue]) {
                        
                        [[NSUserDefaults standardUserDefaults] setValue:[[data objectForKey:@"responseData"]objectForKey:@"agentlogin"] forKey:USERDEFAULT_LOGININFO];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        [AppDelegate sharedInstance].is_login=YES;
                        [[SlideNavigationController sharedInstance].leftMenu  viewDidLoad];
                        [AppDelegate sharedInstance].id_user_login=[[[data objectForKey:@"responseData"]objectForKey:@"agentlogin"] objectForKey:@"id"];
                        
                         [self.navigationController popViewControllerAnimated:YES];
//                        [AppDelegate sharedInstance].is_search=NO;
//                        ViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
//                        [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
//                                                                                 withSlideOutAnimation:nil
//                                                                                         andCompletion:nil];
                        
                    }
                    else {
                        [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                        
                    }
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
                }
                
            }];
        }
        else {
            [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
        }

    }
}
- (IBAction)btnRegister:(id)sender {
    
    RegisterVC *vc=[[UIStoryboard storyboardWithName:@"Main"
                  bundle: nil] instantiateViewControllerWithIdentifier:@"RegisterVC"];
    [self.navigationController pushViewController:vc animated:YES];
    
    
}
#pragma mark-Alert View deligate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if(alertView.tag==101)
    {
        if (buttonIndex == 1) {
            
                [self forGotPassword];
            
        }
        else{
            [alertView dismissWithClickedButtonIndex:1 animated:YES];
        }
        
    }
}

- (IBAction)forgotPassword:(id)sender {
    UIAlertView *testAlert = [[UIAlertView alloc] initWithTitle:@"Forgot Password"
                                                        message:@"Please enter email address"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"Done", nil];
    testAlert.tag=101;
    txtEmail = [UITextView new];
    [testAlert setValue:txtEmail forKey:@"accessoryView"];
    [testAlert show];
}
-(void)forGotPassword
{
    if ([[ApplicationManager sharedManagerInstance] emailAddressIsValid:txtEmail.text]) {
        if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
            
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            
            NSDictionary *parameters=@{@"tag":@"forget_pass_request",@"email": txtEmail.text};
            
            NSString *urlStr=COMMON_URL(FORGOT_PASSWORD);
            [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:urlStr] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
                
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                if (data) {
                   [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                    
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
                }
                
            }];
        }
        else {
            [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
        }
    }else{
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please fill valid email address" andTitle:alertTitle];
    }
    

}
@end
