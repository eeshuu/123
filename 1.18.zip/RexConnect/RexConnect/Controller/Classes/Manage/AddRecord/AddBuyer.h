//
//  AddBuyer.h
//  RexConnect
//
//  Created by cis on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SAMenuDropDown.h"
#import "NMRangeSlider.h"
@protocol ManageAddBuyerDeligate;
@interface AddBuyer : UIView<UITextFieldDelegate,SAMenuDropDownDelegate>{
    SAMenuDropDown *dropLocation;
    SAMenuDropDown *dropBedRoom;
    SAMenuDropDown *dropBathroom;
    NSMutableArray *arrayLocation;
    NSMutableArray *arrayBedRoom;
    NSMutableArray *arrayBathroom;
}

@property (weak, nonatomic) id <ManageAddBuyerDeligate> delegate;

@property (strong, nonatomic) IBOutlet UIButton *btnRent;
@property (strong, nonatomic) IBOutlet UIButton *btnSale;
@property (weak, nonatomic) IBOutlet UIView *middleContainer;
@property (weak, nonatomic) IBOutlet UITextField *textFrom;
@property (weak, nonatomic) IBOutlet UITextField *textTo;
@property (weak, nonatomic) IBOutlet UIButton *btnLocation;
@property (weak, nonatomic) IBOutlet UIButton *btnBedroom;
@property (weak, nonatomic) IBOutlet UILabel *lblLocation;
@property (weak, nonatomic) IBOutlet UILabel *lblBedroom;
@property (weak, nonatomic) IBOutlet UILabel *lblBathRoom;
@property (weak, nonatomic) IBOutlet UIButton *btnBathRoom;
@property (strong, nonatomic) NSString *isUpdate;


@property (strong, nonatomic) IBOutlet UIView *viewProperty;
@property (strong, nonatomic) IBOutlet UIView *viewLocation;
@property (strong, nonatomic) IBOutlet UIView *viewBedroom;
@property (strong, nonatomic) IBOutlet UIView *viewBathroom;
@property (strong, nonatomic) IBOutlet UIView *viewContainer;
@property (strong, nonatomic) IBOutlet UIView *viewPriceSlider;
@property (strong, nonatomic) IBOutlet NMRangeSlider *priceSlider;
@property (weak, nonatomic) IBOutlet UILabel *lowPrice;
@property (weak, nonatomic) IBOutlet UILabel *highPrice;

-(IBAction)customOpenBuyer;
-(IBAction)customClose:(id)sender;
- (IBAction)takeLocation:(id)sender;
- (IBAction)takeBedRoom:(id)sender;
- (IBAction)TakeBathroom:(id)sender;
@end
@protocol ManageAddBuyerDeligate <NSObject>

-(void)ManageAddBuyer:(AddBuyer *)search allData:(NSDictionary *)dictAllInfo;
@end