//
//  AddBuyer.m
//  RexConnect
//
//  Created by cis on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "AddBuyer.h"
#import "Constant.h"
#import "DoubleSlider.h"
@implementation AddBuyer
{
    DoubleSlider *slider;
}
@synthesize isUpdate;
-(id)init{
    
    self = [[[NSBundle mainBundle] loadNibNamed:@"AddBuyer" owner:nil  options:nil] lastObject];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [self setFrame:window.frame];
    [self.btnRent setSelected:YES];
    [_middleContainer.layer setCornerRadius:8];
    [_middleContainer.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_middleContainer.layer setBorderWidth:1.0f];
    [_middleContainer.layer setShadowColor:[UIColor blackColor].CGColor];
    [_middleContainer.layer setShadowOpacity:0.8];
    [_middleContainer.layer setShadowRadius:3.0];
    [_middleContainer.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    arrayLocation = [[NSMutableArray alloc]initWithObjects:@"any",@"Abu Dhabi Gate City", @"Airport Road", @"Akoya",
                     @"Al Barari",@"Al Barsha",@"Al Bateen", @"Al Falah City",
                     @"Al Furjan", @"Al Garhoud", @"Al Ghadeer",@"Al Hamra Village",
                     @"Al Karamah", @"Al Khail Heights", @"Al Khalidiya", @"Al Mamzar",
                     @"Al Manhal", @"Al Maqtaa", @"Al Markaz", @"Al Mina", @"Al Muneera",
                     @"Al Mushrif", @"Al Nahda Abu Dhabi", @"Al Nahyan",@"Al Nahyan Camp",
                     @"Al Najda Street", @"Al Nasr Street", @"Al Qurm",@"Al Qusais",
                     @"Al Raha",@"Al Raha Beach",@"Al Raha Gardens",
                     @"Al Raha Golf Gardens",@"Al Rahba",@"Al Rawdah",@"Al Reef",
                     @"Al Reem",@"Al Reem Island",@"Al Sufouh",@"Al Warqaa",@"Al Wasl",
                     @"Arabian Ranches",@"Baniyas",@"Between Two Bridges",
                     @"Business Bay",@"Corniche Area",@"Corniche Road",
                     @"Culture Village",@"Deira",@"DIFC",@"Discovery Gardens",
                     @"Downtown Burj Dubai",@"Downtown Jebel Ali",
                     @"Dubai Healthcare City",@"Dubai Investment Park",@"Dubai Marina",
                     @"Dubai Waterfront",@"Dubai World Central",@"Dubailand",
                     @"Electra Street",@"Emirates Hills",@"Festival City",@"Greens",
                     @"Hamdan Street",@"Hydra Village",@"IMPZ",@"International City",
                     @"JBR",@"Jebel Ali",@"Jumeirah",@"Jumeirah Heights",
                     @"Jumeirah Islands",@"Jumeirah Lake Towers",@"Jumeirah Park",
                     @"Jumeirah Village Circle",@"Jumeirah Village Triangle",@"Khalidia",
                     @"Khalifa City A",@"Khalifa City B",@"Lakes",@"Manama",@"Meadows",
                     @"Meydan City",@"Mirdiff",@"Mohamed Bin Zayed City",
                     @"Mohammad Bin Rashid City",@"Motor City",@"Muroor Area",@"Mushrif",
                     @"Mussafah",@"Old Town",@"Palm Jumeirah",@"Reem",@"Saadiyat Island",
                     @"Salam Street",@"Sheikh Zayed Road",@"Silicon Oasis",
                     @"Sports City",@"Springs",@"TECOM",@"The Hills",@"The Views",
                     @"The Villa",@"The World Islands",@"Tourist Club Area",
                     @"Umm Al Quwain Marina",@"Umm Ramool",@"Umm Suqueim",
                     @"Victory Heights", nil];
    
    arrayBedRoom=[[NSMutableArray alloc]initWithObjects:@"1 Bed",@"2 Bed",@"3 Bed",@"4 Bed",@"5 Bed",@"6 Bed", nil];
    arrayBathroom=[[NSMutableArray alloc]initWithObjects:@"Studio",@"1 Bathroom",@"2 Bathroom",@"3 Bathroom",@"4 Bathroom",@"5 Bathroom",@"6 Bathroom", nil];
    
    dropLocation=[[SAMenuDropDown alloc] initWithWithSource:_btnLocation menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropLocation setDelegate:self];
    [dropLocation setUpItemDataSourceWithNames:arrayLocation subtitles:nil imageNames:nil];
    
    dropBedRoom=[[SAMenuDropDown alloc] initWithWithSource:_btnBedroom menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropBedRoom setDelegate:self];
    [dropBedRoom setUpItemDataSourceWithNames:arrayBedRoom subtitles:nil imageNames:nil];
    
    dropBathroom=[[SAMenuDropDown alloc] initWithWithSource:_btnBathRoom menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropBathroom setDelegate:self];
    [dropBathroom setUpItemDataSourceWithNames:arrayBathroom subtitles:nil imageNames:nil];
    
    
    [_lblBedroom setText:[arrayBedRoom objectAtIndex:0]];
    [_lblLocation setText:[arrayLocation objectAtIndex:0]];

    
    
    _lblLocation.text = [arrayLocation objectAtIndex:0];
    _lblBedroom.text = [arrayBedRoom objectAtIndex:0];
    _lblBathRoom.text = [arrayBathroom objectAtIndex:0];
    [_btnRent setSelected:YES];
    
    
    _lblBedroom.tag=1;
    _lblBathRoom.tag=1;
    
    [_viewBathroom.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewBathroom.layer setBorderWidth:1.0f];
    [_viewBedroom.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewBedroom.layer setBorderWidth:1.0f];
    [_viewLocation.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewLocation.layer setBorderWidth:1.0f];
    [self RadioButtonAction:_btnRent];
    
    
    //    [self.priceSlider setTrackImage:[UIImage imageNamed:@"slider_track.png"]];
    //  self.priceSlider.trackBackgroundImage = [UIImage imageNamed:@"slider_track_overlay.png"];

    [self changeDiscount:nil];
    slider = [[DoubleSlider alloc]initWithFrame:CGRectMake(0, 0, _btnBathRoom.frame.size.width, _viewPriceSlider.frame.size.height) minValue:0 maxValue:1000 barHeight:10];
    if (IS_IPHONE_6) {
        slider = [[DoubleSlider alloc]initWithFrame:CGRectMake(0, 0, _btnBathRoom.frame.size.width+55, _viewPriceSlider.frame.size.height) minValue:0 maxValue:1000 barHeight:10];
    }
    
    if (IS_IPHONE_6_PLUS) {
        slider = [[DoubleSlider alloc]initWithFrame:CGRectMake(0, 0, _btnBathRoom.frame.size.width+95, _viewPriceSlider.frame.size.height) minValue:0 maxValue:1000 barHeight:10];
    }
    
    
    [slider addTarget:self action:@selector(changeDiscount:) forControlEvents:UIControlEventValueChanged];
    slider.tag = 101; //for testing purposes only
    [slider moveSlidersToPosition:[NSNumber numberWithInteger: 10]rightSlider:[NSNumber numberWithInteger: 30] animated:YES];
    [self changeDiscount:slider];
    [self.viewPriceSlider addSubview:slider];


    return self;
}

-(IBAction)customOpenBuyer
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
    self.transform = CGAffineTransformMakeScale(0, 0);
    self.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.alpha = 1;
        self.transform = CGAffineTransformMakeScale(1, 1);
    }];
}

- (IBAction)TakeBathroom:(id)sender {
    dropBathroom.hidden = NO;
    [dropBathroom self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}

-(IBAction)customClose:(id)sender
{
    
//    "tag= add_buyer
//    type=insert
//    agent_id
//    location
//    bed
//    p_type
//    price_from
//    price_to
//    agent_name"
    
    NSUserDefaults *defaultUser=[NSUserDefaults standardUserDefaults];
    NSDictionary *dictLoginInfo=[defaultUser objectForKey:USERDEFAULT_LOGININFO];
    
    
    NSDictionary *dictAllInfo =@{@"isUpdate":isUpdate,@"type":@"add_buyer",@"type":@"insert",@"location": self.lblLocation.text, @"bed": [NSString stringWithFormat:@"%ld",(long)_lblBedroom.tag], @"bathroom":[NSString stringWithFormat:@"%ld",(long)_lblBathRoom.tag], @"price_from": [NSString stringWithFormat:@"%.0f",slider.minSelectedValue*1000], @"price_to": [NSString stringWithFormat:@"%.0f",slider.maxSelectedValue*1000],@"agent_id":[dictLoginInfo objectForKey:@"id"],@"agent_name":[dictLoginInfo objectForKey:@"name"],@"p_type":([_btnRent isSelected])?@"rent":@"buy"};
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(ManageAddBuyer:allData:)])  {
        [_delegate ManageAddBuyer:self allData:(NSDictionary *)dictAllInfo];
    }
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"searchAction" object:nil];
    self.transform = CGAffineTransformMakeScale(1, 1);
    
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

- (IBAction)takeLocation:(id)sender {
    dropLocation.hidden = NO;
    [dropLocation self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}

- (IBAction)takeBedRoom:(id)sender {
    dropBedRoom.hidden = NO;
    [dropBedRoom self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}
- (IBAction)RadioButtonAction:(UIButton *)sender {
    
    if (sender == self.btnRent) {
        [self.btnRent setSelected:YES];
        [self.btnRent setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f green:133.0f/255.0f blue:128.0f/255.0f alpha:1]];
        [self.btnSale setBackgroundColor:[UIColor whiteColor]];
        [self.btnSale setSelected:NO];
    }
    else {
        [self.btnSale setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f green:133.0f/255.0f blue:128.0f/255.0f alpha:1]];
        [self.btnRent setBackgroundColor:[UIColor whiteColor]];
        [self.btnRent setSelected:NO];
        [self.btnSale setSelected:YES];
    }
}

#pragma mark - textField delegate -

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - custom delegate-

- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex{
    if (menuSender == dropLocation) {
        _lblLocation.text = [arrayLocation objectAtIndex:buttonIndex];
        dropLocation.hidden = YES;
        
    }else if (menuSender == dropBedRoom){
        _lblBedroom.text = [arrayBedRoom objectAtIndex:buttonIndex];
        dropBedRoom.hidden = YES;
    }
    else if (menuSender == dropBathroom){
        _lblBathRoom.text = [arrayBathroom objectAtIndex:buttonIndex];
        _lblBedroom.tag=buttonIndex+1;
        dropBathroom.hidden = YES;
    }
}

- (IBAction)close:(id)sender {
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}
-(IBAction)changeDiscount:(DoubleSlider *)sender
{
    [_lowPrice setText:[NSString stringWithFormat:@"AED %.0f",sender.minSelectedValue*1000]];
    [_highPrice setText:[NSString stringWithFormat:@"AED %.0f",sender.maxSelectedValue*1000]];
}

@end
