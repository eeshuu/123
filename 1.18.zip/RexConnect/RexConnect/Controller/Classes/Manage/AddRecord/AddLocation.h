//
//  AddLocation.h
//  RexConnect
//
//  Created by cis on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SAMenuDropDown.h"
@protocol ManageAddLocationDeligate;
@interface AddLocation :  UIView <UITextFieldDelegate,SAMenuDropDownDelegate>{
    SAMenuDropDown *dropLocation;
    NSMutableArray *arrayLocation;
}
@property (strong, nonatomic) IBOutlet UIView *middleContainer;

@property (weak, nonatomic) id <ManageAddLocationDeligate> delegate;
@property (strong, nonatomic) IBOutlet UIView *viewDropDownLocation;
@property (weak, nonatomic) IBOutlet UIButton *btnAgentLocation;
@property (weak, nonatomic) IBOutlet UILabel *lblAgentLocation;
@property (nonatomic, nonatomic) NSString *isUpdate;
-(IBAction)customOpen;
- (IBAction)actionClose:(id)sender;
- (IBAction)takeLocation:(id)sender;

@end
@protocol ManageAddLocationDeligate <NSObject>

-(void)ManageAddlocation:(AddLocation *)search allData:(NSDictionary *)dictAllInfo;
@end
