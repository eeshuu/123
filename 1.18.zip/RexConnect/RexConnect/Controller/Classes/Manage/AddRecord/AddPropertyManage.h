//
//  AddAgent.h
//  RexConnect
//
//  Created by cis on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SAMenuDropDown.h"

@protocol ManageAddPropertyDeligate;
@interface AddPropertyManage : UIView  <UITextFieldDelegate,SAMenuDropDownDelegate>{
    SAMenuDropDown *dropRefrenceNo;
    NSMutableArray *arrayRefrenceNo;
}

@property (weak, nonatomic) id <ManageAddPropertyDeligate> delegate;
@property (weak, nonatomic) IBOutlet UIButton *btnRefrenceNo;
@property (weak, nonatomic) IBOutlet UILabel *lblRefrenceNo;
@property (weak, nonatomic) IBOutlet UIView *middleContainer;
@property (weak, nonatomic) IBOutlet UIView *viewRef;
@property (strong, nonatomic) IBOutlet UITextField *txtDawa;
@property (strong, nonatomic) NSMutableArray *arrayRefrenceNumber;
@property (nonatomic, nonatomic) NSString *isUpdate;
-(IBAction)customOpen;
- (IBAction)actionClose:(id)sender;
-(id)init:(NSMutableArray *)refrenceArray;
@end

@protocol ManageAddPropertyDeligate <NSObject>

-(void)ManageAddproperty:(AddPropertyManage *)search allData:(NSDictionary *)dictAllInfo;
@end

