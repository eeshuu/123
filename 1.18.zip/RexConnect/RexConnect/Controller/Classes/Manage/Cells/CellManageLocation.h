//
//  CellManageLocation.h
//  RexConnect
//
//  Created by cis on 6/22/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellManageLocation : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblLocation;
-(void)setData:(NSMutableDictionary *)dict;
@end
