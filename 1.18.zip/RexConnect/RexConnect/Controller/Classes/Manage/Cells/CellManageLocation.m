//
//  CellManageLocation.m
//  RexConnect
//
//  Created by cis on 6/22/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellManageLocation.h"

@implementation CellManageLocation

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setData:(NSMutableDictionary *)dict
{
    
    [self.lblLocation setText:[NSString stringWithFormat:@"Location name : %@",([[dict objectForKey:@"location_name"] length]>0)?[dict objectForKey:@"location_name"]:@"N/A"]];
}
@end
