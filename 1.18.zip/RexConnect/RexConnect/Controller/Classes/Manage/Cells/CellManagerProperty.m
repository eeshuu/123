//
//  CellManagerProperty.m
//  RexConnect
//
//  Created by cis on 6/22/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellManagerProperty.h"

@implementation CellManagerProperty

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setData:(NSMutableDictionary *)dict
{
    
    [self.lblPropertyName setText:[NSString stringWithFormat:@"Property name : %@",@"india"]];
    [self.lblDEWA setText:[NSString stringWithFormat:@"DEWA : %@",@"123456"]];
    [self.lblRefrenceNumber setText:[NSString stringWithFormat:@"Refrence Number  : %@",@"1234566879"]];
    [self.lblType setText:[NSString stringWithFormat:@"Type : %@",@"Rent"]];
}
@end
