//
//  ManageVC.m
//  RexConnect
//
//  Created by cis on 6/22/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "ManageVC.h"
#import "Constant.h"
#import "CellManageBuyer.h"
#import "CellManageLocation.h"
#import "CellManagerProperty.h"
#import "CellAreaGuideReview.h"
#import "UIImageView+WebCache.h"
#import "AddPropertyManage.h"
#import "AddBuyer.h"
#import "AddLocation.h"
@interface ManageVC ()<ManageAddPropertyDeligate,ManageAddBuyerDeligate,ManageAddLocationDeligate>
{
    NSMutableArray *arrayBuyer;
    NSMutableArray *arrayProperties;
    NSMutableArray *arrayLocation;
    NSMutableArray *arrayRefrenceNumber;
    UITextView *txtReview;
    NSMutableDictionary *dictLoginInfo;
    NSInteger seletedIndex;
    
}
@property (strong, nonatomic) IBOutlet UITableView *tblData;
@property (strong, nonatomic) IBOutlet UISegmentedControl *segmentControl;
@property (strong, nonatomic) IBOutlet UIButton *btnAddReview;

@end

@implementation ManageVC
@synthesize indexSelectedFeature;
- (void)viewDidLoad {
    [super viewDidLoad];
   
    seletedIndex=-1;
    arrayBuyer=[[NSMutableArray alloc]init];
    arrayProperties=[[NSMutableArray alloc]init];
    arrayLocation=[[NSMutableArray alloc]init];
    
    _segmentControl.layer.borderColor=[[UIColor lightGrayColor] CGColor];
    _segmentControl.layer.cornerRadius = 0.0;
    _segmentControl.layer.borderWidth = 1.0f;
    self.segmentControl.layer.masksToBounds = YES;
   
    // Do any additional setup after loading the view.
    
    NSUserDefaults *defaultUser=[NSUserDefaults standardUserDefaults]; 
    dictLoginInfo=[defaultUser objectForKey:USERDEFAULT_LOGININFO];
    
  
    [[NSNotificationCenter defaultCenter]
     addObserver:self selector:@selector(triggerAction:) name:@"ManageVC" object:nil];
    
    
    [self segmentSelection:indexSelectedFeature];
    self.navigationController.navigationBarHidden=NO;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (indexSelectedFeature == 0) {
        return [arrayBuyer count];
    }
    else  if (indexSelectedFeature == 1) {
        return [arrayProperties count];
    }
    else  if (indexSelectedFeature == 2) {
        return [arrayLocation count];
    }
    else{
        return 0;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexSelectedFeature == 1) {
        return 80;
    }
    else if(indexSelectedFeature == 2){
        return 45;
    }
    else if(indexSelectedFeature == 0){
        return 80;
    }
    else{
        return 0;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexSelectedFeature == 0) {
        static NSString *CellIdentifier = @"CellManageBuyer";
        CellManageBuyer	*customCell = (CellManageBuyer *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (customCell == nil) {
            customCell = [[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
            [customCell setSelectionStyle:UITableViewCellSelectionStyleNone];
            [customCell setClipsToBounds:YES];
        }
        NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayBuyer objectAtIndex:indexPath.row]];
        /*set*/
        [customCell setData:dictData];
        
        return customCell;
    }
    else if(indexSelectedFeature == 1){
        static NSString *CellIdentifier = @"CellManagerProperty";
        CellManagerProperty	*customCell = (CellManagerProperty *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (customCell == nil) {
            customCell = [[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
            [customCell setSelectionStyle:UITableViewCellSelectionStyleNone];
            [customCell setClipsToBounds:YES];
        }
        NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayProperties objectAtIndex:indexPath.row]];
        /*set*/
        [customCell setData:dictData];
        
        return customCell;

    }
    else if(indexSelectedFeature == 2){
        static NSString *CellIdentifier = @"CellManageLocation";
        CellManageLocation	*customCell = (CellManageLocation *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (customCell == nil) {
            customCell = [[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil] lastObject];
            [customCell setSelectionStyle:UITableViewCellSelectionStyleNone];
            [customCell setClipsToBounds:YES];
        }
        NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayLocation objectAtIndex:indexPath.row]];
        /*set*/
        [customCell setData:dictData];
        
        return customCell;

    }
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if ([_segmentControl selectedSegmentIndex] == 1) {
//        [[ApplicationManager sharedManagerInstance]showAlert:[[arrayBuyer objectAtIndex:indexPath.row] objectForKey:@"comment"] andTitle:[NSString stringWithFormat:@"%@ Comment:",[[arrayBuyer objectAtIndex:indexPath.row] objectForKey:@"user_name"]]];
//    }
    
    
    seletedIndex=indexPath.row;
    
    UIAlertView *alert ;
    if (indexSelectedFeature == 0) {
        alert = [[UIAlertView alloc]
           initWithTitle:@"Buyer"
           message:@"What you want to do?"
           delegate:self
           cancelButtonTitle:@"Cancel"
           otherButtonTitles:@"Edit Buyer", @"Delete Buyer", nil];
        alert.tag=100;
        
    }
    else if (indexSelectedFeature == 1){
        alert = [[UIAlertView alloc]
                 initWithTitle:@"Buyer"
                 message:@"What you want to do?"
                 delegate:self
                 cancelButtonTitle:@"Cancel"
                 otherButtonTitles:@"Edit Property", @"Delete Porperty", nil];
        alert.tag=101;

    }else{
        alert = [[UIAlertView alloc]
                 initWithTitle:@"Buyer"
                 message:@"What you want to do?"
                 delegate:self
                 cancelButtonTitle:@"Cancel"
                 otherButtonTitles:@"Edit Location", @"Delete Location", nil];

        alert.tag=102;
    }
    
    
    [alert show];
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    

    if (alertView.tag==100) {
        if (buttonIndex == 1) {
            AddBuyer *buyerVC=[[AddBuyer alloc]init];
            buyerVC.isUpdate=@"true";
            [buyerVC setDelegate:self];
            [buyerVC customOpenBuyer];
        }
        else if(buttonIndex==2)
        {
            [self delete_repord:alertView.tag];
        }

    }else if(alertView.tag==101){
        if (buttonIndex == 1) {
            AddPropertyManage *propertyVC=[[AddPropertyManage alloc]init:arrayRefrenceNumber];
            propertyVC.isUpdate=@"true";
            [propertyVC setDelegate:self];
            [propertyVC customOpen];
        }
        else if(buttonIndex==2)
        {
            [self delete_repord:alertView.tag];
        }
    }else if(alertView.tag==102){
        if (buttonIndex == 1) {
            AddLocation *addLocationVC=[[AddLocation alloc]init];
            addLocationVC.isUpdate=@"true";
            [addLocationVC setDelegate:self];
            
            [addLocationVC customOpen];
        }
        else if(buttonIndex==2)
        {
            [self delete_repord:alertView.tag];
        }
    }
}


#pragma mark -Delete server data
-(void)delete_repord:(NSInteger)status
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters;
        if (status==100) {
            parameters=@{@"tag": @"add_buyer",@"type": @"delete",@"buy_p_id":[[arrayBuyer objectAtIndex:seletedIndex] objectForKey:@"buy_p_id"]};
        }else if(status==101){
            parameters=@{@"tag": @"add_property",@"type": @"delete",@"prop_id":[[arrayProperties objectAtIndex:seletedIndex] objectForKey:@"prop_id"]};
        }else{
            parameters=@{@"tag": @"add_location",@"type": @"delete",@"loc_id":[[arrayLocation objectAtIndex:seletedIndex] objectForKey:@"loc_id"]};
        }
            
        
        
        NSString *strUrl=COMMON_URL(ADD_PROPERTY);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    if (status==100) {
                        [self loadServerData_buyer];
                    }else if(status==101){
                       [self loadServerData_Property];
                    }else{
                      [self loadServerData_Location];
                    }
                   [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }

}



#pragma mark -load server data
-(void)loadServerData_buyer
{
    
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"add_buyer",@"type": @"select",@"agent_id":[AppDelegate sharedInstance].id_user_login};
        
        NSString *strUrl=COMMON_URL(ADD_PROPERTY);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    if (![[data objectForKey:@"responseData"] isKindOfClass:[NSString class]]) {
                          arrayBuyer=[[NSMutableArray alloc]initWithArray:[data objectForKey:@"responseData"]];
                    }
                    else{
                          arrayBuyer=[[NSMutableArray alloc]init];
                         [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                    }
                    
                 
                    [_tblData reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}


-(void)loadServerData_Property
{
    
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"add_property",@"type": @"select",@"agent_id":[AppDelegate sharedInstance].id_user_login};
        
        NSString *strUrl=COMMON_URL(ADD_PROPERTY);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    if (![[data objectForKey:@"responseData"] isKindOfClass:[NSString class]]) {
                        arrayProperties=[[NSMutableArray alloc]initWithArray:[data objectForKey:@"responseData"]];
                        
                        
                    }
                    else{
                        arrayProperties=[[NSMutableArray alloc]init];
                         [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                    }
                   
                    [_tblData reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}


-(void)loadServerData_Location
{
    
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"add_location",@"type": @"select",@"agent_id":[AppDelegate sharedInstance].id_user_login};
        
        NSString *strUrl=COMMON_URL(ADD_PROPERTY);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    if (![[data objectForKey:@"responseData"] isKindOfClass:[NSString class]]) {
                        arrayLocation=[[NSMutableArray alloc]initWithArray:[data objectForKey:@"responseData"]];
                    }
                    else{
                        arrayLocation=[[NSMutableArray alloc]init];
                          [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                    }
                   
                    [_tblData reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

#pragma mark -Add
-(void)Add_properties:(NSDictionary *)dict isUpdate:(NSString *)isUpadte
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        NSDictionary *parameters;
        
        if ([isUpadte boolValue]) {
            parameters=@{@"tag":@"add_property",@"agent_id": [AppDelegate sharedInstance].id_user_login,@"type":@"update",@"agent_name": [dictLoginInfo objectForKey:@"name"],@"dewa":[dict objectForKey:@"refrence_no"],@"refrence_no":[dict objectForKey:@"refrence_no"],@"prop_id":[[arrayProperties objectAtIndex:seletedIndex] objectForKey:@"prop_id"]};
        }
        else {
            parameters=@{@"tag":@"add_property",@"agent_id": [AppDelegate sharedInstance].id_user_login,@"type":@"insert",@"agent_name": [dictLoginInfo objectForKey:@"name"],@"dewa":[dict objectForKey:@"refrence_no"],@"refrence_no":[dict objectForKey:@"refrence_no"]};
        }
        
        
        
        
        NSString *strUrl=COMMON_URL(ADD_PROPERTY);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    [self loadServerData_Property] ;
                }
               [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}


-(void)Add_Buyer:(NSDictionary *)dict isUpdate:(NSString *)isUpadte
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters;
        if ([isUpadte boolValue]) {
            parameters=@{@"tag":@"add_buyer",@"agent_id": [AppDelegate sharedInstance].id_user_login,@"type":@"update",@"agent_name": [dict objectForKey:@"agent_name"],@"location":[dict objectForKey:@"location"],@"price_from":[dict objectForKey:@"price_from"],@"bed":[dict objectForKey:@"bed"],@"price_to":[dict objectForKey:@"price_to"],@"p_type":[dict objectForKey:@"p_type"],@"buy_p_id":[[arrayBuyer objectAtIndex:seletedIndex] objectForKey:@"buy_p_id"]};
        }
        else {
            parameters=@{@"tag":@"add_buyer",@"agent_id": [AppDelegate sharedInstance].id_user_login,@"type":@"insert",@"agent_name": [dict objectForKey:@"agent_name"],@"location":[dict objectForKey:@"location"],@"price_from":[dict objectForKey:@"price_from"],@"bed":[dict objectForKey:@"bed"],@"price_to":[dict objectForKey:@"price_to"],@"p_type":[dict objectForKey:@"p_type"]};
        }
        
       
        
        NSString *strUrl=COMMON_URL(ADD_PROPERTY);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    if (data) {
                        if ([data[@"success"] boolValue]) {
                            [self loadServerData_buyer] ;
                        }
                        [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                        
                    }
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

-(void)Add_Location:(NSDictionary *)dict isUpdate:(NSString *)isUpadte
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
        
        NSDictionary *parameters;
        if ([isUpadte boolValue]) {
            parameters=@{@"tag":@"add_location",@"agent_id": [AppDelegate sharedInstance].id_user_login,@"type":@"update",@"agent_name": [dictLoginInfo objectForKey:@"name"],@"location_name":[dict objectForKey:@"locationAgent"],@"loc_id":[[arrayLocation objectAtIndex:seletedIndex] objectForKey:@"loc_id"]};
        }
        else {
            parameters=@{@"tag":@"add_location",@"agent_id": [AppDelegate sharedInstance].id_user_login,@"type":@"insert",@"agent_name": [dictLoginInfo objectForKey:@"name"],@"location_name":[dict objectForKey:@"locationAgent"]};
        }

        
        
        NSString *strUrl=COMMON_URL(ADD_PROPERTY);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    if (data) {
                        if ([data[@"success"] boolValue]) {
                            [self loadServerData_Location] ;
                        }
                        [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                        
                    }
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}


#pragma mark- RefernceNumber
-(void)get_refrence_number 
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        
        NSDictionary *parameters=@{@"tag":@"get_agent_ref_no",@"login_email":[dictLoginInfo objectForKey:@"login_email"]};
        
        NSString *strUrl=COMMON_URL(REF_NUMBER);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    arrayRefrenceNumber=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"] objectForKey:@"agent_ref_no"]];
                }
                else {
                    
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}




#pragma mark -Action
- (IBAction)segmentSelection:(NSInteger)sender {
    seletedIndex=-1;
//    UIColor *selectedColor = [UIColor lightGrayColor];
//    NSDictionary *segmentedControlTextAttributes = @{NSFontAttributeName:[UIFont fontWithName:@"HelveticaNeue" size:16.0], NSForegroundColorAttributeName:[UIColor whiteColor]};
//    [self.segmentControl setTitleTextAttributes:segmentedControlTextAttributes forState:UIControlStateNormal];
//    [self.segmentControl setTitleTextAttributes:segmentedControlTextAttributes forState:UIControlStateHighlighted];
//    [self.segmentControl setTitleTextAttributes:segmentedControlTextAttributes forState:UIControlStateSelected];
    
//    for (UIControl *subview in [_segmentControl subviews]) {
//        if ([subview isSelected]){
//            [subview setTintColor:selectedColor];
//            [subview.layer setCornerRadius:0];
//        }
//        else{
//            [subview.layer setCornerRadius:5];
//        }
//    }
 
    
    if (sender ==0) {
            self.title=@"Manage Buyer";
        [self loadServerData_buyer];
    }
    else if (sender ==1)
    {
            self.title=@"Manage Property";
        [self get_refrence_number];
        [self loadServerData_Property];
    }else
    {
            self.title=@"Manage Location";
        [self loadServerData_Location];
    }
    
}

- (IBAction)btnActionAdd:(id)sender {
//    [self segmentSelection:sender];
    
    if (indexSelectedFeature ==0) {
        AddBuyer *buyerVC=[[AddBuyer alloc]init];
        buyerVC.isUpdate=@"false";
        [buyerVC setDelegate:self];
        
        [buyerVC customOpenBuyer];
    }
    else if (indexSelectedFeature ==1)
    {
        AddPropertyManage *propertyVC=[[AddPropertyManage alloc]init:arrayRefrenceNumber];
        propertyVC.isUpdate=@"false";
        [propertyVC setDelegate:self];
        
        [propertyVC customOpen];
    }else
    {
        AddLocation *addLocationVC=[[AddLocation alloc]init];
        addLocationVC.isUpdate=@"false";
        [addLocationVC setDelegate:self];
        
        [addLocationVC customOpen];
    }}
-(void)ManageAddproperty:(AddPropertyManage *)search allData:(NSDictionary *)dictAllInfo
{
    [self Add_properties:dictAllInfo isUpdate:[dictAllInfo objectForKey:@"isUpdate"]];
}
-(void)ManageAddBuyer:(AddBuyer *)search allData:(NSDictionary *)dictAllInfo
{
    [self Add_Buyer:dictAllInfo isUpdate:[dictAllInfo objectForKey:@"isUpdate"]];
}
-(void)ManageAddlocation:(AddLocation *)search allData:(NSDictionary *)dictAllInfo
{
    [self Add_Location:dictAllInfo isUpdate:[dictAllInfo objectForKey:@"isUpdate"]];
}

#pragma mark - Notification
-(void) triggerAction:(NSNotification *) notification
{
    if ([notification.object isKindOfClass:[NSString class]])
    {
        seletedIndex=-1;
        arrayBuyer=[[NSMutableArray alloc]init];
        arrayProperties=[[NSMutableArray alloc]init];
        arrayLocation=[[NSMutableArray alloc]init];
        [_tblData reloadData];
        indexSelectedFeature=[notification.object integerValue];
        [self segmentSelection:[notification.object integerValue]];
        // do stuff here with your message data
    }
    else
    {
        //  NSLog(@"Error, object not recognised.");
    }
}
@end
