//
//  MyAnnotation.m
//  Workly
//
//  Created by Nilesh on 2/17/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "MyAnnotation.h"


@implementation MyAnnotation

@synthesize title;
@synthesize subtitle;
@synthesize coordinate;

- (void)dealloc 
{
	self.title = nil;
	self.subtitle = nil;
}
@end