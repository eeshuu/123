//
//  DetailViewController.m
//  Test
//
//  Created by cis on 24/06/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "DetailViewController.h"
#import "Constant.h"
#import "UIImageView+WebCache.h"
#import "MapViewVC.h"
#import "AAShareBubbles.h"
@interface DetailViewController ()<location,AAShareBubblesDelegate>{
    NSMutableArray *arrImages;
    NSString *strLat, *strLong;
     UITextView *txtReview;
    AAShareBubbles *shareBubbles;

}

@property (weak, nonatomic) IBOutlet UIScrollView *scroll_Main;
@property (nonatomic, nonatomic) IBOutlet UIScrollView *scroll_Images;
@property (strong, nonatomic) IBOutlet UIScrollView *imgScroller;
@property (strong, nonatomic) IBOutlet UILabel *lblDescription;
@property (strong, nonatomic) IBOutlet UILabel *lblDescription2;
@property (strong, nonatomic) IBOutlet UILabel *lblType;


@property (strong, nonatomic) IBOutlet UILabel *lblEmairates;
@property (strong, nonatomic) IBOutlet UILabel *lblCommunity;
@property (strong, nonatomic) IBOutlet UILabel *lblUnitType;
@property (strong, nonatomic) IBOutlet UILabel *lblrefNo;
@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;

@property (strong, nonatomic) IBOutlet UIView *view3;
@property (strong, nonatomic) IBOutlet UIView *view4;
@property (strong, nonatomic) IBOutlet UIView *view5;
@property (strong, nonatomic) IBOutlet UIView *view6;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollViewMain;
@property (strong, nonatomic) IBOutlet UIButton *btnMap;
@property (weak, nonatomic) IBOutlet UILabel *lblBedroom;
@property (weak, nonatomic) IBOutlet UILabel *lblBathroom;
@property (weak, nonatomic) IBOutlet UILabel *lblArea;
@property (weak, nonatomic) IBOutlet UILabel *lblPropertyDetail;
@property (weak, nonatomic) IBOutlet UILabel *lblPropertyName;
@property (strong, nonatomic) IBOutlet UILabel *lblPrice;
@property (weak, nonatomic) IBOutlet UILabel *lblAddtype;
@property (weak, nonatomic) IBOutlet UILabel *lblPropertyType;
@property (weak, nonatomic) IBOutlet UILabel *lblPropertySize;


@end

@implementation DetailViewController
@synthesize dictPropertyDetail,arrayPropertyList;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title=@"Property Detail";
    
    [self.view1.layer setCornerRadius:4.0];
    self.view1.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.view1.layer.borderWidth=1.0f;
    [self.view2.layer setCornerRadius:4.0];
    self.view2.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.view2.layer.borderWidth=0.0f;
    [self.view3.layer setCornerRadius:4.0];
    self.view3.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.view3.layer.borderWidth=0.0f;
    [self.view4.layer setCornerRadius:4.0];
    self.view4.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.view4.layer.borderWidth=0.0f;
    [self.view5.layer setCornerRadius:4.0];
    self.view5.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.view5.layer.borderWidth=0.0f;
    [self.view6.layer setCornerRadius:4.0];
    self.view6.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.view6.layer.borderWidth=0.0f;
    
    
   /* [self.btnBathRoom1.layer setCornerRadius:4.0];
    self.btnBathRoom1.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.btnBathRoom1.layer.borderWidth=1.0f;
    
    [self.btnBathRoom2.layer setCornerRadius:4.0];
    self.btnBathRoom2.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.btnBathRoom2.layer.borderWidth=1.0f;
    
    [self.btnArea.layer setCornerRadius:4.0];
    self.btnArea.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.btnArea.layer.borderWidth=1.0f;*/
    
    [self.btnMap.layer setCornerRadius:4.0];
    self.btnMap.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.btnMap.layer.borderWidth=1.0f;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    
    [self setData];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark AAShareBubbles

-(void)aaShareBubbles:(AAShareBubbles *)shareBubbles tappedBubbleWithType:(int)bubbleType
{
    switch (bubbleType) {
        case AAShareBubbleTypeFacebook:
            //  NSLog(@"Facebook");
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.facebook.com"]];
            });
            break;
        case AAShareBubbleTypeTwitter:
            // Delay execution of my block for 10 seconds.
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.twitter.com"]];
            });
         
            break;
        case AAShareBubbleTypeGooglePlus:
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://plus.google.com"]];
            });
            break;
        case AAShareBubbleTypePinterest:
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                
               [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.pinterest.com"]];
            });
            break;
        case AAShareBubbleTypeVk:
            //  NSLog(@"Vkontakte (vk.com)");
            break;
        case AAShareBubbleTypeLinkedIn:
            //  NSLog(@"LinkedIn");
            break;
        case AAShareBubbleTypeYoutube:
            //  NSLog(@"Youtube");
            break;
        case AAShareBubbleTypeVimeo:
            //  NSLog(@"Vimeo");
            break;
        case AAShareBubbleTypeReddit:
            //  NSLog(@"Reddit");
            break;
        default:
            break;
    }
}

-(void)aaShareBubblesDidHide:(AAShareBubbles*)bubbles {
    //  NSLog(@"All Bubbles hidden");
}
#pragma mark-Alert View deligate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if(alertView.tag==101)
    {
        if (buttonIndex == 1) {
            
            if ([txtReview.text length]> 0) {
                [self submitReview];
            }
            else{
                [[ApplicationManager sharedManagerInstance]showAlert:@"Please Fill Review Text Before Submit. " andTitle:@"Error!"];
            }
            
        }
        else{
            [alertView dismissWithClickedButtonIndex:1 animated:YES];
        }
        
    }
}
#pragma mark-Scroll View deligate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    int pageNo = round(self.scroll_Images.contentOffset.x / self.scroll_Images.frame.size.width);
    //  NSLog(@"Page number is %i", pageNo++);
    
    [_lblPropertySize setText:[NSString stringWithFormat:@"%d of %.0f",pageNo,self.scroll_Images.contentSize.width/self.scroll_Images.frame.size.width]];
    
}

-(void)setData
{
//    "ad_type" = Rent;
//    "agent_bcd_no" = "";
//    "agent_company" = "";
//    "agent_email" = "murtaza@aquaproperties.com";
//    "agent_name" = "Aqua  Support 33";
//    "agent_phone" = "";
//    area = "280.00";
//    bathroom = 0;
//    bedroom = "";
//    community = Deira;
//    "deal_img" = "tmp_img/558d23a7994fa.jpeg";
//    emirate = Dubai;
//    id = 74;
//    image =     (
//                 "tmp_img/558d23a7994fa.jpeg",
//                 "tmp_img/558d23a825e33.jpeg",
//                 "tmp_img/558d23aa8fecd.jpeg",
//                 "tmp_img/558d23ab233b0.jpeg",
//                 "tmp_img/558d23abb2384.jpeg",
//                 "tmp_img/558d23ac40957.jpeg"
//                 );
//    latitude = "25.289606329305293";
//    longitude = "55.40403127670288";
//    "p_name" = "Al Qusais Industrial Area";
//    "p_ref_no" = "AQ-R-1032";
//    price = "50000.00";
//    "prop_title" = "Retail Shops Available for Rent in Al Qusais 4 - Deira";
//    "unit_type" = Retail;

    
    [_scrollViewMain setContentSize:CGSizeMake(self.scroll_Main.frame.size.width, self.btnMap.frame.size.height+self.btnMap.frame.origin.y+20)];
    
    
    [_lblBedroom setText:[NSString stringWithFormat:@":%@",[dictPropertyDetail objectForKey:@"bedroom"]]];
    [_lblBathroom setText:[NSString stringWithFormat:@":%@",[dictPropertyDetail objectForKey:@"bathroom"]]];
    [_lblArea setText:[NSString stringWithFormat:@":%@",[dictPropertyDetail objectForKey:@"area"]]];
    [_lblrefNo setText:[NSString stringWithFormat:@":%@",[dictPropertyDetail objectForKey:@"p_ref_no"]]];
    
    [_lblAddtype setText:[NSString stringWithFormat:@":%@",[dictPropertyDetail objectForKey:@"ad_type"]]];
    [_lblPropertyType setText:[NSString stringWithFormat:@":%@",[dictPropertyDetail objectForKey:@"unit_type"]]];
    
    
    [_lblPropertyDetail setText:[dictPropertyDetail objectForKey:@"prop_title"]];
    [_lblPropertyName setText:[dictPropertyDetail objectForKey:@"p_name"]];
    [_lblPrice setText:[NSString stringWithFormat:@"AED %@/-",[dictPropertyDetail objectForKey:@"price"]]];
    
   
    
    
    
    strLat=[dictPropertyDetail objectForKey:@"latitude"];
    strLong=[dictPropertyDetail objectForKey:@"longitude"];
//    [_lblDescription setText:[dictPropertyDetail objectForKey:@"prop_title"]];
//    [_lblDescription2 setText:[dictPropertyDetail objectForKey:@"p_name"]];
//    [_lblType setText:[dictPropertyDetail objectForKey:@"ad_type"]];
//    
//    [_lblEmairates setText:[dictPropertyDetail objectForKey:@"emirate"]];
//    [_lblCommunity setText:[dictPropertyDetail objectForKey:@"community"]];
//    [_lblUnitType setText:[dictPropertyDetail objectForKey:@"unit_type"]];
    
    
    
    
    
    
    
    
    /*fill scrollre Array*/
    arrImages = [[NSMutableArray alloc]initWithArray:[dictPropertyDetail objectForKey:@"image"]];
    
    int X = 0;

    
    for (UIImageView * view in self.scroll_Images.subviews) {
            [view removeFromSuperview];
     }
    [self.scroll_Images setContentOffset:CGPointZero];
    
    for (int i=0; i<[arrImages count]; i++) {
      
        X=([UIScreen mainScreen].bounds.size.width*i);
        UIImageView *imgView=[[UIImageView alloc]initWithFrame:CGRectMake(X, 2, [UIScreen mainScreen].bounds.size.width, self.scroll_Images.frame.size.height)];
         [imgView setBackgroundColor:[UIColor clearColor]];
//        [imgView setBackgroundColor:[UIColor redColor]];
        [imgView setImage:[UIImage imageNamed:@"no_image_found.png"]];
        [imgView setContentMode:UIViewContentModeScaleToFill];
        if (![[arrImages objectAtIndex:i] length]==0) {
             [imgView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_BASE_URL,[arrImages objectAtIndex:i]]]];
        }
        
        [imgView setContentMode:UIViewContentModeScaleToFill];
        
        [self.scroll_Images addSubview:imgView];
    }
    
    [self.scroll_Images setContentSize:CGSizeMake(X+[UIScreen mainScreen].bounds.size.width+5, self.scroll_Images.frame.size.height)];
    int pageNo = round(self.scroll_Images.contentOffset.x / self.scroll_Images.frame.size.width);
    
    [_lblPropertySize setText:[NSString stringWithFormat:@"%d OF %.0f",pageNo,self.scroll_Images.contentSize.width/self.scroll_Images.frame.size.width]];
  
}
- (IBAction)openMap:(id)sender {
    MapViewVC *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MapViewVC"];
    vc.delegate=self;
    vc.isEditable = YES;
    vc.locationForAnnotation = [[CLLocation alloc]initWithLatitude:[strLat floatValue] longitude:[strLong floatValue]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)btnReviewAction:(id)sender {
    if (![AppDelegate sharedInstance].is_login) {
        [[ApplicationManager sharedManagerInstance]showAlert:@"Please login first to submit your review" andTitle:@"Warring !"];
    }
    else{
        UIAlertView *testAlert = [[UIAlertView alloc] initWithTitle:@"Reviwer Name"
                                                            message:@"Please fill this review"
                                                           delegate:self
                                                  cancelButtonTitle:@"Cancel"
                                                  otherButtonTitles:@"Post Review", nil];
        testAlert.tag=101;
        txtReview = [UITextView new];
        [testAlert setValue:txtReview forKey:@"accessoryView"];
        [testAlert show];
    }
}

-(void)submitReview
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        NSUserDefaults *defaultUser=[NSUserDefaults standardUserDefaults];
        NSDictionary *loginInfo=[defaultUser objectForKey:USERDEFAULT_LOGININFO];
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"area_review",@"type": @"post_area_review",@"area_id": [dictPropertyDetail objectForKey:@"p_ref_no"],@"comment":[txtReview.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]],@"user_id":[loginInfo objectForKey:@"id"]};
        
        NSString *strUrl=COMMON_URL(REVIEW_GUIDE);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                [[ApplicationManager sharedManagerInstance] showAlert:@"Review Successfully Submitted." andTitle:alertTitle];
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

- (IBAction)btnShareAction:(id)sender {
    
    if(shareBubbles) {
        shareBubbles = nil;
    }
    shareBubbles = [[AAShareBubbles alloc] initWithPoint:CGPointMake(self.view.center.x, self.view.center.y-64) radius:100 inView:self.view];
    shareBubbles.delegate = self;
    shareBubbles.bubbleRadius = 40;
    shareBubbles.showFacebookBubble = YES;
    shareBubbles.showTwitterBubble = YES;
    shareBubbles.showGooglePlusBubble = YES;
    //    shareBubbles.showTumblrBubble = YES;
    //    shareBubbles.showVkBubble = YES;
    //    shareBubbles.showLinkedInBubble = YES;
    //    shareBubbles.showYoutubeBubble = YES;
    //    shareBubbles.showVimeoBubble = YES;
    //    shareBubbles.showRedditBubble = YES;
    shareBubbles.showPinterestBubble = YES;
    //    shareBubbles.showInstagramBubble = YES;
    //    shareBubbles.showWhatsappBubble = YES;
    
    
    
    [shareBubbles show];
}
- (IBAction)btnDownArrowAction:(id)sender {
        _propertyIndex++;
    if (_propertyIndex < [arrayPropertyList count]) {
    
        dictPropertyDetail=[arrayPropertyList objectAtIndex:_propertyIndex];
        [self setData];

    }
}
@end
