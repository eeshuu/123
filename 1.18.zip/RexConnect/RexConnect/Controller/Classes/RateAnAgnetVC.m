//
//  RateAnAgnetVC.m
//  RexConnect
//
//  Created by cis on 7/17/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "RateAnAgnetVC.h"
#import "CellRateAnAgent.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "EDStarRating.h"
#import "LMAlertView.h"
#import "AppDelegate.h"
@interface RateAnAgnetVC ()<EDStarRatingProtocol>
{
     NSMutableArray *arryAgent;
    NSInteger selectedIndex;
    NSInteger selectedRating;
    EDStarRating *starRating;
}
@property (weak, nonatomic) IBOutlet UITableView *_tblRateAgent;
@property (strong, nonatomic) LMAlertView *ratingAlertView;
@end

@implementation RateAnAgnetVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title=@"Rate an Agent";
    // Do any additional setup after loading the view, typically from a nib.
    
    self.navigationController.navigationBarHidden=NO;
    arryAgent=[[NSMutableArray alloc]init];
    selectedIndex=-1;
    
    
    [self loadServerData:@"any"];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}


#pragma mark-TableView deligate

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arryAgent count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellRateAnAgent *cell = [tableView dequeueReusableCellWithIdentifier:@"CellRateAnAgent"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arryAgent objectAtIndex:indexPath.row]];
    /*set*/
    [cell setData:dictData];
    UIView *bgView = [[UIView alloc] init];
    // At least on iOS6 you don't to size the view for this to work.
    bgView.backgroundColor = [UIColor colorWithRed:18.0f/255.0f green:155.0f/255.0f blue:149.0f/255.0f alpha:1];
    
        cell.btnRate.tag=indexPath.row;
    [cell.btnRate addTarget:self action:@selector(btnRateNowAction:) forControlEvents:UIControlEventTouchUpInside];
    

   
    return cell;
}



/**/
/**/
-(void)loadServerData:(NSString *)strLocation
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"find_agent",@"location_name": strLocation};
        
        NSString *strUrl=COMMON_URL(SEARCH_METHOD);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    
                    if (![[[data objectForKey:@"responseData"] objectForKey:@"agents"] isKindOfClass:[NSString class]]) {
                        arryAgent=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"agents"]];
                    }
                    else{
                        arryAgent=[[NSMutableArray alloc]init];
                    }
                    
                    [__tblRateAgent reloadData];
                    
                    if (selectedIndex < [arryAgent count] && selectedIndex > -1) {
                        [__tblRateAgent reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
                    }
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}




#pragma mark EDStarRatingProtocol delegate methods

- (void)starsSelectionChanged:(EDStarRating *)control rating:(float)rating
{
    NSString *ratingDescription;
    
    switch ([[NSNumber numberWithFloat:rating] integerValue]) {
        case 0:
            ratingDescription = @"Not yet rated";
            break;
        case 1:
            ratingDescription = @"Piss poor";
            break;
        case 2:
            ratingDescription = @"Ok I guess";
            break;
        case 3:
            ratingDescription = @"Average";
            break;
        case 4:
            ratingDescription = @"Pretty good";
            break;
        case 5:
            ratingDescription = @"Freaking amazing";
            break;
        default:
            return;
    }
    
    LMModalItemTableViewCell *cell = [self.ratingAlertView buttonCellForIndex:self.ratingAlertView.firstOtherButtonIndex];
    cell.isEnabled = (rating > 0);
    selectedRating=rating;
    self.ratingAlertView.message = ratingDescription;
    self.ratingAlertView.tag=101;
}

#pragma mark UIAlertViewDelegate delegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //  NSLog(@"%@: Clicked button at index: %li %li", [alertView class] , (long)buttonIndex,(long)alertView.tag);
    
    if (alertView.tag==101) {
        if (buttonIndex == 1) {
            [self rateCustomer];
        }
    }
}
-(void)rateCustomer
{
     //  NSLog(@"Rate Customer %ld - rating persent - %f",(long)selectedIndex,starRating.rating);
    
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
        
        NSDictionary *parameters=@{@"tag": @"agent_rating",@"agent_id": [[arryAgent objectAtIndex:selectedIndex] objectForKey:@"id"],@"rating": [NSString stringWithFormat:@"%.0f", starRating.rating*2],@"voterid": [AppDelegate sharedInstance].id_user_login};
        
        NSString *strUrl=COMMON_URL(RATING);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    
               
                    [self loadServerData:@"any"];
                }
                [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }

    
}


#pragma mark- Contact

- (IBAction)btnRateNowAction:(UIButton *)sender {
    selectedIndex=sender.tag;
    if ([AppDelegate sharedInstance].is_login) {
        //        if (self.ratingAlertView != nil) {
        //            starRating=0;
        //            [self.ratingAlertView show];
        //            return;
        //        }
        
        self.ratingAlertView = [[LMAlertView alloc] initWithTitle:@"Rate this Agent" message:@"Average" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Rate", nil];
        CGSize size = self.ratingAlertView.size;
        
        LMModalItemTableViewCell *cell = [self.ratingAlertView buttonCellForIndex: self.ratingAlertView.firstOtherButtonIndex];
        cell.isEnabled = NO;
        
        [self.ratingAlertView setSize:CGSizeMake(size.width, 152.0)];
        
        UIView *contentView = self.ratingAlertView.contentView;
        
        starRating = [[EDStarRating alloc] initWithFrame:CGRectMake((size.width/2.0 - 190.0/2.0), 55.0, 190.0, 50.0)];
        starRating.starImage = [UIImage imageNamed:@"Star-25_unfil.png"];
        starRating.starHighlightedImage = [UIImage imageNamed:@"Star-25_fill.png"];
        starRating.maxRating = 5.0;
        starRating.delegate = self;
        starRating.horizontalMargin = 12.0;
        starRating.editable = YES;
        starRating.displayMode = EDStarRatingDisplayFull;
        starRating.rating = 0;
        starRating.backgroundColor = [UIColor clearColor];
        
        [contentView addSubview:starRating];
        
        [self.ratingAlertView show];
    }
    else{
        [[ApplicationManager sharedManagerInstance]showAlert:@"Please log in before submit a Aating" andTitle:@"Message"];
    }
    
}


@end
