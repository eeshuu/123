//
//  CustomComboBox.h
//  CharityDirectory
//
//  Created by abc on 6/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//#define comboWidth 200
//#define comboHeight 35



@protocol CustomComboBoxDelegate;

@interface CustomComboBox : UIView <UITableViewDelegate, UITableViewDataSource>{
    
    UIButton *comboButton;
    UITableView *listTableView;
    NSArray *listArray;
    NSString *strTitle;
    NSInteger currentVisibleRow, previousVisibleRow;
    
    CGFloat comboCurrentExtendedHeight;
    
    CGFloat comboWidth, comboHeight;
    
    
    id<CustomComboBoxDelegate> delegate;
    
//    UIActivityIndicatorView *activity;
}

@property (retain, nonatomic) NSArray *listArray;
@property (retain, nonatomic) id<CustomComboBoxDelegate> delegate;


-(void)closeCombobox;

-(id)initWithRect:(CGRect)rect  list:(NSArray *)list;

-(void)selectItemAtIndex:(NSInteger)index;

@end

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

@protocol CustomComboBoxDelegate <NSObject>

@optional
-(void)comboBox:(CustomComboBox *)comboBox didSelectItem:(NSString *)item atIndex:(NSInteger)index;

-(void)comboBoxDidExpand:(CustomComboBox *)comboBox;

@end