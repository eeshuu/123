//
//  SearchBuyer.h
//  RexConnect
//
//  Created by Dheerendra on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SAMenuDropDown.h"
#import "SearchBuyer.h"
@protocol SearchViewBuyerDelegate;
@interface SearchBuyer : UIView<UITextFieldDelegate,SAMenuDropDownDelegate>
{
SAMenuDropDown *dropLocation;
SAMenuDropDown *dropBedRoom;
SAMenuDropDown *dropBathroom;
NSMutableArray *arrayLocation;
NSMutableArray *arrayBedRoom;
NSMutableArray *arrayBathroom;
}

@property (weak, nonatomic) id <SearchViewBuyerDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIButton *btnRent;
@property (strong, nonatomic) IBOutlet UIButton *btnSale;
@property (strong, nonatomic) IBOutlet UIView *middleContainer;

@property (weak, nonatomic) IBOutlet UIButton *btnLocation;
@property (weak, nonatomic) IBOutlet UIButton *btnBedroom;
@property (weak, nonatomic) IBOutlet UILabel *lblLocation;
@property (weak, nonatomic) IBOutlet UILabel *lblBedroom;
@property (weak, nonatomic) IBOutlet UILabel *lblBathRoom;
@property (weak, nonatomic) IBOutlet UIButton *btnBathRoom;

@property (strong, nonatomic) IBOutlet UIView *viewProperty;
@property (strong, nonatomic) IBOutlet UIView *viewLocation;
@property (strong, nonatomic) IBOutlet UIView *viewBedroom;
@property (strong, nonatomic) IBOutlet UIView *viewBathroom;
@property (strong, nonatomic) IBOutlet UIView *viewContainer;

-(IBAction)customOpen:(UIWindow *)window;
-(IBAction)customClose:(id)sender;
- (IBAction)takeLocation:(id)sender;
- (IBAction)takeBedRoom:(id)sender;
- (IBAction)TakeBathroom:(id)sender;

@end

@protocol SearchViewBuyerDelegate <NSObject>

-(void)SearchView:(SearchBuyer *)search allData:(NSDictionary *)dictAllInfo;
@end
