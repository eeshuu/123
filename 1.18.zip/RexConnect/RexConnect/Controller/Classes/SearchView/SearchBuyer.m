//
//  SearchBuyer.m
//  RexConnect
//
//  Created by Dheerendra on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "SearchBuyer.h"

@implementation SearchBuyer
-(id)init{
    
    self = [[[NSBundle mainBundle] loadNibNamed:@"SearchBuyer" owner:nil  options:nil] lastObject];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [self setFrame:window.frame];
    [self.btnRent setSelected:YES];
    

    [_middleContainer.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_middleContainer.layer setBorderWidth:1.0f];
    [_middleContainer.layer setShadowColor:[UIColor blackColor].CGColor];
    [_middleContainer.layer setShadowOpacity:0.8];
    [_middleContainer.layer setShadowRadius:3.0];
    [_middleContainer.layer setShadowOffset:CGSizeMake(2.0, 2.0)];

    
    arrayLocation = [[NSMutableArray alloc]initWithObjects:@"all",@"Abu Dhabi Gate City", @"Airport Road", @"Akoya",
                     @"Al Barari",@"Al Barsha",@"Al Bateen", @"Al Falah City",
                     @"Al Furjan", @"Al Garhoud", @"Al Ghadeer",@"Al Hamra Village",
                     @"Al Karamah", @"Al Khail Heights", @"Al Khalidiya", @"Al Mamzar",
                     @"Al Manhal", @"Al Maqtaa", @"Al Markaz", @"Al Mina", @"Al Muneera",
                     @"Al Mushrif", @"Al Nahda Abu Dhabi", @"Al Nahyan",@"Al Nahyan Camp",
                     @"Al Najda Street", @"Al Nasr Street", @"Al Qurm",@"Al Qusais",
                     @"Al Raha",@"Al Raha Beach",@"Al Raha Gardens",
                     @"Al Raha Golf Gardens",@"Al Rahba",@"Al Rawdah",@"Al Reef",
                     @"Al Reem",@"Al Reem Island",@"Al Sufouh",@"Al Warqaa",@"Al Wasl",
                     @"Arabian Ranches",@"Baniyas",@"Between Two Bridges",
                     @"Business Bay",@"Corniche Area",@"Corniche Road",
                     @"Culture Village",@"Deira",@"DIFC",@"Discovery Gardens",
                     @"Downtown Burj Dubai",@"Downtown Jebel Ali",
                     @"Dubai Healthcare City",@"Dubai Investment Park",@"Dubai Marina",
                     @"Dubai Waterfront",@"Dubai World Central",@"Dubailand",
                     @"Electra Street",@"Emirates Hills",@"Festival City",@"Greens",
                     @"Hamdan Street",@"Hydra Village",@"IMPZ",@"International City",
                     @"JBR",@"Jebel Ali",@"Jumeirah",@"Jumeirah Heights",
                     @"Jumeirah Islands",@"Jumeirah Lake Towers",@"Jumeirah Park",
                     @"Jumeirah Village Circle",@"Jumeirah Village Triangle",@"Khalidia",
                     @"Khalifa City A",@"Khalifa City B",@"Lakes",@"Manama",@"Meadows",
                     @"Meydan City",@"Mirdiff",@"Mohamed Bin Zayed City",
                     @"Mohammad Bin Rashid City",@"Motor City",@"Muroor Area",@"Mushrif",
                     @"Mussafah",@"Old Town",@"Palm Jumeirah",@"Reem",@"Saadiyat Island",
                     @"Salam Street",@"Sheikh Zayed Road",@"Silicon Oasis",
                     @"Sports City",@"Springs",@"TECOM",@"The Hills",@"The Views",
                     @"The Villa",@"The World Islands",@"Tourist Club Area",
                     @"Umm Al Quwain Marina",@"Umm Ramool",@"Umm Suqueim",
                     @"Victory Heights", nil];
    
    arrayBedRoom=[[NSMutableArray alloc]initWithObjects:@"1 bed",@"2 bed",@"3 bed",@"4 bed",@"5 bed",@"6 bed",@"Studio", nil];
    arrayBathroom=[[NSMutableArray alloc]initWithObjects:nil];
    dropLocation=[[SAMenuDropDown alloc] initWithWithSource:_btnLocation menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropLocation setDelegate:self];
    [dropLocation setUpItemDataSourceWithNames:arrayLocation subtitles:nil imageNames:nil];
    
    dropBedRoom=[[SAMenuDropDown alloc] initWithWithSource:_btnBedroom menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropBedRoom setDelegate:self];
    [dropBedRoom setUpItemDataSourceWithNames:arrayBedRoom subtitles:nil imageNames:nil];
    
    dropBathroom=[[SAMenuDropDown alloc] initWithWithSource:_btnBathRoom menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropBathroom setDelegate:self];
    [dropBathroom setUpItemDataSourceWithNames:arrayBathroom subtitles:nil imageNames:nil];
    
    _lblLocation.text = [arrayLocation objectAtIndex:0];
    _lblBedroom.text = [arrayBedRoom objectAtIndex:0];
//    _lblBathRoom.text = [arrayBathroom objectAtIndex:0];
    
    [_btnRent setSelected:YES];

    [self RadioButtonAction:_btnRent];
    
    
    [_viewBathroom.layer setBorderColor:[[UIColor colorWithRed:172.0f/255.0f green:172.0f/255.0f blue:172.0f/255.0f alpha:1.0] CGColor]];
    [_viewBathroom.layer setBorderWidth:1.0];
    
    [_viewBedroom.layer setBorderColor:[[UIColor colorWithRed:172.0f/255.0f green:172.0f/255.0f blue:172.0f/255.0f alpha:1.0] CGColor]];
    [_viewBedroom.layer setBorderWidth:1.0];
    
    [_viewLocation.layer setBorderColor:[[UIColor colorWithRed:172.0f/255.0f green:172.0f/255.0f blue:172.0f/255.0f alpha:1.0] CGColor]];
    [_viewLocation.layer setBorderWidth:1.0];
    
    [_viewProperty.layer setBorderColor:[[UIColor colorWithRed:172.0f/255.0f green:172.0f/255.0f blue:172.0f/255.0f alpha:1.0] CGColor]];
    [_viewProperty.layer setBorderWidth:1.0];
    
    
    
    
    
    [_viewBedroom.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewBedroom.layer setBorderWidth:1.0f];
    [_viewBathroom.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewBathroom.layer setBorderWidth:1.0f];
    [_viewLocation.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewLocation.layer setBorderWidth:1.0f];
    
    return self;
}


-(IBAction)customOpen:(UIWindow *)window
{
    [window addSubview:self];
    self.transform = CGAffineTransformMakeScale(0, 0);
    self.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.alpha = 1;
        self.transform = CGAffineTransformMakeScale(1, 1);
    }];
    [self updateConstraintsIfNeeded];
}

- (IBAction)TakeBathroom:(id)sender {
    dropLocation.hidden = YES;
    dropBedRoom.hidden = YES;
    dropBathroom.hidden = NO;
    [dropBathroom bringSubviewToFront:_viewContainer];
    [dropBathroom self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}

-(IBAction)customClose:(id)sender
{
    NSDictionary *dictAllInfo =@{@"type":([_btnRent isSelected])?@"rent":@"buy",@"location": self.lblLocation.text, @"bedroom": self.lblBedroom.text, @"bathroom": @""};
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(SearchView:allData:)])  {
        [_delegate  SearchView:self allData:(NSDictionary *)dictAllInfo];
    }
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"searchAction" object:nil];
    self.transform = CGAffineTransformMakeScale(1, 1);
    
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

- (IBAction)takeLocation:(id)sender {
    dropLocation.hidden = NO;
    dropBedRoom.hidden = YES;
    dropBathroom.hidden = YES;
    [dropLocation self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}

- (IBAction)takeBedRoom:(id)sender {
    dropLocation.hidden = YES;
    dropBedRoom.hidden = NO;
    dropBathroom.hidden = YES;
    [dropBedRoom self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}
- (IBAction)RadioButtonAction:(UIButton *)sender {
    
    if (sender == self.btnRent) {
        [self.btnRent setSelected:YES];
        [self.btnRent setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f green:133.0f/255.0f blue:128.0f/255.0f alpha:1]];
        [self.btnSale setBackgroundColor:[UIColor whiteColor]];
        [self.btnSale setSelected:NO];
    }
    else {
        [self.btnSale setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f green:133.0f/255.0f blue:128.0f/255.0f alpha:1]];
        [self.btnRent setBackgroundColor:[UIColor whiteColor]];
        [self.btnRent setSelected:NO];
        [self.btnSale setSelected:YES];
    }
}

#pragma mark - textField delegate -

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - custom delegate-

- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex{
    dropLocation.hidden = YES;
    dropBedRoom.hidden = YES;
    dropBathroom.hidden = YES;
    if (menuSender == dropLocation) {
        _lblLocation.text = [arrayLocation objectAtIndex:buttonIndex];
        dropLocation.hidden = YES;
        
    }else if (menuSender == dropBedRoom){
        _lblBedroom.text = [arrayBedRoom objectAtIndex:buttonIndex];
        dropBedRoom.hidden = YES;
    }
    else if (menuSender == dropBathroom){
        _lblBathRoom.text = [arrayBathroom objectAtIndex:buttonIndex];
        dropBathroom.hidden = YES;
    }
}
- (IBAction)close:(id)sender {
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}



@end
