//
//  SubCatAreaGuideVC.h
//  RexConnect
//
//  Created by cis on 6/16/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubCatAreaGuideVC : UIViewController
@property(nonatomic,retain)NSString *strCategoryID,*strCategoryName;
@end
