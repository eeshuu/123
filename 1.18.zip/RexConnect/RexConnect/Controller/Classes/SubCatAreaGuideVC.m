//
//  SubCatAreaGuideVC.m
//  RexConnect
//
//  Created by cis on 6/16/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "SubCatAreaGuideVC.h"
#import "Constant.h"
#import "AreaGuideVC.h"
#import "UIImageView+WebCache.h"
#import "CellCatTable.h"
@interface SubCatAreaGuideVC ()
{
    NSMutableArray *arraySubArea;
}
@property (strong, nonatomic) IBOutlet UITableView *tblSubArea;
@end

@implementation SubCatAreaGuideVC
@synthesize strCategoryID,strCategoryName;

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden=NO;
    self.title=strCategoryName;
    
    UIButton *backButton  = [[UIButton alloc] initWithFrame:CGRectMake(-20, 0, 44, 44)];
    ;
    
    
    [backButton setImage:[[UIImage imageNamed:@"right_menu"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
     [backButton addTarget:self action:@selector(popBack) forControlEvents:UIControlEventTouchUpInside];
    [backButton setTintColor:[UIColor whiteColor]];
    UIBarButtonItem *backButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = backButtonItem;
    
    
    arraySubArea=[[NSMutableArray alloc]init];
    [self loadServerData];
    
}

-(void) popBack {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark - UITableView Delegate & Datasrouce -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arraySubArea count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellCatTable *cell = [tableView dequeueReusableCellWithIdentifier:@"CellCatTable"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arraySubArea objectAtIndex:indexPath.row]];
    /*set*/
    [cell setData:dictData];
    
    return cell;

}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AreaGuideVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                 bundle: nil] instantiateViewControllerWithIdentifier: @"AreaGuideVC"];
    VC.strSubcat=[[arraySubArea objectAtIndex:indexPath.row] objectForKey:@"sub_cat_id"];
    [self.navigationController pushViewController:VC animated:YES];

}

#pragma mark-Action
/**/
-(void)loadServerData
{
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"subarea",@"type": @"select_subarea",@"cat_id":strCategoryID};
        
        NSString *strUrl=COMMON_URL(AREA_GUIDE);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    
                    if ([[[data objectForKey:@"responseData"]objectForKey:@"subarea"] isKindOfClass:[NSString class]]) {
                         arraySubArea=[[NSMutableArray alloc]init];
                    }
                    else{
                         arraySubArea=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"subarea"]];
                    }
                    
                   
                    [_tblSubArea reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

@end
