//
//  LMNavigationBar.h
//  LMAlertViewDemo
//
//  Created by Lee McDermott on 18/11/2013.
//  Copyright (c) 2013 Bestir Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMNavigationBar : UINavigationBar

@end
