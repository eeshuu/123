//
//  KPCommanClass.m
//  Kronopress
//
//  Created by cis on 4/17/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "KPCommanClass.h"

@implementation KPCommanClass


+ (void)putTitleToButton:(UIButton *)buttonToDecorate
                   Title:(NSString *)buttonTitle
                    font:(NSString *)titleFont
                    size:(CGFloat)titleFontSize
                   color:(UIColor *)titleTextColor{
    [buttonToDecorate setTitle:buttonTitle forState:UIControlStateNormal];
    [buttonToDecorate.titleLabel setFont:[UIFont fontWithName:titleFont size:titleFontSize]];
    [buttonToDecorate.titleLabel setTextColor:titleTextColor];
}


#pragma mark
#pragma mark Label related methods

+ (void)putTextToLabel:(UILabel *)label text:(NSString *)labelText
                  font:(NSString *)labelFontName
                  size:(CGFloat)labelFontSize color:(UIColor *)labelTextColor;
{
    if([labelText length]>0){
        [label setText:labelText];
    }
    label.textColor = labelTextColor;
    [label setFont:[UIFont fontWithName:labelFontName size:labelFontSize]];
}

#pragma mark
#pragma mark TextView related methods

+ (void)putTextToTextView:(UITextView *)textView text:(NSString *)Text
                     font:(NSString *)labelFontName
                     size:(CGFloat)labelFontSize color:(UIColor *)labelTextColor;{
    textView.textColor = labelTextColor;
    [textView setFont:[UIFont fontWithName:labelFontName size:labelFontSize]];
    [textView setText:Text];
}


+ (void)putTextToTextFiled:(UITextField *)textField placeholder:(NSString *)placeholderText
                      font:(NSString *)labelFontName
                      size:(CGFloat)labelFontSize color:(UIColor *)labelTextColor
{
    [textField setPlaceholder:placeholderText];
    textField.textColor = labelTextColor;
    [textField setFont:[UIFont fontWithName:labelFontName size:labelFontSize]];
}

#pragma mark
#pragma mark Button related methods

+ (void)putImageToButton:(UIButton *)buttonToDecorate normalStateImage:(NSString *)imageN
       pressedStateImage:(NSString *)imageP
{
    [buttonToDecorate setImage:[UIImage imageNamed:imageN] forState:UIControlStateNormal];
    [buttonToDecorate setImage:[UIImage imageNamed:imageP] forState:UIControlStateSelected];
}

@end
