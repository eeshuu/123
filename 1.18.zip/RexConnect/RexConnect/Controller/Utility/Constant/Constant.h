//
//  Constant.h
//  Kronopress
//
//  Created by cis on 4/16/15.
//  Copyright (c) 2015 cis. All rights reserved.
//
#import "KPCommanClass.h"
#import "MBProgressHUD.h"
#import "ApplicationManager.h"
#import "AppDelegate.h"
#ifndef Kronopress_Constant_h
#define Kronopress_Constant_h

//Font Size -
#define FONT_10 10.0
#define FONT_11 11.0
#define FONT_12 12.0
#define FONT_13 13.0
#define FONT_14 14.0
#define FONT_15 15.0
#define FONT_16 16.0
#define FONT_17 17.0
#define FONT_18 18.0
#define FONT_19 19.0
#define FONT_20 20.0
#define FONT_22 22.0
#define FONT_23 23.0
#define FONT_24 24.0
#define FONT_25 25.0
#define FONT_26 26.0

//Color -
#define COLOR_RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define COLOR_LIGHT_GREY_RGB [UIColor colorWithRed:131.0/255.0 green:131.0/255.0 blue:131.0/255.0 alpha:1]


#define FONT_G_BLACK         @"Gotham-Black"
#define FONT_G_BOOK          @"Gotham-Book"
#define FONT_G_BOLD          @"Gotham-Bold"
#define FONT_G_LIGHT         @"Gotham-Light"
#define FONT_G_MEDIUM        @"Gotham-Medium"
#define FONT_G_THIN          @"Gotham-Thin"
#define FONT_G_XLIGHT        @"Gotham-XLight"
#define FONT_G_NARROW_MEDIUM @"GothamNarrow-Medium"
#define FONT_G_NARROW_THIN   @"GothamNarrow-Thin"
#define FONT_RAAVI_NORMAL    @"Raavib"
#define FONT_RAAVI_BOLD      @"Raavi"

#define IS_IPHONE_5      ([UIScreen mainScreen].bounds.size.height == 568)
#define IS_IPHONE_6      ([UIScreen mainScreen].bounds.size.height == 667)
#define IS_IPHONE_6_PLUS ([UIScreen mainScreen].bounds.size.height == 736)
/*storage*/
#define USERDEFAULT_LOGININFO @"loginInfo"



#define networkNotConnected @"Internet connection not found, please make sure that you are connected with internet"
#define serverNotResponding @"Request fail, Server is down"
#define alertTitle @"Message"

#define SEARCH_METHOD @"ws_search_prop.php"
#define AREA_GUIDE @"ws_areaguide.php"
#define REVIEW_GUIDE @"ws_review_system.php"
#define LONGIN_URL @"ws_login.php"
#define ADD_PROPERTY @"ws_addproperty.php"
#define IMAGE_BASE_URL @"http://rexconnect.ae/"
#define AGENT_PROPERTY_DETAIL @"list_prop_agent.php"
#define REF_NUMBER @"ws_ref_no.php"
#define FORGOT_PASSWORD @"ws_forget_pass.php"
#define RATING @"ws_agent_rating.php"
#define COMET_CHAT_URL @"http://rexconnect.ae/cometchat/"

#define USER_PREF [NSUserDefaults standardUserDefaults]
//#define COMMON_URL(str) [NSString stringWithFormat:@"http://rgpvhelp.com/test/webservice/%@",str];
#define COMMON_URL(str) [NSString stringWithFormat:@"http://rexconnect.ae/webservice/%@",str];


#endif
