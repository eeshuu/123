//
//  BlankVC.h
//  RexConnect
//
//  Created by Dheerendra chaturvedi on 08/09/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlankVC : UIViewController

@end
