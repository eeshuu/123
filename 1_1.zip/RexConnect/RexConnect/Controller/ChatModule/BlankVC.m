//
//  BlankVC.m
//  RexConnect
//
//  Created by Dheerendra chaturvedi on 08/09/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "BlankVC.h"
#import "MainViewController.h"
@interface BlankVC ()

@end

@implementation BlankVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    MainViewController *vc=[self.storyboard instantiateViewControllerWithIdentifier:@"mainviewcontroller"];
    
    [self.navigationController pushViewController:vc animated:NO];
    vc=nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
