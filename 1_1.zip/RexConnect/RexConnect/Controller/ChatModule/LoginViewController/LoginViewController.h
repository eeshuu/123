//
//  LoginViewController.h
//  SDKTestApp
//
//  Created by Inscripts on 18/06/15.
//  Copyright (c) 2015 inscripts. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CometChatSDK/CometChat.h>

@interface LoginViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIView *urlWrapperView;
@property (weak, nonatomic) IBOutlet UIView *loginOptionsView;
@property (weak, nonatomic) IBOutlet UIView *userIDLoginView;
@property (weak, nonatomic) IBOutlet UIView *usernameLoginView;
@property (weak, nonatomic) IBOutlet UIView *guestLoginView;


@property (weak, nonatomic) IBOutlet UITextField *urlTextField;
@property (weak, nonatomic) IBOutlet UITextField *userIDTextField;
@property (weak, nonatomic) IBOutlet UITextField *usernameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UITextField *guestNameTextField;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@property IBOutletCollection(UIButton) NSArray *controlButtons;
@property (weak, nonatomic) IBOutlet UILabel *loginWithLabel;
@property (weak, nonatomic) IBOutlet UITextView *noteLabel;

- (IBAction)handleOptionClick:(id)sender;
- (IBAction)next:(id)sender;
- (IBAction)login:(id)sender;
@end
