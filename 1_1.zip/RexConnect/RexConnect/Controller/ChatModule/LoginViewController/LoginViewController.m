//
//  LoginViewController.m
//  SDKTestApp
//
//  Created by Inscripts on 18/06/15.
//  Copyright (c) 2015 inscripts. All rights reserved.
//

#import "LoginViewController.h"
#import "NativeKeys.h"
#import "MainViewController.h"
#import "Constant.h"
@interface LoginViewController () {
    
    CometChat *cometChat;
    BOOL loginFlag;
    UIBarButtonItem *backButton;
}

@end

@implementation LoginViewController
@synthesize urlTextField,userIDTextField,urlWrapperView,loginOptionsView,userIDLoginView,usernameLoginView,guestLoginView,usernameTextField,passwordTextField,guestNameTextField;
@synthesize activityIndicator;
@synthesize controlButtons;
@synthesize noteLabel,loginWithLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //Initialize Variables
    
    cometChat = [[CometChat alloc] init];
    loginFlag = NO;
    [activityIndicator setHidden:YES];
    self.navigationController.navigationBarHidden=NO;
    /* Remove default Back button */
    self.navigationItem.hidesBackButton = YES;
    backButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back-25"] style:UIBarButtonItemStylePlain target:self action:@selector(handleBackButton)];
    
    //Settings for buttons
    for (UIButton *button in controlButtons) {
        
        [button setBackgroundColor:[UIColor colorWithRed:235.0f/255.0f green:235.0f/255.0f blue:235.0f/255.0f alpha:1.0f]];
//        [button setTitleColor:[UIColor colorWithRed:0.0f/255.0f green:0.0f/255.0f blue:100.0f/255.0f alpha:0.7f] forState:UIControlStateNormal];
        
        [button setTitleColor:[UIColor colorWithRed:49.0f/255.0f green:140.0f/255.0f blue:231.0f/255.0f alpha:1.0f] forState:UIControlStateNormal];
        
        [button setTitleColor:[UIColor colorWithRed:60.0f/255.0f green:160.0f/255.0f blue:236.0f/255.0f alpha:0.7f] forState:UIControlStateNormal];
        button.layer.cornerRadius = 5; // this value vary as per your desire
        button.clipsToBounds = YES;
    }
    
    //Set Development Mode to YES to log request and response params.
    [CometChat setDevelopmentMode:NO];
    
    NSLog(@"SDK Version is %@",[CometChat getSDKVersion]);
    
    //Check if user has previously logged-in. If LOGIN_DETAILS is found in NSUserDefaults then the user is logged-in.
    if ([[NSUserDefaults standardUserDefaults] objectForKey:LOGIN_DETAILS]) {
        
        //You have to always call CometChat login before subscribing
        
        loginFlag = YES;
       
        
        switch ([[[[NSUserDefaults standardUserDefaults] objectForKey:LOGIN_DETAILS] objectAtIndex:0] integerValue]) {
                
            case 1: {
                
                //Login using UserID
                [cometChat loginWithURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"websiteURL"]] userID:[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] objectForKey:LOGIN_DETAILS] objectAtIndex:1]] success:^(NSDictionary *response) {
                    
                    NSLog(@"SDK log : UserID Login Success %@",response);
                    
                    [self handleLogin];
                    
                } failure:^(NSError *error) {
                    
                    NSLog(@"SDK log : UserID Login Error%@",error);
                    [self handleLoginError:@[@1,error]];
                    
                }];
            }
                break;
                
            case 2: {
                
                //Login using Username & Password
                [cometChat loginWithURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"websiteURL"]] username:[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] objectForKey:LOGIN_DETAILS] objectAtIndex:1]] password:[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] objectForKey:LOGIN_DETAILS] objectAtIndex:2]] success:^(NSDictionary *response) {
                    
                    NSLog(@"SDK log : Username/Password Login Success %@",response);
                    
                    [self handleLogin];
                    
                    
                } failure:^(NSError *error) {
                    NSLog(@"SDK log : Username/Password Login Error%@",error);
                    [self handleLoginError:@[@1,error]];
                    
                }];
                
            }
                break;
                
            case 3: {
                //Guest Login
                
                /* You don't need to call login again if you have logged in as guest, because if you call login again with guest then you will be recognized as different user by CometChat.
                 This is an exception for Guest Login */
                
                [self handleLogin];
            }
                break;
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    self.navigationItem.title = @"Login View";
    
    if (loginFlag) {
        
        [self.navigationController setNavigationBarHidden:YES];
        [userIDLoginView setHidden:YES];
        [usernameLoginView setHidden:YES];
        [guestLoginView setHidden:YES];
        [loginOptionsView setHidden:YES];
        [loginWithLabel setHidden:YES];
        [noteLabel setHidden:YES];
        [urlWrapperView setHidden:YES];
        
        [self startLoader];
        
    } else {
        
        [self.navigationController setNavigationBarHidden:NO];
        self.navigationItem.leftBarButtonItem = nil;
        
        [usernameLoginView setHidden:YES];
        [guestLoginView setHidden:YES];
        [loginOptionsView setHidden:YES];
        [loginWithLabel setHidden:YES];
        [noteLabel setHidden:YES];
        [urlWrapperView setHidden:NO];
    }
//    [self next:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    //LoginViewController will disappear only when login is successfull. Thus, reset the flag
    loginFlag = NO;
}
#pragma mark - Private Methods

- (void)handleBackButton {
    
    if (loginOptionsView.hidden == NO) {
        
        [loginOptionsView setHidden:YES];
        [loginWithLabel setHidden:YES];
        [noteLabel setHidden:YES];
        [urlWrapperView setHidden:NO];
        self.navigationItem.leftBarButtonItem = nil;
        
    } else if (userIDLoginView.hidden == NO) {
        
        [userIDLoginView setHidden:YES];
        [loginOptionsView setHidden:NO];
        [loginWithLabel setHidden:NO];
        [noteLabel setHidden:NO];
        
    } else if (usernameLoginView.hidden == NO) {
        
        [usernameLoginView setHidden:YES];
        [loginOptionsView setHidden:NO];
        [loginWithLabel setHidden:NO];
        [noteLabel setHidden:NO];
        
    } else if (guestLoginView.hidden == NO) {
        
        [guestLoginView setHidden:YES];
        [loginOptionsView setHidden:NO];
        [loginWithLabel setHidden:NO];
        [noteLabel setHidden:NO];
    }
}

- (void)showAlertWithTitle:(NSString *)title messageString:(NSString *)message {
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:message
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
    alertView = nil;
    
    
}

- (void)handleLogin {
    
    /* Handle Login success event in this block */
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Success"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"com.sdkdemo.logsview.refreshLogs" object:nil];
    
    MainViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"mainviewcontroller"];
    [self.navigationController pushViewController:viewController animated:YES];
    viewController = nil;
    
    [self stopLoader];
}

- (void)handleLoginError:(NSArray *)array {
    
    [self stopLoader];
    
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Failure"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"com.sdkdemo.logsview.refreshLogs" object:nil];
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGIN_DETAILS];
    
    NSString *message = @"Error message";
    
    switch ([[array objectAtIndex:1] code]) {
        case 10:
            message = [NSString stringWithFormat:@"Please check your internet connection"];
            break;
        case 11:
            message = [NSString stringWithFormat:@"Error in connection"];
            break;
        case 20:
            message = [NSString stringWithFormat:@"Plsease check username or password"];
            break;
        case 21:
            message = [NSString stringWithFormat:@"Invalid user details"];
            break;
        case 22:
            message = [NSString stringWithFormat:@"Invalid URL"];
            break;
        case 23:
            message = [NSString stringWithFormat:@"CometChat needs to be upgraded on the site"];
        case 24:
            message = [NSString stringWithFormat:@"Invalid credentials OR Server not configured. Please contact the administrator"];
            break;
    }
    
    [self showAlertWithTitle:@"" messageString:message];
    
    if ([[array objectAtIndex:0] isEqualToNumber:@1]) {
        [self.navigationController setNavigationBarHidden:NO];
        
        [usernameLoginView setHidden:YES];
        [guestLoginView setHidden:YES];
        [loginOptionsView setHidden:YES];
        [loginWithLabel setHidden:YES];
        [noteLabel setHidden:YES];
        [urlWrapperView setHidden:NO];
    }
    
    message = nil;
}

- (void)startLoader {
    
    [activityIndicator setHidden:NO];
    [activityIndicator startAnimating];
}

- (void)stopLoader {
    
    [activityIndicator setHidden:YES];
    [activityIndicator stopAnimating];
}

#pragma mark - UITextFieldDelegate Methods
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - IBAction Methods

- (IBAction)next:(id)sender {
    
    [self textFieldShouldReturn:urlTextField];
    self.urlTextField.text=COMET_CHAT_URL;
    if ([self.urlTextField.text isEqualToString:@""]) {
        
        [self showAlertWithTitle:@"" messageString:@"Enter Website URL"];
        [self showAlertWithTitle:@"" messageString:@"Enter API Key"];
        
    } else {
        
        [[NSUserDefaults standardUserDefaults] setObject:self.urlTextField.text forKey:@"websiteURL"];        
        
         cometChat = [[CometChat alloc] init];
        
        [urlWrapperView setHidden:YES];
        [loginOptionsView setHidden:NO];
        [loginWithLabel setHidden:NO];
        [noteLabel setHidden:NO];
        self.navigationItem.leftBarButtonItem = backButton;
    }
}

- (IBAction)login:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    switch (button.tag) {
        case 1:
            [self textFieldShouldReturn:userIDTextField];
            if ([userIDTextField.text isEqualToString:@""]) {
                
                [self showAlertWithTitle:@"" messageString:@"UserID cannot be empty"];
                
            } else {
                
                
                [button setUserInteractionEnabled:NO];
                
                [self startLoader];
                
                [cometChat loginWithURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"websiteURL"]] userID:[NSString stringWithFormat:@"%@",userIDTextField.text] success:^(NSDictionary *response) {
                    
                    NSLog(@"SDK log : UserID Login Success %@",response);
                    
                    [button setUserInteractionEnabled:YES];
                    [self handleLogin];
                    
                    [[NSUserDefaults standardUserDefaults] setObject:@[LOGIN_TYPE_USERID,[NSString stringWithFormat:@"%@",userIDTextField.text]] forKey:LOGIN_DETAILS];
                    
                } failure:^(NSError *error) {
                    
                    NSLog(@"SDK log : UserID Login Error%@",error);
                    
                    [button setUserInteractionEnabled:YES];
                    [self handleLoginError:@[@0,error]];
                    
                }];
            }
            
            break;
            
        case 2:
            [self textFieldShouldReturn:passwordTextField];
            if ([usernameTextField.text isEqualToString:@""]) {
                
                [self showAlertWithTitle:@"" messageString:@"Username cannot be empty"];
                
            } else if ([passwordTextField.text isEqualToString:@""]) {
                
                [self showAlertWithTitle:@"" messageString:@"Password cannot be empty"];
                
            } else {
                
                
                [button setUserInteractionEnabled:NO];
                
                [self startLoader];
                
                [cometChat loginWithURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"websiteURL"]] username:usernameTextField.text password:passwordTextField.text success:^(NSDictionary *response) {
                    
                    NSLog(@"SDK log : Username/Password Login Success %@",response);
                    
                    [button setUserInteractionEnabled:YES];
                    [self handleLogin];
                    
                    [[NSUserDefaults standardUserDefaults] setObject:@[LOGIN_TYPE_USERNAME,usernameTextField.text,passwordTextField.text] forKey:LOGIN_DETAILS];
                    
                } failure:^ (NSError *error) {
                    
                    NSLog(@"SDK log : Username/Password Login Error%@",error);
                    
                    [button setUserInteractionEnabled:YES];
                    [self handleLoginError:@[@0,error]];
                    
                }];

            }
            
            break;
        case 3:
            [self textFieldShouldReturn:guestNameTextField];
            if ([guestNameTextField.text isEqualToString:@""]) {
                
                [self showAlertWithTitle:@"" messageString:@"Guest name cannot be empty"];
                
            } else {
                
                
                [button setUserInteractionEnabled:NO];
                
                [self startLoader];
                
                [cometChat guestLoginWithURL:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"websiteURL"]] name:guestNameTextField.text success:^(NSDictionary *response) {
                    
                    NSLog(@"SDK log : Guest Login Success %@",response);
                    
                    [button setUserInteractionEnabled:YES];
                    [self handleLogin];
                    
                    [[NSUserDefaults standardUserDefaults] setObject:@[LOGIN_TYPE_GUEST,guestNameTextField.text] forKey:LOGIN_DETAILS];
                    
                } failure:^(NSError *error) {
                    
                    NSLog(@"SDK log : Guest Login Error%@",error);
                    
                    [button setUserInteractionEnabled:YES];
                    [self handleLoginError:@[@0,error]];
                    
                }];
            }
            
            break;
    }
    
    button = nil;
}

//Show different login options
- (IBAction)handleOptionClick:(id)sender {
    
    [loginOptionsView setHidden:YES];
    [loginWithLabel setHidden:YES];
    [noteLabel setHidden:YES];
    
    if(!self.navigationItem.leftBarButtonItem) {
        
        self.navigationItem.leftBarButtonItem = backButton;
    }
    
    UIButton *button = (UIButton *)sender;
    
    switch (button.tag) {
            
        case 1:
            
            [userIDLoginView setHidden:NO];
            
            break;
            
        case 2:
            
            [usernameLoginView setHidden:NO];
            
            break;
            
        case 3:
            
            [guestLoginView setHidden:NO];
            
            break;
            
    }
    
    button = nil;
}

@end
