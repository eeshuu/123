//
//  AgentDetailVC.m
//  RexConnect
//
//  Created by cis on 6/20/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "AgentDetailVC.h"
#import "UIImageView+WebCache.h"
#import "ApplicationManager.h"
#import "KLCPopup.h"
#import "Constant.h"
#import "CellAgentDetail.h"
#import "DetailViewController.h"
#import "LMAlertView.h"
#import "EDStarRating.h"
@interface AgentDetailVC ()
{
    NSMutableArray *arrayPropertyDetail;
    EDStarRating *starRating;
}
@property (strong, nonatomic) IBOutlet UIImageView *imgProfile;
@property (strong, nonatomic) IBOutlet UILabel *lblContactInfo;
@property (strong, nonatomic) IBOutlet UILabel *lblPhoneNumber;
@property (strong, nonatomic) IBOutlet UILabel *lblCompanyName;
@property (strong, nonatomic) IBOutlet UILabel *lblEmailAddres;
@property (strong, nonatomic) IBOutlet UILabel *lblBrokerNumber;
@property (strong, nonatomic) IBOutlet UIImageView *star1;
@property (strong, nonatomic) IBOutlet UIImageView *star2;
@property (strong, nonatomic) IBOutlet UIImageView *star3;
@property (strong, nonatomic) IBOutlet UIImageView *star4;
@property (strong, nonatomic) IBOutlet UIImageView *star5;
@property (strong, nonatomic) IBOutlet UIButton *lblMessage;
@property (strong, nonatomic) IBOutlet UITableView *tblProperty;
@property (strong, nonatomic) IBOutlet UILabel *lblScore;

@property (strong, nonatomic) IBOutlet UILabel *lblFeedbackPercent;
@property (strong, nonatomic) IBOutlet UILabel *lblPositive;
@property (strong, nonatomic) IBOutlet UILabel *lblNeutral;
@property (strong, nonatomic) IBOutlet UILabel *lblNegative;
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (strong, nonatomic) LMAlertView *ratingAlertView;




@end

@implementation AgentDetailVC
@synthesize dictDetail;
- (void)viewDidLoad {
    [super viewDidLoad];
     self.title=@"Agent Detail";
    // Do any additional setup after loading the view.
    self.imgProfile.layer.borderColor=[[UIColor grayColor] CGColor];
    self.imgProfile.layer.borderWidth=1.0f;
    
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setUpImageBackButton];
}
-(void)viewDidAppear:(BOOL)animated
{
    [self.imgProfile setImage:[UIImage imageNamed:@"placeHolder"]];
    [self.imgProfile.layer setCornerRadius:self.imgProfile.frame.size.height/2];
    [self fillAgentDetail];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)setUpImageBackButton
{
    self.navigationController.navigationBarHidden=NO;
    self.navigationController.navigationItem.hidesBackButton=YES;
    UIButton *button  = [[UIButton alloc] initWithFrame:CGRectMake(-20, 0, 44, 44)];
    ;
    [button setImage:[[UIImage imageNamed:@"right_menu"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [button setTintColor:[UIColor whiteColor]];
    UIBarButtonItem *barBackButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    [button addTarget:self action:@selector(popCurrentViewController) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = barBackButtonItem;
    self.navigationItem.hidesBackButton = YES;
}
-(void)popCurrentViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayPropertyDetail count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellAgentDetail *cell = [tableView dequeueReusableCellWithIdentifier:@"CellAgentDetail"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayPropertyDetail objectAtIndex:indexPath.row]];
    /*set*/
    [cell setData:dictData];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailViewController *vc=[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:[NSBundle mainBundle]];
    vc.dictPropertyDetail=[arrayPropertyDetail objectAtIndex:indexPath.row];
    vc.arrayPropertyList=arrayPropertyDetail;
    vc.propertyIndex=indexPath.row;
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark-Action
-(void)fillAgentDetail
{
    strPhoneNumber = [dictDetail objectForKey:@"phone"];
    strEmail = [dictDetail objectForKey:@"email"];
    ;
//    [self loadServerData:[dictDetail objectForKey:@"id"]];
    
    NSURL *imgURL=[NSURL URLWithString:[dictDetail objectForKey:@"agent_image"]];
    if (!imgURL) {
        [self.imgProfile setImage:[UIImage imageNamed:@"not_found.png"]];
    }
    [self.imgProfile sd_setImageWithURL:imgURL placeholderImage:[UIImage imageNamed:@"not_found.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [self.imgProfile setImage:image];
    }];

    /*get persent*/
    NSInteger persent=[[dictDetail objectForKey:@"ag_rate"] integerValue];
    if (persent>0) {
        persent=persent*100/10;
        persent=persent/20;
        [self setRating:persent];
    }
    
    [self.lblPositive setText:[NSString stringWithFormat:@"%@",[dictDetail objectForKey:@"positive"]]];
    
    [self.lblNegative setText:[NSString stringWithFormat:@"%@",[dictDetail objectForKey:@"negative"]]];
    [self.lblNeutral setText:[NSString stringWithFormat:@"%@",[dictDetail objectForKey:@"nutral"]]];
    [self.lblFeedbackPercent setText:[NSString stringWithFormat:@"%.2f",[[dictDetail objectForKey:@"positive_feedback"] floatValue]]];
    [self.lblScore setText:[NSString stringWithFormat:@"(Score : %@)",[dictDetail objectForKey:@"totalsocre"]]];
    [self.lblName setText:[NSString stringWithFormat:@"%@",[dictDetail objectForKey:@"name"]]];
    [self.lblCompanyName setText:[NSString stringWithFormat:@"%@",[dictDetail objectForKey:@"company"]]];
}


-(void)setRating:(NSInteger)val{
    if(val<1)
        [self.star1 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star1 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<2)
        [self.star2 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star2 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    if(val<3)
        [self.star3 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star3 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<4)
        [self.star4 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star4 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<5)
        [self.star5 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star5 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
}

- (IBAction)btnMessageAction:(id)sender {
//    [self loadPopView:dictDetail andCount:3];
    
    switch (((UIButton *)sender).tag) {
        case 1000:
//            //  NSLog(@"Call");
            
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",strPhoneNumber]]];
            break;
        case 1001:
//            //  NSLog(@"chat");
//            [self sendMail:strEmail];
            break;
        case 1002:
            //  NSLog(@"Email");
           [self sendMail:strEmail];
            break;
        case 1003:
//            //  NSLog(@"Message");
            [self sendMessage];
            break;
            
        case 1004:
//            //  NSLog(@"Rating");
            [self btnRateNowAction:sender];
            break;
            
            
        default:
            break;
    }
    
    

}


-(void)loadPopView:(NSDictionary *)dict andCount:(int)buttonCount{
    
    strPhoneNumber = [dictDetail objectForKey:@"phone"];
    strEmail = [dictDetail objectForKey:@"email"];
    ;
    
    // Generate content view to present
    UIVisualEffect *blurEffect;
    blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView * contentView = [[UIVisualEffectView alloc]initWithEffect:blurEffect];
    //    UIView *contentView = [[UIView alloc]init];
    //    [contentView setBackgroundColor:[UIColor blackColor]];
    contentView.translatesAutoresizingMaskIntoConstraints = NO;
    contentView.layer.cornerRadius = 12.0;
    
    UIButton* callButton = [UIButton buttonWithType:UIButtonTypeCustom];
    callButton.translatesAutoresizingMaskIntoConstraints = NO;
    callButton.contentEdgeInsets = UIEdgeInsetsMake(10, 20, 10, 20);
    [callButton setImage:[UIImage imageNamed:@"image0.png"] forState:UIControlStateNormal];
    callButton.layer.cornerRadius = 6.0;
    callButton.tag = 1000;
    [callButton addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* messageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    messageButton.translatesAutoresizingMaskIntoConstraints = NO;
    messageButton.contentEdgeInsets = UIEdgeInsetsMake(10, 20, 10, 20);
    [messageButton setImage:[UIImage imageNamed:@"image1.png"] forState:UIControlStateNormal];
    messageButton.layer.cornerRadius = 6.0;
    messageButton.tag = 1001;
    [messageButton addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* mailButton = [UIButton buttonWithType:UIButtonTypeCustom];
    mailButton.translatesAutoresizingMaskIntoConstraints = NO;
    mailButton.contentEdgeInsets = UIEdgeInsetsMake(10, 20, 10, 20);
    [mailButton setImage:[UIImage imageNamed:@"image2.png"] forState:UIControlStateNormal];
    mailButton.layer.cornerRadius = 6.0;
    mailButton.tag = 1002;
    [mailButton addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    [contentView addSubview:callButton];
    [contentView addSubview:messageButton];
    [contentView addSubview:mailButton];
    
    NSDictionary* views = NSDictionaryOfVariableBindings(contentView, mailButton, messageButton, callButton);
    
    [contentView addConstraints:
     [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(24)-[callButton]-(10)-[messageButton]-(10)-[mailButton]-(24)-|"
                                             options:NSLayoutFormatAlignAllCenterX
                                             metrics:nil
                                               views:views]];
    
    [contentView addConstraints:
     [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(50)-[callButton]-(50)-|"
                                             options:0
                                             metrics:nil
                                               views:views]];
    
    // Show in popup
    KLCPopupLayout layout = KLCPopupLayoutMake(KLCPopupHorizontalLayoutCenter,
                                               KLCPopupVerticalLayoutCenter);
    
    KLCPopup* popup = [KLCPopup popupWithContentView:contentView
                                            showType:KLCPopupShowTypeBounceInFromTop
                                         dismissType:KLCPopupDismissTypeBounceOutToBottom
                                            maskType:KLCPopupMaskTypeDimmed
                            dismissOnBackgroundTouch:YES
                               dismissOnContentTouch:NO];
    
    [popup showWithLayout:layout];
    
    
    
    
}

- (void)dismissButtonPressed:(id)sender {
    
    if ([sender isKindOfClass:[UIView class]]) {
        [(UIView*)sender dismissPresentingPopup];
    }
    
    switch (((UIButton *)sender).tag) {
        case 1000:
//            //  NSLog(@"Call");
            
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",strPhoneNumber]]];
            break;
        case 1001:
//            //  NSLog(@"Mail");
            [self sendMail:strEmail];
            break;
        case 1002:
//            //  NSLog(@"Message");
            [self sendMessage];
            break;
        case 1003:
//            //  NSLog(@"Message");
            [self sendMessage];
            break;
            
        case 1004:
//            //  NSLog(@"Message");
            [self btnRateNowAction:sender];
            break;
            
            
        default:
            break;
    }
}
#pragma mark - MFMAILComposer

- (void) sendMail:(NSString *)receiverEmail {
    
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    controller.mailComposeDelegate = self;
    controller.delegate = self;
    [controller setSubject:@"RexConnect"];
    
    [controller setToRecipients:@[receiverEmail]];
    
    if (controller) {
        [self presentViewController:controller animated:YES completion:nil];
    }
    
}


- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    NSString *messageBody= [[NSString alloc] init];
    switch (result)
    {
        case MFMailComposeResultCancelled:
            //DLog(@"Mail cancelled: you cancelled the operation and no email message was queued.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"You cancelled sending message";
            break;
            
        case MFMailComposeResultSaved:
            //DLog(@"Mail saved: you saved the email message in the drafts folder.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail saved: you saved the email message in the drafts folder'";
            break;
            
        case MFMailComposeResultSent:
            //DLog(@"Mail send: the email message is queued in the outbox. It is ready to send.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail has been sent";
            [self mailSent];
            break;
            
        case MFMailComposeResultFailed:
            //DLog(@"Mail failed: the email message was not saved or queued, possibly due to an error.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Email sending failed";
            break;
            
        default:
            //DLog(@"Mail not sent.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            break;
    }
    
    
}

- (void) mailSent
{
    //showing an alert for success
    [[ApplicationManager sharedManagerInstance] showAlert:@"Mail Sent Successfully." andTitle:@"Message"];
    
}

- (void) sendMessage{
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {
        controller.body =@"RexConnect";
        controller.recipients = @[strPhoneNumber];
        controller.messageComposeDelegate = self;
        [self presentViewController:controller animated:YES completion:nil];
    }
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    [self dismissViewControllerAnimated:YES completion:nil];
    switch (result) {
        case MessageComposeResultCancelled:
            [self.navigationController popViewControllerAnimated:YES];
            break;
            
        case MessageComposeResultFailed:
        {
            
            [self.navigationController popViewControllerAnimated:YES];
            break;
        }
            
        case MessageComposeResultSent:
            [self.navigationController popViewControllerAnimated:YES];
            break;
            
        default:
            [self.navigationController popViewControllerAnimated:YES];
            break;
    }
}

#pragma mark-rating
#pragma mark UIAlertViewDelegate delegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
//    //  NSLog(@"%@: Clicked button at index: %li %li", [alertView class] , (long)buttonIndex,(long)alertView.tag);
    
    if (alertView.tag==101) {
        if (buttonIndex == 1) {
            [self rateCustomer];
        }
    }
}
- (IBAction)btnRateNowAction:(UIButton *)sender {
    if ([AppDelegate sharedInstance].is_login) {
  
        self.ratingAlertView = [[LMAlertView alloc] initWithTitle:@"Rate this Agent" message:@"Average" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Rate", nil];
        CGSize size = self.ratingAlertView.size;
     
        [self.ratingAlertView setSize:CGSizeMake(size.width, 152.0)];
        
        UIView *contentView = self.ratingAlertView.contentView;
        
        starRating = [[EDStarRating alloc] initWithFrame:CGRectMake((size.width/2.0 - 190.0/2.0), 55.0, 190.0, 50.0)];
        starRating.starImage = [UIImage imageNamed:@"Star-25_unfil.png"];
        starRating.starHighlightedImage = [UIImage imageNamed:@"Star-25_fill.png"];
        starRating.maxRating = 5.0;
        starRating.delegate = self;
        starRating.horizontalMargin = 12.0;
        starRating.editable = YES;
        starRating.displayMode = EDStarRatingDisplayFull;
        starRating.rating = 0;
        starRating.backgroundColor = [UIColor clearColor];
        
        [contentView addSubview:starRating];
        [self.ratingAlertView setTag:101];
        [self.ratingAlertView show];
    }
    else{
        [[ApplicationManager sharedManagerInstance]showAlert:@"Please log in before submit a Aating" andTitle:@"Message"];
    }
    
}


-(void)rateCustomer
{
    
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        
        NSDictionary *parameters=@{@"tag": @"agent_rating",@"agent_id": [dictDetail objectForKey:@"id"],@"rating": [NSString stringWithFormat:@"%.0f", starRating.rating*2],@"voterid": [AppDelegate sharedInstance].id_user_login};
        
        NSString *strUrl=COMMON_URL(RATING);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if ([[data objectForKey:@"success"]boolValue]) {
                
                [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                
                
                dictDetail = [[data objectForKey:@"responseData"] objectForKey:@"agent_info"];
                [self fillAgentDetail];
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    
}
#pragma mark EDStarRatingProtocol delegate methods

- (void)starsSelectionChanged:(EDStarRating *)control rating:(float)rating
{
    NSString *ratingDescription;
    
    switch ([[NSNumber numberWithFloat:rating] integerValue]) {
        case 0:
            ratingDescription = @"Not yet rated";
            break;
        case 1:
            ratingDescription = @"Piss poor";
            break;
        case 2:
            ratingDescription = @"Ok I guess";
            break;
        case 3:
            ratingDescription = @"Average";
            break;
        case 4:
            ratingDescription = @"Pretty good";
            break;
        case 5:
            ratingDescription = @"Freaking amazing";
            break;
        default:
            return;
    }
    
    LMModalItemTableViewCell *cell = [self.ratingAlertView buttonCellForIndex:self.ratingAlertView.firstOtherButtonIndex];
    cell.isEnabled = (rating > 0);
    self.ratingAlertView.message = ratingDescription;
    self.ratingAlertView.tag=101;
}



@end
