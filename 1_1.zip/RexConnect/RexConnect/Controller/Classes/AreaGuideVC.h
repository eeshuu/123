//
//  AreaGuideVC.h
//  RexConnect
//
//  Created by Dheerendra on 6/14/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AreaGuideVC : UIViewController
@property(nonatomic,retain) NSString *strSubcat;
@end
