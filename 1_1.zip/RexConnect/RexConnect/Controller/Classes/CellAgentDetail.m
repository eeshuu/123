//
//  CellAgentDetail.m
//  RexConnect
//
//  Created by Dheerendra on 6/27/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellAgentDetail.h"
#import "UIImageView+WebCache.h"
#import "Constant.h"
@implementation CellAgentDetail

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
/*set data*/
-(void)setData:(NSMutableDictionary *)dict{

    NSURL *ImgURl=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_BASE_URL,[dict objectForKey:@"single_img"]]];
    [self.loader startAnimating];
    [self.imgProperty sd_setImageWithURL:ImgURl placeholderImage:[UIImage imageNamed:@"not_found.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [self.imgProperty setImage:image];
        [self.loader stopAnimating];
    }];
    
    [self.loader startAnimating];
    [self.lblHading setText:[dict objectForKey:@"prop_title"]];
    [self.lblType setText:[dict objectForKey:@"ad_type"]];
}
@end
