//
//  CellAreaGuideReview.m
//  RexConnect
//
//  Created by Dheerendra on 6/14/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellAreaGuideReview.h"
#import "UIImageView+WebCache.h"
#import "Constant.h"
@implementation CellAreaGuideReview

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


/*action*/
-(void)setData:(NSMutableDictionary *)dict
{
    
    self.lblName.text=[dict objectForKey:@"user_name"];
    self.lblMessage.text=[dict objectForKey:@"comment"];
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSDate *Date = [dateFormatter dateFromString:[dict objectForKey:@"date"]];
    dateFormatter.dateFormat = @"dd-MMM-yyyy";
    
    [_imgReviwer sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_BASE_URL,[dict objectForKey:@"user_imge"]] ]  placeholderImage:[UIImage imageNamed:@"not_found.png"]];
    
    self.lblTime.text=[dateFormatter stringFromDate:Date];
}




@end
