//
//  CellCatTable.h
//  RexConnect
//
//  Created by Dheerendra on 6/21/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellCatTable : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgCell;
@property (strong, nonatomic) IBOutlet UILabel *lblValue;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loader;
-(void)setData:(NSMutableDictionary *)dict;
@end
