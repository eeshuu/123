//
//  CellFindBuyer.m
//  RexConnect
//
//  Created by cis on 6/5/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellFindBuyer.h"
#import "Constant.h"
#import "UIImageView+WebCache.h"
@implementation CellFindBuyer

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


/*set data*/
-(void)setData:(NSMutableDictionary *)dict{
    
    [self.imgBuyer.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
     [self.imgBuyer.layer setBorderWidth:1.0f];
    _lblName.text=[dict objectForKey:@"u_name"];
    _lblDetail.text=[dict objectForKey:@"company"];
    _lblType.text=[NSString stringWithFormat:@"Has a %@ of %@ in %@",[dict objectForKey:@"p_type"],[dict objectForKey:@"bed"],[dict objectForKey:@"location"]];
    [_lblPrice setText:[NSString stringWithFormat:@"AED %@ /-",[dict objectForKey:@"price_to"]]];
    
    NSURL *ImgURl=[NSURL URLWithString:[dict objectForKey:@"agent_image"]];
    [self.loader startAnimating];
    [self.imgBuyer sd_setImageWithURL:ImgURl placeholderImage:[UIImage imageNamed:@"not_found.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [self.imgBuyer setImage:image];
        [self.loader stopAnimating];
    }];

    
    [self setRating:[[dict objectForKey:@"ag_rate"] integerValue]];
}

-(void)setRating:(NSInteger)val{
    if(val<1)
        [self.star1 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star1 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<2)
        [self.star2 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star2 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    if(val<3)
        [self.star3 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star3 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<4)
        [self.star4 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star4 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<5)
        [self.star5 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.star5 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];}
@end
