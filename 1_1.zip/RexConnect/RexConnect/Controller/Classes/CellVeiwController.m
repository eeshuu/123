//
//  CellVeiwController.m
//  Kronopress
//
//  Created by cis on 4/18/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "CellVeiwController.h"
#import "UIImageView+WebCache.h"
#import "Constant.h"
@implementation CellVeiwController
@synthesize starImg1,starImg2,starImg3,starImg4,starImg5;
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


/*set data*/
-(void)setData:(NSMutableDictionary *)dict{
 

    NSURL *ImgURl=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_BASE_URL,[dict objectForKey:@"deal_img"]]];
    [self.loader startAnimating];
    [self.img sd_setImageWithURL:ImgURl placeholderImage:[UIImage imageNamed:@"not_found.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [self.img setImage:image];
        [self.loader stopAnimating];
    }];

    
    [self.img.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
    [self.img.layer setBorderWidth:1.0f];

    
    [self.lblName setText:[dict objectForKey:@"p_name"]];
    
    [self.lblAddress setText:[dict objectForKey:@"prop_title"]];
    [self.lblPropertyType setText:[dict objectForKey:@"unit_type"]];
    
    if([[dict objectForKey:@"bedroom"] length]>0)
    {
        [self.lblBedRoom setText:[NSString stringWithFormat:@"%@ Bed",[dict objectForKey:@"bedroom"]]];

    }
    else{
        [self.lblBedRoom setText:[NSString stringWithFormat:@"%@ Bed",@"0"]];

    }
    
    
    if([[dict objectForKey:@"bedroom"] length]>0)
    {
        [self.lblBathRoom setText:[NSString stringWithFormat:@"%@ Bath",[dict objectForKey:@"bedroom"]]];
        
    }
    else{
        [self.lblBathRoom setText:[NSString stringWithFormat:@"%@ Bath",@"0"]];
        
    }
    
    [self.lblRefrenceNumber setText:[dict objectForKey:@"p_ref_no"]];
    
    [self.lblPrice setText:[NSString stringWithFormat:@"AED : %@ /-",[dict objectForKey:@"price"]]];
    
    
    
    [self setRating:4];
}

/*set data*/
-(void)setRating:(int)val{
    if(val<1)
        [self.starImg1 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg1 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<2)
        [self.starImg2 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg2 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    if(val<3)
        [self.starImg3 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg3 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<4)
        [self.starImg4 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg4 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
    
    if(val<5)
        [self.starImg5 setImage:[UIImage imageNamed:@"Star-50_unfill.png"]];
    else
        [self.starImg5 setImage:[UIImage imageNamed:@"Star-50_fill.png"]];
}



@end
