//
//  FindAgentVC.m
//  RexConnect
//
//  Created by cis on 6/5/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "FindAgentVC.h"
#import "SlideNavigationController.h"
#import "Constant.h"
#import "CellAgentList.h"
#import "AgentDetailVC.h"
#import "SearchViewAgent.h"
#import "LMAlertView.h"
#import "EDStarRating.h"
#import "AppDelegate.h"
@interface FindAgentVC ()<SearchViewAgentDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,UINavigationControllerDelegate>
{
    NSMutableArray *arryAgent;
    NSString *strPhoneNumber,*strEmail;
    NSInteger selectedIndex;
    NSInteger selectedRating;
    EDStarRating *starRating;
}
@property (weak, nonatomic) IBOutlet UITableView *tblAgent;
@property (strong, nonatomic) LMAlertView *ratingAlertView;
@end

@implementation FindAgentVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"Find Agent";
    // Do any additional setup after loading the view, typically from a nib.
    
    self.navigationController.navigationBarHidden=NO;
    arryAgent=[[NSMutableArray alloc]init];
    
    
    selectedIndex=-1;
    [self loadServerData:@"any"];
    
    /*set up navigation bar*/
    [self setupNavigationBar];
    [self btnSearchAction:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark-Navigation bar
-(void)setupNavigationBar
{
    UIButton *button  = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    ;
    [button setImage:[[UIImage imageNamed:@"searchIcon"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [button setContentMode:UIViewContentModeScaleAspectFit];
    [button addTarget:self action:@selector(btnSearchAction:) forControlEvents:UIControlEventTouchUpInside];
    [button setTintColor:[UIColor whiteColor]];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem=rightBarButtonItem;
}
#pragma mark-TableView deligate

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arryAgent count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
     CellAgentList *cell = [tableView dequeueReusableCellWithIdentifier:@"CellAgentList"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arryAgent objectAtIndex:indexPath.row]];
    /*set*/
    [cell setData:dictData];
    UIView *bgView = [[UIView alloc] init];
    // At least on iOS6 you don't to size the view for this to work.
    bgView.backgroundColor = [UIColor colorWithRed:18.0f/255.0f green:155.0f/255.0f blue:149.0f/255.0f alpha:1];
    
    
    [cell.btnCall addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnMessage addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnChat addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnMail addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.btnCall.tag=100;
    cell.btnMessage.tag=101;
    cell.btnChat.tag=102;
    cell.btnMail.tag=103;
    cell.btnRate.tag=indexPath.row;
    cell.btnCall.titleLabel.tag=indexPath.row;
    cell.btnMessage.titleLabel.tag=indexPath.row;
    cell.btnChat.titleLabel.tag=indexPath.row;
    cell.btnMail.titleLabel.tag=indexPath.row;
    cell.selectedBackgroundView = bgView;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AgentDetailVC *VC = [[UIStoryboard storyboardWithName:@"Main"
    bundle: nil] instantiateViewControllerWithIdentifier: @"AgentDetailVC"];
    VC.dictDetail=[[NSMutableDictionary alloc]initWithDictionary:[arryAgent objectAtIndex:indexPath.row]];
    [self.navigationController pushViewController:VC animated:YES];
}



/**/
/**/
-(void)loadServerData:(NSString *)strLocation
{
       if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
          NSDictionary *parameters=@{@"tag": @"find_agent",@"location_name": strLocation};
        
        NSString *strUrl=COMMON_URL(SEARCH_METHOD);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    
                    if (![[[data objectForKey:@"responseData"] objectForKey:@"agents"] isKindOfClass:[NSString class]]) {
                        arryAgent=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"agents"]];
                    }
                    else{
                        arryAgent=[[NSMutableArray alloc]init];
                    }

                    [_tblAgent reloadData];
                    
                    if (selectedIndex < [arryAgent count] && selectedIndex > -1) {
                        [_tblAgent reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
                    }
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

/*manage search button filter action*/
-(IBAction)btnSearchAction:(id)sender
{
    SearchViewAgent *searchVc=[[SearchViewAgent alloc]init];
    [searchVc setDelegate:self];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    
    [searchVc customOpen:window];
}

-(void)SearchViewAgent:(SearchViewAgent *)search allData:(NSDictionary *)dictAllInfo
{
       [self loadServerData_withFilter:dictAllInfo];
}
#pragma mark EDStarRatingProtocol delegate methods

- (void)starsSelectionChanged:(EDStarRating *)control rating:(float)rating
{
    NSString *ratingDescription;
    
    switch ([[NSNumber numberWithFloat:rating] integerValue]) {
        case 0:
            ratingDescription = @"Not yet rated";
            break;
        case 1:
            ratingDescription = @"Piss poor";
            break;
        case 2:
            ratingDescription = @"Ok I guess";
            break;
        case 3:
            ratingDescription = @"Average";
            break;
        case 4:
            ratingDescription = @"Pretty good";
            break;
        case 5:
            ratingDescription = @"Freaking amazing";
            break;
        default:
            return;
    }
    
    LMModalItemTableViewCell *cell = [self.ratingAlertView buttonCellForIndex:self.ratingAlertView.firstOtherButtonIndex];
    cell.isEnabled = (rating > 0);
    selectedRating=rating;
    self.ratingAlertView.message = ratingDescription;
    self.ratingAlertView.tag=101;
}

#pragma mark UIAlertViewDelegate delegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //  NSLog(@"%@: Clicked button at index: %li %li", [alertView class] , (long)buttonIndex,(long)alertView.tag);
    
    if (alertView.tag==101) {
        if (buttonIndex == 1) {
            [self rateCustomer];
        }
    }
}
#pragma mark - MFMAILComposer

- (void) sendMail:(NSString *)receiverEmail {
    
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    controller.mailComposeDelegate = self;
    controller.delegate = self;
    [controller setSubject:@"RexConnect"];
    
    [controller setToRecipients:@[receiverEmail]];
    
    if (controller) {
        [self presentViewController:controller animated:YES completion:nil];
    }
    
}


- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    NSString *messageBody= [[NSString alloc] init];
    switch (result)
    {
        case MFMailComposeResultCancelled:
            //DLog(@"Mail cancelled: you cancelled the operation and no email message was queued.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"You cancelled sending message";
            break;
            
        case MFMailComposeResultSaved:
            //DLog(@"Mail saved: you saved the email message in the drafts folder.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail saved: you saved the email message in the drafts folder'";
            break;
            
        case MFMailComposeResultSent:
            //DLog(@"Mail send: the email message is queued in the outbox. It is ready to send.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail has been sent";
            [self mailSent];
            break;
            
        case MFMailComposeResultFailed:
            //DLog(@"Mail failed: the email message was not saved or queued, possibly due to an error.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Email sending failed";
            break;
            
        default:
            //DLog(@"Mail not sent.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            break;
    }
    
    
}

- (void) mailSent
{
    //showing an alert for success
    [[ApplicationManager sharedManagerInstance] showAlert:@"Mail sent successfully." andTitle:@"Message"];
    
}

- (void) sendMessage{
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {
        controller.body =@"RexConnect";
        controller.recipients = @[strPhoneNumber];
        controller.messageComposeDelegate = self;
        [self presentViewController:controller animated:YES completion:nil];
    }
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    [self dismissViewControllerAnimated:YES completion:nil];
    switch (result) {
        case MessageComposeResultCancelled:
            [self.navigationController popViewControllerAnimated:YES];
            break;
            
        case MessageComposeResultFailed:
        {
            
            [self.navigationController popViewControllerAnimated:YES];
            break;
        }
            
        case MessageComposeResultSent:
            [self.navigationController popViewControllerAnimated:YES];
            break;
            
        default:
            [self.navigationController popViewControllerAnimated:YES];
            break;
    }
}

#pragma mark- Contact

- (IBAction)btnRateNowAction:(UIButton *)sender {
    selectedIndex=sender.tag;
    if ([AppDelegate sharedInstance].is_login) {
//        if (self.ratingAlertView != nil) {
//            starRating=0;
//            [self.ratingAlertView show];
//            return;
//        }

        self.ratingAlertView = [[LMAlertView alloc] initWithTitle:@"Rate this Agent" message:@"Average" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Rate", nil];
        CGSize size = self.ratingAlertView.size;
        
        LMModalItemTableViewCell *cell = [self.ratingAlertView buttonCellForIndex: self.ratingAlertView.firstOtherButtonIndex];
        cell.isEnabled = NO;
        
        [self.ratingAlertView setSize:CGSizeMake(size.width, 152.0)];
        
        UIView *contentView = self.ratingAlertView.contentView;
        
        starRating = [[EDStarRating alloc] initWithFrame:CGRectMake((size.width/2.0 - 190.0/2.0), 55.0, 190.0, 50.0)];
        starRating.starImage = [UIImage imageNamed:@"Star-25_unfil.png"];
        starRating.starHighlightedImage = [UIImage imageNamed:@"Star-25_fill.png"];
        starRating.maxRating = 5.0;
        starRating.delegate = self;
        starRating.horizontalMargin = 12.0;
        starRating.editable = YES;
        starRating.displayMode = EDStarRatingDisplayFull;
        starRating.rating = 0;
        starRating.backgroundColor = [UIColor clearColor];
        
        [contentView addSubview:starRating];
        
        [self.ratingAlertView show];
    }
    else{
        [[ApplicationManager sharedManagerInstance]showAlert:@"Please log in before submit a Aating" andTitle:@"Message"];
    }

}


-(void)rateCustomer
{
    
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        
        NSDictionary *parameters=@{@"tag": @"agent_rating",@"agent_id": [[arryAgent objectAtIndex:selectedIndex] objectForKey:@"id"],@"rating": [NSString stringWithFormat:@"%.0f", starRating.rating*2],@"voterid": [AppDelegate sharedInstance].id_user_login};
        
        NSString *strUrl=COMMON_URL(RATING);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    
                    
                    [self loadServerData:@"any"];
                }
                [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    
}



- (void)dismissButtonPressed:(UIButton *)sender {
    if ([AppDelegate sharedInstance].is_login) {
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithDictionary:[arryAgent objectAtIndex:sender.titleLabel.tag]];
        
        strPhoneNumber=[dict objectForKey:@"phone"];
        strEmail=[dict objectForKey:@"email"];
        
        
        switch (((UIButton *)sender).tag) {
            case 100:
                //  NSLog(@"Call");
                
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",strPhoneNumber]]];
                break;
            case 101:
                //  NSLog(@"message");
                [self sendMessage];
                break;
            case 102:
                //  NSLog(@"Chat");
                
                break;
            case 103:
                //  NSLog(@"Mail");
                [self sendMail:strEmail];
                
            default:
                break;
        }

    }
    else{
         [[ApplicationManager sharedManagerInstance]showAlert:@"Please login before using this feature" andTitle:@"Message"];
    }
    
}
-(void)loadServerData_withFilter:(NSDictionary *)dictAllInfo
{

    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"find_agent",@"location_name": [dictAllInfo objectForKey:@"locationAgent"]};
        
        
        
        
        NSString *strUrl=COMMON_URL(SEARCH_METHOD);
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    arryAgent=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"agents"]];
                    [_tblAgent reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}


@end
