//
//  FindBuyerVC.m
//  RexConnect
//
//  Created by cis on 6/5/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "FindBuyerVC.h"
#import "Constant.h"
#import "CellFindBuyer.h"
#import "SlideNavigationController.h"
#import "SearchBuyer.h"
#import "BuyerDetailVC.h"
@interface FindBuyerVC ()<SearchViewBuyerDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,UINavigationControllerDelegate>
{
    NSMutableArray *arryBuyerList;
    NSString *strPhoneNumber,*strEmail;
}
@property (weak, nonatomic) IBOutlet UITableView *tblBuyer;
@end

@implementation FindBuyerVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title=@"Find Buyer";
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    self.navigationController.navigationBarHidden=NO;
    arryBuyerList=[[NSMutableArray alloc]init];
    
    
    
    [self loadServerData];
    
    /*set up navigation bar*/
    [self setupNavigationBar];
    [self btnSearchAction:nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark-Navigation bar
-(void)setupNavigationBar
{
    UIButton *button  = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    ;
    [button setImage:[[UIImage imageNamed:@"searchIcon"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [button setContentMode:UIViewContentModeScaleAspectFit];
    [button addTarget:self action:@selector(btnSearchAction:) forControlEvents:UIControlEventTouchUpInside];
    [button setTintColor:[UIColor whiteColor]];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem=rightBarButtonItem;
}
#pragma mark-TableView deligate

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arryBuyerList count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellFindBuyer *cell = [tableView dequeueReusableCellWithIdentifier:@"CellAgentList"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arryBuyerList objectAtIndex:indexPath.row]];
    /*set*/
    [cell setData:dictData];
    UIView *bgView = [[UIView alloc] init];
    // At least on iOS6 you don't to size the view for this to work.
    bgView.backgroundColor = [UIColor colorWithRed:18.0f/255.0f green:155.0f/255.0f blue:149.0f/255.0f alpha:1];
    cell.selectedBackgroundView = bgView;
    
    [cell.btnCall addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnMessage addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnChat addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnMail addTarget:self action:@selector(dismissButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.btnCall.tag=100;
    cell.btnMessage.tag=101;
    cell.btnChat.tag=102;
    cell.btnMail.tag=103;
    
    cell.btnCall.titleLabel.tag=indexPath.row;
    cell.btnMessage.titleLabel.tag=indexPath.row;
    cell.btnChat.titleLabel.tag=indexPath.row;
    cell.btnMail.titleLabel.tag=indexPath.row;
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    BuyerDetailVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                   bundle: nil] instantiateViewControllerWithIdentifier: @"BuyerDetailVC"];
    VC.dictDetail=[[NSMutableDictionary alloc]initWithDictionary:[arryBuyerList objectAtIndex:indexPath.row]];
    [self.navigationController pushViewController:VC animated:YES];
}


#pragma mark - MFMAILComposer

- (void) sendMail:(NSString *)receiverEmail {
    
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    controller.mailComposeDelegate = self;
    controller.delegate = self;
    [controller setSubject:@"RexConnect"];
    
    [controller setToRecipients:@[receiverEmail]];
    
    if (controller) {
        [self presentViewController:controller animated:YES completion:nil];
    }
    
}


- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    NSString *messageBody= [[NSString alloc] init];
    switch (result)
    {
        case MFMailComposeResultCancelled:
            //DLog(@"Mail cancelled: you cancelled the operation and no email message was queued.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"You cancelled sending message";
            break;
            
        case MFMailComposeResultSaved:
            //DLog(@"Mail saved: you saved the email message in the drafts folder.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail saved: you saved the email message in the drafts folder'";
            break;
            
        case MFMailComposeResultSent:
            //DLog(@"Mail send: the email message is queued in the outbox. It is ready to send.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail has been sent";
            [self mailSent];
            break;
            
        case MFMailComposeResultFailed:
            //DLog(@"Mail failed: the email message was not saved or queued, possibly due to an error.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Email sending failed";
            break;
            
        default:
            //DLog(@"Mail not sent.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            break;
    }
    
    
}

- (void) mailSent
{
    //showing an alert for success
    [[ApplicationManager sharedManagerInstance] showAlert:@"Mail sent successfully." andTitle:@"Message"];
    
}

- (void) sendMessage{
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {
        controller.body =@"RexConnect";
        controller.recipients = @[strPhoneNumber];
        controller.messageComposeDelegate = self;
        [self presentViewController:controller animated:YES completion:nil];
    }
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    [self dismissViewControllerAnimated:YES completion:nil];
    switch (result) {
        case MessageComposeResultCancelled:
            [self.navigationController popViewControllerAnimated:YES];
            break;
            
        case MessageComposeResultFailed:
        {
            
            [self.navigationController popViewControllerAnimated:YES];
            break;
        }
            
        case MessageComposeResultSent:
            [self.navigationController popViewControllerAnimated:YES];
            break;
            
        default:
            [self.navigationController popViewControllerAnimated:YES];
            break;
    }
}
/*load data form web services*/
-(void)loadServerData
{
    [_tblBuyer reloadData];
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
          NSDictionary *parameters=@{@"tag": @"find_buyer",@"buy_location": @"all",@"bed": @"any",@"bathroom":@"any",@"p_type_byuer":@"any"};
        
        NSString *strUrl=COMMON_URL(SEARCH_METHOD);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    arryBuyerList=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"buyers"]];
                    [_tblBuyer reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}
-(void)loadServerData_withFilter:(NSDictionary *)dictAllInfo
{
    [_tblBuyer reloadData];
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"find_buyer",@"buy_location": [dictAllInfo objectForKey:@"location"],@"bed": [dictAllInfo objectForKey:@"bedroom"],@"bathroom": [dictAllInfo objectForKey:@"bathroom"],@"p_type_byuer":[dictAllInfo objectForKey:@"type"]};
        
        
        
        
        NSString *strUrl=COMMON_URL(SEARCH_METHOD);
                [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    arryBuyerList=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"buyers"]];
                    [_tblBuyer reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}
/*manage search button filter action*/
-(IBAction)btnSearchAction:(id)sender
{
    SearchBuyer *searchVc=[[SearchBuyer alloc]init];
    [searchVc setDelegate:self];
     UIWindow *window = [UIApplication sharedApplication].keyWindow;
    
    [searchVc customOpen:window];
}


-(void)SearchView:(SearchBuyer *)search allData:(NSDictionary *)dictAllInfo
{
    [self loadServerData_withFilter:dictAllInfo];
}

- (void)dismissButtonPressed:(UIButton *)sender {
    if ([AppDelegate sharedInstance].is_login) {
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithDictionary:[arryBuyerList objectAtIndex:sender.titleLabel.tag]];
        
        strPhoneNumber=[dict objectForKey:@"phone"];
        strEmail=[dict objectForKey:@"email"];
        
        
        switch (((UIButton *)sender).tag) {
            case 100:
                //  NSLog(@"Call");
                
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",strPhoneNumber]]];
                break;
            case 101:
                //  NSLog(@"message");
                [self sendMessage];
                break;
            case 102:
                //  NSLog(@"Chat");
                
                break;
            case 103:
                //  NSLog(@"Mail");
                [self sendMail:strEmail];
                
            default:
                break;
        }
        
    }
    else{
        [[ApplicationManager sharedManagerInstance]showAlert:@"Please login before using this feature" andTitle:@"Message"];
    }
    
}

@end
