//
//  LeftMenuVC.m
//  Kronopress
//
//  Created by cis on 4/16/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "LeftMenuVC.h"
#import "CellLeftMenu.h"
#import "KPCommanClass.h"
#import "Constant.h"
#import "ViewController.h"
#import "LoginVC.h"
#import "FindAgentVC.h"
#import "FindBuyerVC.h"
#import "CategoryAreaGuideVC.h"
#import "Constant.h"
#import "ManageVC.h"
#import "RegisterVC.h"
#import "UIImageView+WebCache.h"
#import "RateAnAgnetVC.h"
#import "HomeVC.h"
#import "LoginVC.h"
#import "LoginViewController.h"
#import <CometChatSDK/CometChat.h>
#import "LoginViewController.h"
#import "NativeKeys.h"
#import "MainViewController.h"
#import "BlankVC.h"
@interface LeftMenuVC ()
{
    NSMutableArray *arrayMenu;
    AppDelegate *appDeligate;
    NSUserDefaults *userDefault;
    CometChat *cometChat;
}
@property (strong, nonatomic) IBOutlet UITextField *txtUserName;
@property (strong, nonatomic) IBOutlet UITextField *txtEmailID;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtPhoneNumber;
@property (strong, nonatomic) IBOutlet UITextField *txtCompany;
@property (strong, nonatomic) IBOutlet UITextField *txtORN;
@property (strong, nonatomic) IBOutlet UITextField *txtBroker;
@property (strong, nonatomic) IBOutlet UIButton *btnRegister;
@property (weak, nonatomic) IBOutlet UIButton *btnLogin;
@property (weak, nonatomic) IBOutlet UIButton *btnCaht;
@property (weak, nonatomic) IBOutlet UIButton *btnNotification;
@property (weak, nonatomic) IBOutlet UILabel *lblLogin;


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leftLofin;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rightNotification;
@property (weak, nonatomic) IBOutlet UITableView *tblMenu;
@end

@implementation LeftMenuVC
- (id)initWithCoder:(NSCoder *)aDecoder
{
    self.slideOutAnimationEnabled = YES;
    
    return [super initWithCoder:aDecoder];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    /*add valu in array*/
//    arrayMenu=[[NSMutableArray alloc]initWithObjects:@"Find a Deal",@"Find Buyers",@"Find Agent",@"Manage",@"Area Guide",@"Agent Login",@"About Us",@"Login",nil];
    
    
    
    
    
    arrayMenu=[[NSMutableArray alloc]init];
    
    [arrayMenu addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"HOME",@"key",@[@{@"Title":@"Home",@"imageName":@"home.png"},],@"array",nil]];
    
    [arrayMenu addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"RATE & REVIEW",@"key",@[@{@"Title":@"Review Development",@"imageName":@"home.png"},@{@"Title":@"Rate an Agent",@"imageName":@"home.png"}],@"array",nil]];
    [arrayMenu addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"FIND",@"key", @[@{@"Title":@"Find a Deal",@"imageName":@"searchicon_1.png"},@{@"Title":@"Find a Buyer",@"imageName":@"searchicon_1.png"},@{@"Title":@"Find an Agent",@"imageName":@"searchicon_1.png"}], @"array",nil]];
    appDeligate=[AppDelegate sharedInstance];
    userDefault=[NSUserDefaults standardUserDefaults];
    if (!appDeligate.is_login) {
        [arrayMenu addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Manage",@"key", @[@{@"Title":@"Buyers",@"imageName":@"right_icon_1"},@{@"Title":@"Property",@"imageName":@"searchicon_1.png"},@{@"Title":@"Location",@"imageName":@"searchicon_1.png"}], @"array",nil]];
    }
    else{
        [arrayMenu addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"MANAGE",@"key", @[@{@"Title":@"Buyers",@"imageName":@"right_icon_1"},@{@"Title":@"Properties",@"imageName":@"searchicon_1.png"},@{@"Title":@"Location",@"imageName":@"searchicon_1.png"},@{@"Title":@"Logout",@"imageName":@"Logout-100.png"}], @"array",nil]];
    }
    
    
    [_tblMenu setTableFooterView:[[UIView alloc]initWithFrame:CGRectZero]];
    [_tblMenu setBackgroundColor:[UIColor clearColor]];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"table_bg.png"]]];
    
   
    
    [[NSNotificationCenter defaultCenter] addObserverForName:SlideNavigationControllerDidReveal object:nil queue:nil usingBlock:^(NSNotification *note) {
        if ([AppDelegate sharedInstance].is_login) {
             
            
            NSUserDefaults *defaultUser=[NSUserDefaults standardUserDefaults];
            NSDictionary *loginInfo=[defaultUser objectForKey:USERDEFAULT_LOGININFO];
            UIImageView *imgProfile=[[UIImageView alloc]init];
            
            [imgProfile sd_setImageWithURL:[NSURL URLWithString:[loginInfo objectForKey:@"profile_img"]] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                [self.btnLogin setImage:image forState:UIControlStateNormal];
                [self.btnLogin.layer setCornerRadius:self.btnLogin.frame.size.height/2];
                self.btnLogin.layer.borderWidth=3.0f;
                self.btnLogin.layer.borderColor=[[UIColor colorWithRed:152.0f/255.0f green:152.0f/255.0f blue:152.0f/255.0f alpha:1.0] CGColor];
                if (error) {
                  [self.btnLogin setImage:[UIImage imageNamed:@"User_Male_Circle-100"] forState:UIControlStateNormal];
                }
            }];
            [_lblLogin setText:[loginInfo objectForKey:@"name"]];
        }
        else{
            [self.btnLogin setImage:[UIImage imageNamed:@"User_Male_Circle-100"] forState:UIControlStateNormal];
            [_lblLogin setText:@"Login Here"];
        }
        
    }];
    
    [_btnCaht setTintColor:[UIColor colorWithRed:152.0f/255.0f green:152.0f/255.0f blue:152.0f/255.0f alpha:1.0]];
    [_btnCaht setImage:[[UIImage imageNamed:@"speech_bubble.png" ] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [_btnNotification setTintColor:[UIColor colorWithRed:152.0f/255.0f green:152.0f/255.0f blue:152.0f/255.0f alpha:1.0]];
    [_btnNotification setImage:[[UIImage imageNamed:@"alert.png" ] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    
    [_tblMenu reloadData];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - UITableView Delegate & Datasrouce -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[[arrayMenu objectAtIndex:section] objectForKey:@"array"] count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [arrayMenu count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 25;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
     UIView *sectionView=[[UIView alloc]initWithFrame:CGRectMake(0, 0,self.tblMenu.frame.size.width, 25)];
    if (section == 0 ) {
        UIImageView *imgfooter=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, sectionView.frame.size.width, 2)];
        [imgfooter setImage:[UIImage imageNamed:@"division.png"]];
        [sectionView addSubview:imgfooter];

    }
   
//    sectionView.backgroundColor=[UIColor colorWithRed:42.0f/255.0f green:38.0f/255.0f blue:34.0f/255.0f alpha:1];
    sectionView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"menuHeader_bg.png"]];
    UILabel *tempLabel=[[UILabel alloc]initWithFrame:CGRectMake(15,0,self.tblMenu.frame.size.width-2.5,sectionView.frame.size.height)];
    tempLabel.text=[[arrayMenu objectAtIndex:section] objectForKey:@"key"];
    tempLabel.textColor=[UIColor colorWithRed:75.0f/255.0f green:75.0f/255.0f blue:75.0f/255.0f alpha:1];
    [tempLabel setFont:[tempLabel.font fontWithSize: 15]];
    [sectionView addSubview:tempLabel];
    
    UIImageView *imgfooter=[[UIImageView alloc]initWithFrame:CGRectMake(0, tempLabel.frame.size.height-2, sectionView.frame.size.width, 2)];
    [imgfooter setImage:[UIImage imageNamed:@"division.png"]];
    [sectionView addSubview:imgfooter];
    return sectionView;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellLeftMenu *cell = (CellLeftMenu *)[tableView dequeueReusableCellWithIdentifier:@"CellLeftMenu"];
    NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithDictionary:[[[arrayMenu objectAtIndex:indexPath.section] objectForKey:@"array"] objectAtIndex:indexPath.row]];
    
    [cell setData:dict];

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [AppDelegate sharedInstance].is_search=NO;
    
    switch (indexPath.section)
    {
        case 0:
        {
            switch (indexPath.row)
            {
                case 0:
                {
                    HomeVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                         bundle: nil] instantiateViewControllerWithIdentifier: @"HomeVC"];
                    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                     andCompletion:nil];
            
                }
                break;
            }
            break;
        }
        case 1:
        {
            switch (indexPath.row)
            {
                case 0:
                {
                    CategoryAreaGuideVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                         bundle: nil] instantiateViewControllerWithIdentifier: @"CategoryAreaGuideVC"];
                    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                     andCompletion:nil];
                    
                }
                    break;
                case 1:
                {
                    if (appDeligate.is_login) {
                        RateAnAgnetVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                       bundle: nil] instantiateViewControllerWithIdentifier: @"RateAnAgnetVC"];
                        [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                                 withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                         andCompletion:nil];
                        
                        
                    }
                    else{
                        [[ApplicationManager sharedManagerInstance]showAlert:@"Please login for this section" andTitle:@"Message!"];
                    }
                    
                    
                }
                    break;
            }
            break;
        }
            
        
        case 2:
        {
            switch (indexPath.row)
            {
                case 0:
                {
                    ViewController *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
                    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                     andCompletion:nil];
                    
                }
                    break;
                    
                case 1:
                {
                    FindBuyerVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil] instantiateViewControllerWithIdentifier: @"FindBuyerVC"];
                    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                     andCompletion:nil];
                    
                }
                    break;
                case 2:
                {
                    FindAgentVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil] instantiateViewControllerWithIdentifier: @"FindAgentVC"];
                    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                     andCompletion:nil];
                    
                }
                    break;
                
            }
            
        }
            break;
        case 3:
        {
            switch (indexPath.row)
            {
                case 0:
                {
                    if (appDeligate.is_login) {
                        ManageVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                  bundle: nil] instantiateViewControllerWithIdentifier: @"ManageVC"];
                        
                        VC.indexSelectedFeature=indexPath.row;
           
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"ManageVC" object:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
                        [[SlideNavigationController sharedInstance]popAllAndSwitchToViewController:VC withCompletion:nil];
                    }
                    else{
                        [[ApplicationManager sharedManagerInstance]showAlert:@"Please login for this section" andTitle:@"Message!"];
                    }
                    
                }
                    break;
                    
                case 1:
                {
                    if (appDeligate.is_login) {
                        ManageVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                  bundle: nil] instantiateViewControllerWithIdentifier: @"ManageVC"];
          
                        
                        
                        VC.indexSelectedFeature=indexPath.row;
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"ManageVC" object:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
                        
                        
                        [[SlideNavigationController sharedInstance]popAllAndSwitchToViewController:VC withCompletion:nil];
                        

                    }
                    else{
                        [[ApplicationManager sharedManagerInstance]showAlert:@"Please login for this section" andTitle:@"Message!"];
                    }

                    
                }
                    break;
                case 2:
                {
                    if (appDeligate.is_login) {
                        ManageVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                  bundle: nil] instantiateViewControllerWithIdentifier: @"ManageVC"];
                        VC.indexSelectedFeature=indexPath.row;
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"ManageVC" object:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
                        
                        [[SlideNavigationController sharedInstance]popAllAndSwitchToViewController:VC withCompletion:nil];
                    }
                    else{
                        [[ApplicationManager sharedManagerInstance]showAlert:@"Please login for this section" andTitle:@"Message!"];
                    }
                    
                    
                }
                    break;
                case 3:
                {
                    if (appDeligate.is_login) {
                        [[ApplicationManager sharedManagerInstance]showAlert:@"User successfully log out" andTitle:@"Message"];
                        [userDefault removeObjectForKey:USERDEFAULT_LOGININFO];
                        appDeligate.is_login=false;
                        [self viewDidLoad];
                        [_tblMenu reloadData];
                        
                        
                        HomeVC *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
                        [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                                 withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                         andCompletion:nil];
                    }

                    
                    
                }
                    break;
            }
            
        }
            break;
    }
    


}
- (IBAction)btnLogin:(id)sender {
    [AppDelegate sharedInstance].is_search=YES;
    if (!appDeligate.is_login) {
        LoginVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                 bundle: nil] instantiateViewControllerWithIdentifier: @"LoginVC"];
        [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC withSlideOutAnimation:self.slideOutAnimationEnabled andCompletion:nil];
    }
    else{
        RegisterVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                    bundle: nil] instantiateViewControllerWithIdentifier: @"RegisterVC"];
        VC.is_edit=YES;
        [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC withSlideOutAnimation:self.slideOutAnimationEnabled andCompletion:nil];
    }
}
- (IBAction)btnChat:(id)sender {
    
    if (appDeligate.is_login) {

        
        MainViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"mainviewcontroller"];
    
         [[SlideNavigationController sharedInstance]popAllAndSwitchToViewController:viewController withCompletion:nil];
        
        
          }
    else{
         [[ApplicationManager sharedManagerInstance]showAlert:@"Please login for this section" andTitle:@"Message!"];
    }

    
}

- (void)handleLogin {
    
    /* Handle Login success event in this block */
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Success"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"com.sdkdemo.logsview.refreshLogs" object:nil];
    
    MainViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"mainviewcontroller"];
    [self.navigationController pushViewController:viewController animated:YES];
    viewController = nil;
    
 }

- (void)handleLoginError:(NSArray *)array {
    
    
    [NativeKeys getLogOType:LOG_TYPE_ONE_ON_ON ForMessage:@"Login Failure"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"com.sdkdemo.logsview.refreshLogs" object:nil];
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGIN_DETAILS];
    
    NSString *message = @"Error message";
    
    switch ([[array objectAtIndex:1] code]) {
        case 10:
            message = [NSString stringWithFormat:@"Please check your internet connection"];
            break;
        case 11:
            message = [NSString stringWithFormat:@"Error in connection"];
            break;
        case 20:
            message = [NSString stringWithFormat:@"Plsease check username or password"];
            break;
        case 21:
            message = [NSString stringWithFormat:@"Invalid user details"];
            break;
        case 22:
            message = [NSString stringWithFormat:@"Invalid URL"];
            break;
        case 23:
            message = [NSString stringWithFormat:@"CometChat needs to be upgraded on the site"];
        case 24:
            message = [NSString stringWithFormat:@"Invalid credentials OR Server not configured. Please contact the administrator"];
            break;
    }
    
    [[ApplicationManager sharedManagerInstance] showAlert:@"Message" andTitle:message];
 
    message = nil;
}

- (IBAction)btnNotification:(id)sender {
}


@end
