//
//  LoginVC.h
//  Kronopress
//
//  Created by cis on 4/22/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "ViewController.h"

@interface LoginVC : ViewController

@end
