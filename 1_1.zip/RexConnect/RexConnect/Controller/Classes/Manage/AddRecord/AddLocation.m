//
//  AddLocation.m
//  RexConnect
//
//  Created by cis on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "AddLocation.h"

@implementation AddLocation
@synthesize isUpdate;

-(id)init{
    
    self = [[[NSBundle mainBundle] loadNibNamed:@"AddLocation" owner:nil options:nil] lastObject];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [self setFrame:window.frame];
//    [_middleContainer.layer setCornerRadius:8];
    [_middleContainer.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_middleContainer.layer setBorderWidth:1.0f];
    [_middleContainer.layer setShadowColor:[UIColor blackColor].CGColor];
    [_middleContainer.layer setShadowOpacity:0.8];
    [_middleContainer.layer setShadowRadius:3.0];
    [_middleContainer.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
 
    arrayLocation = [[NSMutableArray alloc]initWithObjects:@"any",@"Abu Dhabi Gate City", @"Airport Road", @"Akoya",
                     @"Al Barari",@"Al Barsha",@"Al Bateen", @"Al Falah City",
                     @"Al Furjan", @"Al Garhoud", @"Al Ghadeer",@"Al Hamra Village",
                     @"Al Karamah", @"Al Khail Heights", @"Al Khalidiya", @"Al Mamzar",
                     @"Al Manhal", @"Al Maqtaa", @"Al Markaz", @"Al Mina", @"Al Muneera",
                     @"Al Mushrif", @"Al Nahda Abu Dhabi", @"Al Nahyan",@"Al Nahyan Camp",
                     @"Al Najda Street", @"Al Nasr Street", @"Al Qurm",@"Al Qusais",
                     @"Al Raha",@"Al Raha Beach",@"Al Raha Gardens",
                     @"Al Raha Golf Gardens",@"Al Rahba",@"Al Rawdah",@"Al Reef",
                     @"Al Reem",@"Al Reem Island",@"Al Sufouh",@"Al Warqaa",@"Al Wasl",
                     @"Arabian Ranches",@"Baniyas",@"Between Two Bridges",
                     @"Business Bay",@"Corniche Area",@"Corniche Road",
                     @"Culture Village",@"Deira",@"DIFC",@"Discovery Gardens",
                     @"Downtown Burj Dubai",@"Downtown Jebel Ali",
                     @"Dubai Healthcare City",@"Dubai Investment Park",@"Dubai Marina",
                     @"Dubai Waterfront",@"Dubai World Central",@"Dubailand",
                     @"Electra Street",@"Emirates Hills",@"Festival City",@"Greens",
                     @"Hamdan Street",@"Hydra Village",@"IMPZ",@"International City",
                     @"JBR",@"Jebel Ali",@"Jumeirah",@"Jumeirah Heights",
                     @"Jumeirah Islands",@"Jumeirah Lake Towers",@"Jumeirah Park",
                     @"Jumeirah Village Circle",@"Jumeirah Village Triangle",@"Khalidia",
                     @"Khalifa City A",@"Khalifa City B",@"Lakes",@"Manama",@"Meadows",
                     @"Meydan City",@"Mirdiff",@"Mohamed Bin Zayed City",
                     @"Mohammad Bin Rashid City",@"Motor City",@"Muroor Area",@"Mushrif",
                     @"Mussafah",@"Old Town",@"Palm Jumeirah",@"Reem",@"Saadiyat Island",
                     @"Salam Street",@"Sheikh Zayed Road",@"Silicon Oasis",
                     @"Sports City",@"Springs",@"TECOM",@"The Hills",@"The Views",
                     @"The Villa",@"The World Islands",@"Tourist Club Area",
                     @"Umm Al Quwain Marina",@"Umm Ramool",@"Umm Suqueim",
                     @"Victory Heights", nil];
    
    dropLocation=[[SAMenuDropDown alloc] initWithWithSource:_btnAgentLocation menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropLocation setDelegate:self];
    [dropLocation setUpItemDataSourceWithNames:arrayLocation subtitles:nil imageNames:nil];
    
    _lblAgentLocation.text = [arrayLocation objectAtIndex:0];
    
    [_viewDropDownLocation.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewDropDownLocation.layer setBorderWidth:1.0f];
    return self;
}

#pragma mark - Action -

- (IBAction)actionClose:(id)sender {
    NSDictionary *dictAllInfo =@{@"isUpdate":isUpdate,@"locationAgent": self.lblAgentLocation.text};
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(ManageAddlocation:allData:)])  {
        [_delegate ManageAddlocation:self allData:(NSDictionary *)dictAllInfo];
    }
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"searchAction" object:nil];
    self.transform = CGAffineTransformMakeScale(1, 1);
    
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

- (IBAction)takeLocation:(id)sender {
    dropLocation.hidden = NO;
    [dropLocation self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}

#pragma mark - Custom delegate-

- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex{
    if (menuSender == dropLocation) {
        _lblAgentLocation.text = [arrayLocation objectAtIndex:buttonIndex];
        dropLocation.hidden = YES;
    }
}
-(IBAction)customOpen
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
    self.transform = CGAffineTransformMakeScale(0, 0);
    self.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.alpha = 1;
        self.transform = CGAffineTransformMakeScale(1, 1);
    }];
}
- (IBAction)close:(id)sender {
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}
@end
