//
//  AddAgent.m
//  RexConnect
//
//  Created by cis on 6/24/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "AddPropertyManage.h"
#import "Constant.h"
@implementation AddPropertyManage
@synthesize arrayRefrenceNumber,isUpdate;
-(id)init:(NSMutableArray *)refrenceArray{
    
    self = [[[NSBundle mainBundle] loadNibNamed:@"AddPropertyManage" owner:nil options:nil] lastObject];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [self setFrame:window.frame];
//    [_middleContainer.layer setCornerRadius:8];
    [_middleContainer.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_middleContainer.layer setBorderWidth:1.0f];
    [_middleContainer.layer setShadowColor:[UIColor blackColor].CGColor];
    [_middleContainer.layer setShadowOpacity:0.8];
    [_middleContainer.layer setShadowRadius:3.0];
    [_middleContainer.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    arrayRefrenceNo=[[NSMutableArray alloc]initWithArray:refrenceArray];
    
    dropRefrenceNo=[[SAMenuDropDown alloc] initWithWithSource:_btnRefrenceNo menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropRefrenceNo setDelegate:self];
    [dropRefrenceNo setUpItemDataSourceWithNames:arrayRefrenceNo subtitles:nil imageNames:nil];
    if ([arrayRefrenceNo count]>0) {
        [_lblRefrenceNo setText:[arrayRefrenceNo objectAtIndex:0]];
    }
    else{
        [_lblRefrenceNo setText:@"Refrence No Not Available"];
    }
    
    [_viewRef.layer setBorderWidth:1.0f];
    [_viewRef.layer setBorderColor:[[UIColor grayColor] CGColor]];
    
    return self;
}

#pragma mark - Action -

- (IBAction)actionClose:(id)sender {
    if ([arrayRefrenceNo count]>0) {
        NSDictionary *dictAllInfo =@{@"isUpdate":isUpdate,@"refrence_no": self.lblRefrenceNo.text,@"dawa":_txtDawa.text};
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(ManageAddproperty:allData:)])  {
            [_delegate ManageAddproperty:self allData:(NSDictionary *)dictAllInfo];
        }
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"searchAction" object:nil];
        self.transform = CGAffineTransformMakeScale(1, 1);
        
        [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
            self.transform = CGAffineTransformMakeScale(0.01, 0.01);
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }else{
        [[ApplicationManager sharedManagerInstance]showAlert:@"Reference number not available" andTitle:@"Message"];
    }
   
}

- (IBAction)takeLocation:(id)sender {
    dropRefrenceNo.hidden = NO;
    if ([arrayRefrenceNo count]>0) {
        [dropRefrenceNo self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];

    }
    else{
        [[ApplicationManager sharedManagerInstance]showAlert:@"Reference number not available" andTitle:@"Message"];
    }
 }

#pragma mark - Custom delegate-

- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex{
    if (menuSender == dropRefrenceNo) {
        _lblRefrenceNo.text = [arrayRefrenceNo objectAtIndex:buttonIndex];
        dropRefrenceNo.hidden = YES;
    }
}
-(IBAction)customOpen
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
    self.transform = CGAffineTransformMakeScale(0, 0);
    self.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.alpha = 1;
        self.transform = CGAffineTransformMakeScale(1, 1);
    }];
}
- (IBAction)close:(id)sender {
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

@end
