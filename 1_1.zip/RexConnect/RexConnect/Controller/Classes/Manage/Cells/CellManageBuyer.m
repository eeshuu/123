//
//  CellManageBuyer.m
//  RexConnect
//
//  Created by cis on 6/22/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "CellManageBuyer.h"

@implementation CellManageBuyer

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setData:(NSMutableDictionary *)dict
{
    [self.lblPropertyName setText:[NSString stringWithFormat:@"Property name : %@",[dict objectForKey:@"u_name"]]];
    [self.lblType setText:[NSString stringWithFormat:@"type : %@",[dict objectForKey:@"p_type"]]];
    [self.lblBed setText:[NSString stringWithFormat:@"Bed  : %@",[dict objectForKey:@"bed"]]];
    [self.lblRefrenceNumber setText:[NSString stringWithFormat:@"Price from %@  to %@",[dict objectForKey:@"price_from"],[dict objectForKey:@"price_to"]]];

    
}

@end
