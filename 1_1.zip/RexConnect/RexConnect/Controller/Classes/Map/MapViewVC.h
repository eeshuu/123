//
//  MapViewVC.h
//  Workly
//
//  Created by Nilesh on 2/17/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "MyAnnotation.h"

@protocol location <NSObject>

-(void)getLocation:(NSDictionary *)dict;

@end


@interface MapViewVC : UIViewController<MKMapViewDelegate>

@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (nonatomic)BOOL isEditable;
@property (nonatomic, strong)CLLocation *locationForAnnotation;
@property (nonatomic,unsafe_unretained)id<location>delegate;
- (IBAction)doneBtnAction:(id)sender;
@end
