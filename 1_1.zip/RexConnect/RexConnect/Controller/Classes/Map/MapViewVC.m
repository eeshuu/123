//
//  MapViewVC.m
//  Workly
//
//  Created by Nilesh on 2/17/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "MapViewVC.h"

@interface MapViewVC ()
{
    BOOL isTouch;
    BOOL userLocationShown;
    MyAnnotation *myAnnotation;
    NSMutableDictionary *dataDic;
}
@end

@implementation MapViewVC
@synthesize mapView,delegate,isEditable,locationForAnnotation;
- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"Map";
    
    if (!self.isEditable) {
        mapView.showsUserLocation = YES;
        mapView.delegate = self;
        isTouch = NO;
        userLocationShown = NO;
    
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGesture:)];
    longPressGesture.minimumPressDuration = 0.5;
    [mapView addGestureRecognizer:longPressGesture];
    
    dataDic = [NSMutableDictionary new];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc ]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneBtnAction:)];
    self.navigationItem.rightBarButtonItem = rightButton;
    }
    else {
        if (self.locationForAnnotation.coordinate.latitude>0.0 && self.locationForAnnotation.coordinate.latitude>0.0) {
            [self showAnnotationOnMap];
        }
        
    }
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - GestureRecognize Action

-(void)handleLongPressGesture:(UIGestureRecognizer*)sender {
    
    isTouch =YES;
    
    // This is important if you only want to receive one tap and hold event
    
    // Here we get the CGPoint for the touch and convert it to latitude and longitude coordinates to display on the map
    //copy your annotations to an array
    
    NSMutableArray *annotationsToRemove = [[NSMutableArray alloc] initWithArray: mapView.annotations];
    //Remove the object userlocation
    [annotationsToRemove removeObject: mapView.userLocation];
    //Remove all annotations in the array from the mapView
    [mapView removeAnnotations: annotationsToRemove];
    
    CGPoint point = [sender locationInView:mapView];
    CLLocationCoordinate2D locCoord = [mapView convertPoint:point toCoordinateFromView:mapView];
    // Then all you have to do is create the annotation and add it to the map
    
    
    
    myAnnotation = [[MyAnnotation alloc] init];
    
    myAnnotation.coordinate = CLLocationCoordinate2DMake(locCoord.latitude,locCoord.longitude);
    myAnnotation.title = @"NA";

    
    CLLocation *currentLocation = [[CLLocation alloc]
                                   initWithLatitude:locCoord.latitude
                                   longitude:locCoord.longitude];

    
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemark, NSError *error) {
        
        //set the title if we got any placemarks...
        if (placemark.count > 0)
        {
            [dataDic removeAllObjects];
            CLPlacemark *topResult = [placemark objectAtIndex:0];
            [dataDic setObject:[NSString stringWithFormat:@"%f",myAnnotation.coordinate.latitude] forKey:@"Latitude"];
            [dataDic setObject:[NSString stringWithFormat:@"%f",myAnnotation.coordinate.longitude] forKey:@"Longitude"];
            [dataDic setObject:topResult.addressDictionary forKey:@"Address"];

            
            myAnnotation.title = [NSString stringWithFormat:@"%@, %@",topResult.addressDictionary[@"Name"],topResult.addressDictionary[@"City"]];
            myAnnotation.subtitle = [NSString stringWithFormat:@"%@, %@",topResult.addressDictionary[@"Country"],topResult.addressDictionary[@"ZIP"]];
        }
        
    }];
    
    [mapView addAnnotation:myAnnotation];
}

#pragma mark - MapView Delegate

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    if (!userLocationShown) {
        userLocationShown = YES;
        CLLocationCoordinate2D loc = [userLocation coordinate];
        MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(loc, 1000, 1000);
        [mapView setRegion:region animated:YES];
        
        [dataDic removeAllObjects];
        [dataDic setObject:[NSString stringWithFormat:@"%f",loc.latitude] forKey:@"Latitude"];
        [dataDic setObject:[NSString stringWithFormat:@"%f",loc.longitude] forKey:@"Longitude"];
        
        CLLocation *currentLocation = [[CLLocation alloc]
                                       initWithLatitude:[[dataDic objectForKey:@"Latitude"] floatValue]
                                       longitude:[[dataDic objectForKey:@"Longitude"] floatValue]];
        
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        
        [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemark, NSError *error) {
            
            //set the title if we got any placemarks...
            if (placemark.count > 0)
            {
                CLPlacemark *topResult = [placemark objectAtIndex:0];
                [dataDic setObject:topResult.addressDictionary forKey:@"Address"];
                
            }
            
        }];
        
    }
    
    
}

#pragma mark - UIButton Actions

- (IBAction)doneBtnAction:(id)sender {
    
        [self.delegate getLocation:dataDic];
        [self.navigationController popViewControllerAnimated:YES];
}

-(void)showAnnotationOnMap {
    
    NSMutableArray *annotationsToRemove = [[NSMutableArray alloc] initWithArray: mapView.annotations];
    //Remove the object userlocation
    [annotationsToRemove removeObject: mapView.userLocation];
    //Remove all annotations in the array from the mapView
    [mapView removeAnnotations: annotationsToRemove];
    
    
    CLLocationCoordinate2D loc = [self.locationForAnnotation coordinate];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(loc, 1000, 1000);
    [mapView setRegion:region animated:YES];
    
    myAnnotation = [[MyAnnotation alloc] init];
    
    myAnnotation.coordinate = CLLocationCoordinate2DMake(self.locationForAnnotation.coordinate.latitude,self.locationForAnnotation.coordinate.longitude);
    myAnnotation.title = @"NA";
    
    
    CLLocation *currentLocation = [[CLLocation alloc]
                                   initWithLatitude:self.locationForAnnotation.coordinate.latitude
                                   longitude:self.locationForAnnotation.coordinate.longitude];
    
    
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemark, NSError *error) {
        
        //set the title if we got any placemarks...
        if (placemark.count > 0)
        {
            CLPlacemark *topResult = [placemark objectAtIndex:0];
            myAnnotation.title = [NSString stringWithFormat:@"%@",topResult.addressDictionary[@"Name"]];
            myAnnotation.subtitle = [NSString stringWithFormat:@"%@, %@",topResult.addressDictionary[@"State"],topResult.addressDictionary[@"Country"]];
        }
        
    }];
    
    [mapView addAnnotation:myAnnotation];
}

//-(void)getLocation:(NSDictionary *)dict {
//    /*
//     myAnnotation.title = [NSString stringWithFormat:@"%@, %@",topResult.addressDictionary[@"Name"],topResult.addressDictionary[@"City"]];
//     myAnnotation.subtitle = [NSString stringWithFormat:@"%@, %@",topResult.addressDictionary[@"Country"],topResult.addressDictionary[@"ZIP"]];
//     */
//    //  NSLog(@"Location %@",dict);
//    
//    NSMutableDictionary *dictAddress = dict[@"Address"];
//    NSArray *keyArray=[dictAddress allKeys];
//    NSMutableArray *addressArr = [NSMutableArray new];
//    
//    //Latitude & Longitude
//    strLat = [dict objectForKey:@"Latitude"];
//    strLong = [dict objectForKey:@"Longitude"];
//    //Name
//    if ([keyArray containsObject:@"Name"]) {
//        [addressArr addObject:[dictAddress objectForKey:@"Name"]];
//    }
//    
//    //City
//    if ([keyArray containsObject:@"City"]) {
//        [addressArr addObject:[dictAddress objectForKey:@"City"]];
//    }
//    else if ([keyArray containsObject:@"SubAdministrativeArea"]) {
//        [addressArr addObject:[dictAddress objectForKey:@"SubAdministrativeArea"]];
//    }
//    //State
//    if ([keyArray containsObject:@"State"]) {
//        [addressArr addObject:[dictAddress objectForKey:@"State"]];
//    }
//    //Country
//    if ([keyArray containsObject:@"Country"]) {
//        [addressArr addObject:[dictAddress objectForKey:@"Country"]];
//    }
//    //Zip
//    if ([keyArray containsObject:@"ZIP"]) {
//        [addressArr addObject:[dictAddress objectForKey:@"ZIP"]];
//    }
//    
//    NSMutableString *str = [NSMutableString new];
//    for (NSString *temp in addressArr) {
//        [str appendString:[NSString stringWithFormat:@"%@, ",temp]];
//    }
//    
//    [self.txtWorkAddress setText:str];
//    //    _placeHolder_WorkAddress.hidden = YES;
//}

@end
