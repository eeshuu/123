//
//  DetailViewController.h
//  Test
//
//  Created by cis on 24/06/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
@interface DetailViewController : UIViewController<MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,UINavigationControllerDelegate>
@property(nonatomic,retain)NSMutableDictionary *dictPropertyDetail;
@property(nonatomic,retain)NSMutableArray *arrayPropertyList;
@property NSInteger propertyIndex;
@end
