//
//  RegisterVC.m
//  RexConnect
//
//  Created by cis on 6/15/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "RegisterVC.h"
#import "WLSharedImagePicker.h"
#import "YKImageCropperViewController.h"
#import "Constant.h"
#import "SlideNavigationController.h"
#import "ViewController.h"
#import "HomeVC.h"
#import "UIImageView+WebCache.h"
@interface RegisterVC ()<UIImagePickerControllerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIPickerViewDelegate,UITextFieldDelegate>
{
    NSData *imageData;
    UIImage *imgProfile;
    NSMutableArray *imageArray;
    NSMutableDictionary *dictLoginInfo;
}
@property (strong, nonatomic) IBOutlet UIButton *btnProfileImage;

@property (strong, nonatomic) IBOutlet UILabel *lblSignup;
@property (strong, nonatomic) IBOutlet UITextField *txtUsername;
@property (strong, nonatomic) IBOutlet UITextField *txtpassword;
@property (strong, nonatomic) IBOutlet UITextField *txtPhoneNUmber;
@property (strong, nonatomic) IBOutlet UITextField *txtCompany;
@property (strong, nonatomic) IBOutlet UITextField *txtORN;
@property (strong, nonatomic) IBOutlet UITextField *txtBrokerCard;
@property (strong, nonatomic) IBOutlet UIButton *btnRegister;
@property (strong, nonatomic) IBOutlet UITextField *txtEmailID;
@end
enum {
    MHPhotoLibrary = 0,
    MHTakeFromCamera = 1
};

@implementation RegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    imageArray=[[NSMutableArray alloc]init];
    [self setupUI];
    if (_is_edit) {
        dictLoginInfo=[[NSUserDefaults standardUserDefaults] objectForKey:USERDEFAULT_LOGININFO];
        [self setData:dictLoginInfo];
        self.navigationController.navigationBarHidden=YES;
        _lblSignup.text=@"Edit Pofile";
        [self.txtUsername setEnabled:YES];
        [self.txtUsername setTextColor:[UIColor whiteColor]];

        [self.txtEmailID setEnabled:NO];
        [self.txtEmailID setTextColor:[UIColor whiteColor]];
        [self.btnProfileImage setImage:[UIImage imageNamed:@"pick_img.png"] forState:UIControlStateNormal];
        UIImageView *imgProfileNew=[[UIImageView alloc]init];
        
        [imgProfileNew sd_setImageWithURL:[NSURL URLWithString:[dictLoginInfo objectForKey:@"profile_img"]] placeholderImage:[UIImage imageNamed:@"pick_img.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            if (error) {
            [self.btnProfileImage setImage:[UIImage imageNamed:@"User_Male_Circle-100"] forState:UIControlStateNormal];
            }
            else{
                [self.btnProfileImage setImage:image forState:UIControlStateNormal];
                [self.btnProfileImage.layer setCornerRadius:self.btnProfileImage.frame.size.height/2];
                self.btnProfileImage.layer.borderWidth=1.0f;
                self.btnProfileImage.layer.borderColor=[[UIColor lightGrayColor] CGColor];
                imgProfile=image;
            }
        }];
        [self.view updateConstraints];
    }
    else{
        self.navigationController.navigationBarHidden=YES;
      _lblSignup.text=@"Sign Up";
        [self.txtpassword setEnabled:YES];
        [self.txtpassword setTextColor:[UIColor whiteColor]];
        [self.txtUsername setEnabled:YES];
        [self.txtUsername setTextColor:[UIColor whiteColor]];
        //    [self.txtpassword removeFromSuperview];
        [self.txtEmailID setEnabled:YES];
        [self.txtEmailID setTextColor:[UIColor whiteColor]];
        
        [self.view updateConstraints];
    }
    
    
   

    
}

-(void)viewDidDisappear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
   
}
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    if (_is_edit)
        return YES;
    else
        return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - UIImagePicker delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    __unsafe_unretained typeof(self) weakSelf = self;
    
    [picker dismissViewControllerAnimated:YES completion:^{
        // Add root view controller
        UIImage *originalImage = info[UIImagePickerControllerOriginalImage];
        YKImageCropperViewController *cropperVc = [[YKImageCropperViewController alloc] initWithImage:originalImage];
        
        UINavigationController *nvc = [[UINavigationController alloc] initWithRootViewController:cropperVc];
        [weakSelf presentViewController:nvc animated:YES completion:NULL];
        
        cropperVc.cancelHandler = ^() {
            [nvc dismissViewControllerAnimated:YES completion:NULL];
        };
        
        cropperVc.doneHandler = ^(UIImage *editedImage) {
            editedImage=[[AppDelegate sharedInstance] resizeImage:editedImage resizeSize:CGSizeMake(150,150)];
            NSData *data = UIImageJPEGRepresentation(editedImage, 0.2f);
            
            [weakSelf.btnProfileImage setImage:[UIImage imageWithData:data] forState:UIControlStateNormal];
            imageData = UIImageJPEGRepresentation(editedImage, 0.2);
            [imageArray removeAllObjects];
            [imageArray addObject:editedImage];
            imgProfile=editedImage;
            [nvc dismissViewControllerAnimated:YES completion:NULL];
            [self.btnProfileImage.layer setCornerRadius:self.btnProfileImage.frame.size.height/2];
            self.btnProfileImage.layer.borderWidth=1.0f;
            self.btnProfileImage.layer.borderColor=[[UIColor lightGrayColor] CGColor];
         };
        
    }];
    
   
}



- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark-Action
-(void)setupUI
{
    
    
    UIView *leftViewUserName=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    UIImageView *imgUserName=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"fullname_hint.png"]];
    [imgUserName setFrame:CGRectMake(10, 5, 20, 20)];
    [imgUserName setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewUserName addSubview:imgUserName];
    _txtUsername.leftViewMode = UITextFieldViewModeAlways;
    [_txtUsername setLeftView:leftViewUserName];
    
    UIView *leftViewPassword=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    UIImageView *imgPassword=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pass_lock.png"]];
    [imgPassword setFrame:CGRectMake(10, 5, 20, 20)];
    [imgPassword setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewPassword addSubview:imgPassword];
    _txtpassword.leftViewMode = UITextFieldViewModeAlways;
    [_txtpassword setLeftView:leftViewPassword];
    
    
    UIView *leftViewEmail=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    UIImageView *imgEmail=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"email_at.png"]];
    [imgEmail setFrame:CGRectMake(10, 5, 20, 20)];
    [imgEmail setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewEmail addSubview:imgEmail];
    _txtEmailID.leftViewMode = UITextFieldViewModeAlways;
    [_txtEmailID setLeftView:leftViewEmail];
    
    UIView *leftViewPhoneNumber=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    UIImageView *imgPhonenumber=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"phone_hint.png"]];
    [imgPhonenumber setFrame:CGRectMake(10, 5, 20, 20)];
    [imgPhonenumber setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewPhoneNumber addSubview:imgPhonenumber];
    _txtPhoneNUmber.leftViewMode = UITextFieldViewModeAlways;
    [_txtPhoneNUmber setLeftView:leftViewPhoneNumber];
    
    
    
    UIView *leftViewCompany=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    UIImageView *imgCompany=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"address_hint.png"]];
    [imgCompany setFrame:CGRectMake(10, 5, 20, 20)];
    [imgCompany setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewCompany addSubview:imgCompany];
    _txtCompany.leftViewMode = UITextFieldViewModeAlways;
    [_txtCompany setLeftView:leftViewCompany];
    
    
    UIView *leftViewORN=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 34)];
    UIImageView *imgORN=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"orn.png"]];
    [imgORN setFrame:CGRectMake(6, 5, 24, 24)];
    [imgORN setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewORN addSubview:imgORN];
    _txtORN.leftViewMode = UITextFieldViewModeAlways;
    [_txtORN setLeftView:leftViewORN];
    
    
    UIView *leftViewBrokerNumber=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 34)];
    UIImageView *imgBrokerNumber=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"brokerCardNumber.png"]];
    [imgBrokerNumber setFrame:CGRectMake(6, 5, 24, 24)];
    [imgBrokerNumber setContentMode:UIViewContentModeScaleAspectFit];
    [leftViewBrokerNumber addSubview:imgBrokerNumber];
    _txtBrokerCard.leftViewMode = UITextFieldViewModeAlways;
    [_txtBrokerCard setLeftView:leftViewBrokerNumber];
    
   
    
    
    [_txtEmailID setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtpassword setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtUsername setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtPhoneNUmber setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtCompany setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtORN setValue:[UIColor lightGrayColor]  forKeyPath:@"_placeholderLabel.textColor"];
    [_txtBrokerCard setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    
}


/*select image*/

- (IBAction)chooseImage:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle: nil
                                                             delegate: self
                                                    cancelButtonTitle: @"Cancel"
                                               destructiveButtonTitle: nil
                                                    otherButtonTitles: @"Choose from existing",@"Take a new photo", nil];
    [actionSheet showInView:self.view];
}
/*image picker sheet controller*/
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex==MHTakeFromCamera) {
        [self showCameraToTakePic];
    } else if (buttonIndex == MHPhotoLibrary){
        [self letUserToChooseFromPhotoLibrary];
    }
}

/*mange the camera dialog*/
- (void)showCameraToTakePic {
    WLSharedImagePicker *sharedImagePicker = [WLSharedImagePicker shareImagePickerController];
    sharedImagePicker.delegate = self;
    sharedImagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:sharedImagePicker animated:YES completion:NULL];
}
/*mange the photo gallry */
- (void)letUserToChooseFromPhotoLibrary {
     WLSharedImagePicker *sharedImagePicker = [WLSharedImagePicker shareImagePickerController];
    sharedImagePicker.delegate = self;
    sharedImagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:sharedImagePicker animated:YES completion:NULL];
}


-(BOOL)isValidate
{
    _txtUsername.text =[_txtUsername.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtpassword.text =[_txtpassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtEmailID.text =[_txtEmailID.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtPhoneNUmber.text =[_txtPhoneNUmber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtCompany.text =[_txtCompany.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtpassword.text =[_txtpassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtORN.text =[_txtORN.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtpassword.text =[_txtpassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtBrokerCard.text =[_txtBrokerCard.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
   
    
    if (!_txtUsername.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter User Name" andTitle:@"Message"];
        return NO;
    }
    else if (!_txtpassword.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Password" andTitle:@"Message"];
        return NO;
    }
    else if (!_txtEmailID.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Email ID" andTitle:@"Message"];
        return NO;
    }
    else if (![[ApplicationManager sharedManagerInstance]emailAddressIsValid:_txtEmailID.text]) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Valid Email ID" andTitle:@"Message"];
        return NO;
    }
    else if (!_txtPhoneNUmber.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Phone Number Field" andTitle:@"Message"];
        return NO;
    }
    else if (!_txtORN.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter ORN Number" andTitle:@"Message"];
        return NO;
    }
    else if (!_txtBrokerCard.text.length) {
        [[ApplicationManager sharedManagerInstance] showAlert:@"Please Enter Broker Card" andTitle:@"Message"];
        return NO;
    }
    else{
       return true;
    }
    
}


- (IBAction)btnRegisterAction:(id)sender {
    [self.view endEditing:YES];
    if (!_is_edit) {
        if ([self isValidate]) {
            if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
                
                NSString *strProfileImage=@"";
                
                if (imgProfile != Nil) {
                    strProfileImage=[UIImagePNGRepresentation(_btnProfileImage.imageView.image) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
                }

                
                
                [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                NSDictionary *parameters=@{@"tag":@"agentsignup",@"signup_name": _txtUsername.text,@"signup_pass":_txtpassword.text,@"signup_email":_txtEmailID.text,@"phone":_txtPhoneNUmber.text,@"company":_txtCompany.text,@"broker_card_no":_txtBrokerCard.text,@"orn_no":_txtORN.text,@"profile_img":strProfileImage};
                
                NSString *urlStr=COMMON_URL(LONGIN_URL)
                [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:urlStr] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
                    
                    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                    if (data) {
                        if ([data[@"success"] boolValue]) {
                            [[NSUserDefaults standardUserDefaults] setValue:[[data objectForKey:@"responseData"]objectForKey:@"agentsignup"] forKey:USERDEFAULT_LOGININFO];
                            [[NSUserDefaults standardUserDefaults] synchronize];
                            [AppDelegate sharedInstance].is_login=YES;
                            [[SlideNavigationController sharedInstance].leftMenu  viewDidLoad];
                            [AppDelegate sharedInstance].id_user_login=[[[data objectForKey:@"responseData"]objectForKey:@"agentlogin"] objectForKey:@"id"];
                            
                            NSArray *arrayController=self.navigationController.viewControllers;
                            for (id vc in arrayController) {
                                if ([vc isKindOfClass:[HomeVC class]]) {
                                    [self.navigationController popToRootViewControllerAnimated:YES];
                                }
                                break;
                            }
                        }
                        else {
                            [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                        }
                    }
                    else {
                        [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
                    }
                    
                }];
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
            }
            
        }
    }else{
        if ([self isValidate]) {
            if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
                
//                UIImage *imageprofile=[[ApplicationManager sharedManagerInstance] compressForUpload:_btnProfileImage.imageView.image scale:.5];
          
                
                NSString *strProfileImage=@"";
                
                if (imgProfile != Nil) {
                    strProfileImage=[UIImagePNGRepresentation(_btnProfileImage.imageView.image) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
                }
                
                
                [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                NSDictionary *parameters=@{@"tag":@"agentupdate",@"u_id": [dictLoginInfo objectForKey:@"id"],@"name": _txtUsername.text,@"password":_txtpassword.text,@"email":_txtEmailID.text,@"phone":_txtPhoneNUmber.text,@"company":_txtCompany.text,@"broker_card_no":_txtBrokerCard.text,@"orn_no":_txtORN.text,@"profile_img":strProfileImage};
                
                NSString *urlStr=COMMON_URL(LONGIN_URL)
                [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:urlStr] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
                    
                    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                    if (data) {
                        if ([data[@"success"] boolValue]) {
                            [[NSUserDefaults standardUserDefaults] setValue:[[data objectForKey:@"responseData"]objectForKey:@"agentupdate"] forKey:USERDEFAULT_LOGININFO];
                            [[NSUserDefaults standardUserDefaults] synchronize];
                            [AppDelegate sharedInstance].is_login=YES;
                            [[SlideNavigationController sharedInstance].leftMenu  viewDidLoad];
                            [AppDelegate sharedInstance].id_user_login=[[[data objectForKey:@"responseData"]objectForKey:@"agentupdate"] objectForKey:@"id"];
                            
                            NSArray *arrayController=self.navigationController.viewControllers;
                            for (id vc in arrayController) {
                                if ([vc isKindOfClass:[ViewController class]]) {
                                    [self.navigationController popToRootViewControllerAnimated:YES];
                                }
                                break;
                            }
                            [[ApplicationManager sharedManagerInstance] showAlert:@"Profiles sucessfully updated" andTitle:alertTitle];
                        }
                        else {
                            [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                        }
                    }
                    else {
                        [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
                    }
                    
                }];
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
            }
            
        }
    }
    
   
}



/*add edit mode data*/
-(void)setData:(NSMutableDictionary *)dict
{
    [_btnRegister setTitle:@"Edit Profile" forState:UIControlStateNormal];
    
    [self.txtEmailID setText:[dict objectForKey:@"login_email"]];
    [self.txtUsername setText:[dict objectForKey:@"name"]];
    [self.txtpassword setText:[dict objectForKey:@"password"]];
    [self.txtPhoneNUmber setText:[dict objectForKey:@"phone"]];
    [self.txtCompany setText:[dict objectForKey:@"company"]];
    [self.txtORN setText:[dict objectForKey:@"orn_no"]];
    [self.txtBrokerCard setText:[dict objectForKey:@"brokercardno"]];
    NSURL *imgURL=[NSURL URLWithString:[dict objectForKey:@"profile_img"]];
    
    double delayInSeconds = 2.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        UIImageView *img=[[UIImageView alloc]init];
        [img sd_setImageWithURL:imgURL placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            if (error) {
                [self.btnProfileImage setImage:[UIImage imageNamed:@"User_Male_Circle-100.png"] forState:UIControlStateNormal];
            }
            else{
                [self.btnProfileImage setImage:image forState:UIControlStateNormal];
                [self.btnProfileImage setClipsToBounds:YES];
                [self.btnProfileImage.layer setCornerRadius:self.btnProfileImage.frame.size.height/2];
                self.btnProfileImage.layer.borderWidth=1.0f;
                self.btnProfileImage.layer.borderColor=[[UIColor lightGrayColor] CGColor];
            }
        }];
        

    });
    
    
    [self.txtpassword setEnabled:NO];
    [self.txtpassword setTextColor:[UIColor whiteColor]];
    [self.txtUsername setEnabled:NO];
    [self.txtUsername setTextColor:[UIColor whiteColor]];
//    [self.txtpassword removeFromSuperview];
    [self.txtEmailID setEnabled:NO];
    [self.txtEmailID setTextColor:[UIColor whiteColor]];
    
    [self.view updateConstraints];
    

}
@end
