//
//  SearchView.h
//  IDTechDriveIPhone
//
//  Created by cis on 6/12/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SAMenuDropDown.h"
#import "NMRangeSlider.h"
#import "DoubleSlider.h"
@protocol SearchViewDelegate;

@interface SearchView : UIView <UITextFieldDelegate,SAMenuDropDownDelegate>{
    SAMenuDropDown *dropLocation;
    SAMenuDropDown *dropBedRoom;
    SAMenuDropDown *dropBathroom;
    SAMenuDropDown *dropProperty;
    NSMutableArray *arrayLocation;
    NSMutableArray *arrayBedRoom;
    NSMutableArray *arrayBathroom;
    NSMutableArray *arrayProperty;
}

@property (weak, nonatomic) id <SearchViewDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIButton *btnRent;
@property (strong, nonatomic) IBOutlet UIButton *btnSale;

@property (strong, nonatomic) IBOutlet UIView *middleContainer;
@property (weak, nonatomic) IBOutlet UITextField *textFrom;
@property (weak, nonatomic) IBOutlet UITextField *textTo;
@property (weak, nonatomic) IBOutlet UIButton *btnLocation;
@property (weak, nonatomic) IBOutlet UIButton *btnBedroom;
@property (weak, nonatomic) IBOutlet UILabel *lblLocation;
@property (weak, nonatomic) IBOutlet UILabel *lblBedroom;
@property (weak, nonatomic) IBOutlet UILabel *lblBathRoom;
@property (weak, nonatomic) IBOutlet UILabel *lblPropertyType;
@property (weak, nonatomic) IBOutlet UIButton *btnBathRoom;
@property (weak, nonatomic) IBOutlet UIButton *btnPropertyType;

@property (strong, nonatomic) IBOutlet UIView *viewProperty;
@property (strong, nonatomic) IBOutlet UIView *viewLocation;
@property (strong, nonatomic) IBOutlet UIView *viewBedroom;
@property (strong, nonatomic) IBOutlet UIView *viewBathroom;
@property (strong, nonatomic) IBOutlet UIView *viewContainer;
@property (strong, nonatomic) IBOutlet UIView *viewPriceSlider;
@property (strong, nonatomic) IBOutlet NMRangeSlider *priceSlider;
@property (weak, nonatomic) IBOutlet UILabel *lowPrice;
@property (weak, nonatomic) IBOutlet UILabel *highPrice;
 @property (strong, nonatomic) IBOutlet  DoubleSlider *slider;
-(IBAction)customOpen:(UIWindow *)window;
-(IBAction)customClose:(id)sender;
- (IBAction)takeLocation:(id)sender;
- (IBAction)takeBedRoom:(id)sender;
- (IBAction)TakeBathroom:(id)sender;
- (IBAction)close:(id)sender;
@end

@protocol SearchViewDelegate <NSObject>

-(void)SearchView:(SearchView *)search allData:(NSDictionary *)dictAllInfo;
@end