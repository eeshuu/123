//
//  SearchView.m
//  IDTechDriveIPhone
//
//  Created by cis on 6/12/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import "SearchView.h"
#import "DoubleSlider.h"
#import "Constant.h"

@implementation SearchView
{
    DoubleSlider *slider;
}
-(id)init{
    
    self = [[[NSBundle mainBundle] loadNibNamed:@"SearchView" owner:nil  options:nil] lastObject];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [self setFrame:window.frame];
    [self.btnRent setSelected:YES];
    
//    [_middleContainer.layer setCornerRadius:8];
    [_middleContainer.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_middleContainer.layer setBorderWidth:1.0f];
    [_middleContainer.layer setShadowColor:[UIColor blackColor].CGColor];
    [_middleContainer.layer setShadowOpacity:0.8];
    [_middleContainer.layer setShadowRadius:3.0];
    [_middleContainer.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    

    
    arrayLocation = [[NSMutableArray alloc]initWithObjects:@"any",@"Abu Dhabi Gate City", @"Airport Road", @"Akoya",
                     @"Al Barari",@"Al Barsha",@"Al Bateen", @"Al Falah City",
                     @"Al Furjan", @"Al Garhoud", @"Al Ghadeer",@"Al Hamra Village",
                     @"Al Karamah", @"Al Khail Heights", @"Al Khalidiya", @"Al Mamzar",
                     @"Al Manhal", @"Al Maqtaa", @"Al Markaz", @"Al Mina", @"Al Muneera",
                     @"Al Mushrif", @"Al Nahda Abu Dhabi", @"Al Nahyan",@"Al Nahyan Camp",
                     @"Al Najda Street", @"Al Nasr Street", @"Al Qurm",@"Al Qusais",
                     @"Al Raha",@"Al Raha Beach",@"Al Raha Gardens",
                     @"Al Raha Golf Gardens",@"Al Rahba",@"Al Rawdah",@"Al Reef",
                     @"Al Reem",@"Al Reem Island",@"Al Sufouh",@"Al Warqaa",@"Al Wasl",
                     @"Arabian Ranches",@"Baniyas",@"Between Two Bridges",
                     @"Business Bay",@"Corniche Area",@"Corniche Road",
                     @"Culture Village",@"Deira",@"DIFC",@"Discovery Gardens",
                     @"Downtown Burj Dubai",@"Downtown Jebel Ali",
                     @"Dubai Healthcare City",@"Dubai Investment Park",@"Dubai Marina",
                     @"Dubai Waterfront",@"Dubai World Central",@"Dubailand",
                     @"Electra Street",@"Emirates Hills",@"Festival City",@"Greens",
                     @"Hamdan Street",@"Hydra Village",@"IMPZ",@"International City",
                     @"JBR",@"Jebel Ali",@"Jumeirah",@"Jumeirah Heights",
                     @"Jumeirah Islands",@"Jumeirah Lake Towers",@"Jumeirah Park",
                     @"Jumeirah Village Circle",@"Jumeirah Village Triangle",@"Khalidia",
                     @"Khalifa City A",@"Khalifa City B",@"Lakes",@"Manama",@"Meadows",
                     @"Meydan City",@"Mirdiff",@"Mohamed Bin Zayed City",
                     @"Mohammad Bin Rashid City",@"Motor City",@"Muroor Area",@"Mushrif",
                     @"Mussafah",@"Old Town",@"Palm Jumeirah",@"Reem",@"Saadiyat Island",
                     @"Salam Street",@"Sheikh Zayed Road",@"Silicon Oasis",
                     @"Sports City",@"Springs",@"TECOM",@"The Hills",@"The Views",
                     @"The Villa",@"The World Islands",@"Tourist Club Area",
                     @"Umm Al Quwain Marina",@"Umm Ramool",@"Umm Suqueim",
                     @"Victory Heights", nil];

    arrayBedRoom=[[NSMutableArray alloc]initWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9", @"ST", nil];
    arrayBathroom=[[NSMutableArray alloc]initWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12", nil];
    arrayProperty=[[NSMutableArray alloc]initWithObjects:@"Office",@" Apartment",@" Retail", nil];
    
    
    dropLocation=[[SAMenuDropDown alloc] initWithWithSource:_btnLocation menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropLocation setDelegate:self];
    [dropLocation setUpItemDataSourceWithNames:arrayLocation subtitles:nil imageNames:nil];
    
    
    
    dropProperty=[[SAMenuDropDown alloc] initWithWithSource:_btnPropertyType menuHeight:120 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropProperty setDelegate:self];
    [dropProperty setUpItemDataSourceWithNames:arrayProperty subtitles:nil imageNames:nil];
    
    
    
    dropBedRoom=[[SAMenuDropDown alloc] initWithWithSource:_btnBedroom menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropBedRoom setDelegate:self];
    [dropBedRoom setUpItemDataSourceWithNames:arrayBedRoom subtitles:nil imageNames:nil];
    
    dropBathroom=[[SAMenuDropDown alloc] initWithWithSource:_btnBathRoom menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropBathroom setDelegate:self];
    [dropBathroom setUpItemDataSourceWithNames:arrayBathroom subtitles:nil imageNames:nil];
    
     _lblLocation.text = [arrayLocation objectAtIndex:0];
     _lblBedroom.text = [arrayBedRoom objectAtIndex:0];
     _lblBathRoom.text = [arrayBathroom objectAtIndex:0];
    [_btnRent setSelected:YES];
    
    [_lblBedroom setText:@"Bedrooms"];
    [_lblBathRoom setText:@"Bathrooms"];
    _lblBedroom.tag=-1;
    _lblBathRoom.tag=-1;
    _lblPropertyType.tag=1;
    
    [_viewBathroom.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewBathroom.layer setBorderWidth:1.0f];
    [_viewBedroom.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewBedroom.layer setBorderWidth:1.0f];
    [_viewLocation.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewLocation.layer setBorderWidth:1.0f];
    [_viewProperty.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [_viewProperty.layer setBorderWidth:1.0f];
    [self RadioButtonAction:_btnRent];
    
    

    
   
    
    slider = [[DoubleSlider alloc]initWithFrame:CGRectMake(0, 0, _btnBathRoom.frame.size.width, _viewPriceSlider.frame.size.height) minValue:0 maxValue:1000 barHeight:10];
    if (IS_IPHONE_6) {
        slider = [[DoubleSlider alloc]initWithFrame:CGRectMake(0, 0, _btnBathRoom.frame.size.width+55, _viewPriceSlider.frame.size.height) minValue:0 maxValue:1000 barHeight:10];
    }

    if (IS_IPHONE_6_PLUS) {
        slider = [[DoubleSlider alloc]initWithFrame:CGRectMake(0, 0, _btnBathRoom.frame.size.width+95, _viewPriceSlider.frame.size.height) minValue:0 maxValue:1000 barHeight:10];
    }

    
    [slider addTarget:self action:@selector(changeDiscount:) forControlEvents:UIControlEventValueChanged];
    slider.tag = 101; //for testing purposes only
    [slider moveSlidersToPosition:[NSNumber numberWithInteger: 0]rightSlider:[NSNumber numberWithInteger: 100] animated:YES];
    [self changeDiscount:slider];
    [self.viewPriceSlider addSubview:slider];
    
    
    return self;
}



-(IBAction)customOpen:(UIWindow *)window
{
    [window addSubview:self];
    self.transform = CGAffineTransformMakeScale(0, 0);
    self.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.alpha = 1;
        self.transform = CGAffineTransformMakeScale(1, 1);
    }];
    [self updateConstraintsIfNeeded];
}

- (IBAction)TakeBathroom:(id)sender {
    dropLocation.hidden = YES;
    dropBedRoom.hidden = YES;
    dropBathroom.hidden = NO;
    [dropBathroom self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}

-(IBAction)customClose:(id)sender
{
    
    NSString *strPropertyType;
    
    if (_lblPropertyType.tag >0) {
        strPropertyType=_lblPropertyType.text;
    }
    
    NSString *strBathRoom=@"";
    NSString *strBedRoom=@"";
    
    if (_lblBedroom.tag >-1) {
        strBedRoom=[arrayBedRoom objectAtIndex:_lblBedroom.tag];
    }
    
    if (_lblBathRoom.tag >-1) {
        strBathRoom=[arrayBedRoom objectAtIndex:_lblBathRoom.tag];
    }
    
    NSDictionary *dictAllInfo =@{@"type":([_btnRent isSelected])?@"Rent":@"Sale",@"location": self.lblLocation.text, @"bedroom": strBedRoom, @"bathroom": strBedRoom,@"from": [NSString stringWithFormat:@"%.0f",slider.minSelectedValue*1000000], @"to": [NSString stringWithFormat:@"%.0f",slider.maxSelectedValue*1000000]};
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(SearchView:allData:)])  {
        [_delegate SearchView:self allData:(NSDictionary *)dictAllInfo];
    }

    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"searchAction" object:nil];
     self.transform = CGAffineTransformMakeScale(1, 1);

    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

- (IBAction)takeLocation:(id)sender {
    dropLocation.hidden = NO;
    dropBedRoom.hidden = YES;
    dropBathroom.hidden = YES;
    dropProperty.hidden = YES;
    [_slider setHidden:YES];
     [dropLocation self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}

- (IBAction)takeBedRoom:(id)sender {
    dropLocation.hidden = YES;
    dropBedRoom.hidden = NO;
    dropBathroom.hidden = YES;
     dropProperty.hidden = YES;
    [_slider setHidden:YES];
    [dropBedRoom self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}
- (IBAction)takeProperty:(id)sender {
    dropLocation.hidden = YES;
    dropBedRoom.hidden = YES;
    dropBathroom.hidden = YES;
    dropProperty.hidden = NO;
    [_slider setHidden:YES];
    [dropProperty self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}
- (IBAction)RadioButtonAction:(UIButton *)sender {
    
    if (sender == self.btnRent) {
        [self.btnRent setSelected:YES];
        [self.btnRent setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f green:133.0f/255.0f blue:128.0f/255.0f alpha:1]];
        [self.btnSale setBackgroundColor:[UIColor whiteColor]];
        [self.btnSale setSelected:NO];
    }
    else {
        [self.btnSale setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f green:133.0f/255.0f blue:128.0f/255.0f alpha:1]];
        [self.btnRent setBackgroundColor:[UIColor whiteColor]];
        [self.btnRent setSelected:NO];
        [self.btnSale setSelected:YES];
    }
}

#pragma mark - textField delegate - 

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - custom delegate-

- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex{
   
    if (menuSender == dropLocation) {
        _lblLocation.text = [arrayLocation objectAtIndex:buttonIndex];
        dropLocation.hidden = YES;
        
    }else if (menuSender == dropBedRoom){
        _lblBedroom.text = [arrayBedRoom objectAtIndex:buttonIndex];
        _lblBedroom.tag=buttonIndex+1;
        dropBedRoom.hidden = YES;
    }
    else if (menuSender == dropBathroom){
        _lblBathRoom.text = [arrayBathroom objectAtIndex:buttonIndex];
        _lblBathRoom.tag=buttonIndex+1;
        dropBathroom.hidden = YES;
    }
    else if (menuSender == dropProperty){
        _lblPropertyType.text = [arrayProperty objectAtIndex:buttonIndex];
        _lblPropertyType.tag=buttonIndex+1;
        dropProperty.hidden = YES;
    }
    [slider setHidden:NO];
}
- (IBAction)close:(id)sender {
    [UIView transitionWithView:self duration:.5 options:UIViewAnimationOptionTransitionCrossDissolve animations:^(void){
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}
/*discount slider change event*/
-(IBAction)changeDiscount:(DoubleSlider *)sender
{
    [_lowPrice setText:[NSString stringWithFormat:@"AED %.0f",sender.minSelectedValue*1000000]];
    [_highPrice setText:[NSString stringWithFormat:@"AED %.0f",sender.maxSelectedValue*1000000]];
}
@end
