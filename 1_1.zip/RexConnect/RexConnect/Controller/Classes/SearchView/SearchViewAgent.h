//
//  SearchViewAgent.h
//  Test
//
//  Created by cis on 23/06/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SAMenuDropDown.h"
@protocol SearchViewAgentDelegate;

@interface SearchViewAgent : UIView <UITextFieldDelegate,SAMenuDropDownDelegate>{
    SAMenuDropDown *dropLocation;
    NSMutableArray *arrayLocation;
}
@property (strong, nonatomic) IBOutlet UIView *middleContainer;
@property (strong, nonatomic) IBOutlet UIView *viewDropDownLocation;

@property (weak, nonatomic) id <SearchViewAgentDelegate> delegate;
@property (weak, nonatomic) IBOutlet UIButton *btnAgentLocation;
@property (weak, nonatomic) IBOutlet UILabel *lblAgentLocation;
-(IBAction)customOpen:(UIWindow *)window;
- (IBAction)actionClose:(id)sender;
- (IBAction)takeLocation:(id)sender;

@end
@protocol SearchViewAgentDelegate <NSObject>

-(void)SearchViewAgent:(SearchViewAgent *)search allData:(NSDictionary *)dictAllInfo;
@end