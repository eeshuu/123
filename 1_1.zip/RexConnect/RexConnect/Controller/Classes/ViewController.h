//
//  ViewController.h
//  RexConnect
//
//  Created by Dheerendra on 5/31/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchView.h"
@interface ViewController : UIViewController<SearchViewDelegate>

-(IBAction)btnSearchAction:(id)sender;
@end

