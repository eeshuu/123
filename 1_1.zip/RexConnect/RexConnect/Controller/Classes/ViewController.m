
//  ViewController.m
//  RexConnect
//
//  Created by Dheerendra on 5/31/15.
//  Copyright (c) 2015 Dheerendra. All rights reserved.
//

#import "ViewController.h"
#import "SlideNavigationController.h"
#import "Constant.h"
#import "CellVeiwController.h"
#import "SearchView.h"
#import "DetailViewController.h"
@interface ViewController ()<SlideNavigationControllerDelegate>
{
    NSMutableArray *arryDeals;
    SearchView *searchVc;
}
@property (weak, nonatomic) IBOutlet UITableView *tblDeals;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"Find Deals";
    // Do any additional setup after loading the view, typically from a nib.
 
    self.navigationController.navigationBarHidden=NO;
    arryDeals=[[NSMutableArray alloc]init];

    

  
    /*set up navigation bar*/
    [self setupNavigationBar];
  
   
    if (![AppDelegate sharedInstance].is_search) {
         [self btnSearchAction:nil];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.title=@"Find Deals";
    // Do any additional setup after loading the view, typically from a nib.

   
    self.navigationController.navigationBarHidden=NO;
    arryDeals=[[NSMutableArray alloc]init];

    
    [self loadServerData];
    
    
    /*set up navigation bar*/
    [self setupNavigationBar];
    

}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark-Navigation bar
-(void)setupNavigationBar
{

    UIButton *button  = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    ;
    [button setImage:[[UIImage imageNamed:@"searchIcon"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [button setContentMode:UIViewContentModeScaleAspectFit];
    [button addTarget:self action:@selector(btnSearchAction:) forControlEvents:UIControlEventTouchUpInside];
    [button setTintColor:[UIColor whiteColor]];
//    [button setBackgroundColor:[UIColor redColor]];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem=rightBarButtonItem;
}
#pragma mark-TableView deligate

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arryDeals count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellVeiwController *cell = [tableView dequeueReusableCellWithIdentifier:@"CellVeiwController"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arryDeals objectAtIndex:indexPath.row]];
    /*set*/
    UIView *bgView = [[UIView alloc] init];
    // At least on iOS6 you don't to size the view for this to work.
    bgView.backgroundColor = [UIColor colorWithRed:18.0f/255.0f green:155.0f/255.0f blue:149.0f/255.0f alpha:1];
    cell.selectedBackgroundView = bgView;
    [cell setData:dictData];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    DetailViewController *VC=[self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    
    
    DetailViewController *vc=[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:[NSBundle mainBundle]];
    vc.dictPropertyDetail=[arryDeals objectAtIndex:indexPath.row];
    vc.arrayPropertyList=arryDeals;
    vc.propertyIndex=indexPath.row;
    [self.navigationController pushViewController:vc animated:YES];
}

/**/
-(void)loadServerData
{
//        [_tblDeals reloadData];
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        
       [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters=@{@"tag": @"find_deal",@"location": @"any",@"bedroom": @"any",@"bathroom":@"any",@"price_from":@"",@"price_to":@"",@"min_area":@"",@"max_area":@"",@"p_type": @""};

        
       NSString *strUrl=COMMON_URL(SEARCH_METHOD);
   
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    arryDeals=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"deals"]];
                    [_tblDeals reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }

        }];
        
       
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }

}

-(void)loadServerData_withFilter:(NSDictionary *)dictAllInfo
{
    //        [_tblDeals reloadData];
    if ([[ApplicationManager sharedManagerInstance] isNetworkConnected]) {
        
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
   
        
        
        NSDictionary *parameters=@{@"tag": @"find_deal",@"location": [dictAllInfo objectForKey:@"location"],@"bedroom": [dictAllInfo objectForKey:@"bedroom"],@"bathroom":[dictAllInfo objectForKey:@"bathroom"],@"price_from":[dictAllInfo objectForKey:@"from"],@"price_to":[dictAllInfo objectForKey:@"to"],@"min_area":@"",@"max_area":@"",@"p_type": [dictAllInfo objectForKey:@"type"]};
        
        
        NSString *strUrl=COMMON_URL(SEARCH_METHOD);
        
        [[ApplicationManager sharedManagerInstance] multipartRequestWithURL:[NSURL URLWithString:strUrl] andDataDictionary:parameters andgetData:^(NSDictionary *data, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if ([data[@"success"] boolValue]) {
                    if (![[[data objectForKey:@"responseData"] objectForKey:@"deals"] isKindOfClass:[NSString class]]) {
                        arryDeals=[[NSMutableArray alloc]initWithArray:[[data objectForKey:@"responseData"]objectForKey:@"deals"]];
                    }
                    else{
                        arryDeals=[[NSMutableArray alloc]init];
                    }
                    [_tblDeals reloadData];
                }
                else {
                    [[ApplicationManager sharedManagerInstance] showAlert:data[@"msg"] andTitle:alertTitle];
                }
            }
            else {
                [[ApplicationManager sharedManagerInstance] showAlert:error.description andTitle:alertTitle];
            }
            
        }];
        
        
    }
    else {
        [[ApplicationManager sharedManagerInstance] showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}



/*manage search button filter action*/
-(IBAction)btnSearchAction:(id)sender
{
    searchVc=[[SearchView alloc]init];
    [searchVc setDelegate:self];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    
    [searchVc customOpen:window];
}

-(void)SearchView:(SearchView *)search allData:(NSDictionary *)dictAllInfo
{
    [self loadServerData_withFilter:dictAllInfo];
}

@end
