//
//  CALayer+ModalAlert.h
//  LMAlertViewDemo
//
//  Created by Lee McDermott on 18/11/2013.
//  Copyright (c) 2013 Bestir Ltd. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface CALayer (ModalAlert)

@end
