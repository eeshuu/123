//
//  LMEmbeddedViewController.h
//  LMAlertViewDemo
//
//  Created by Lee McDermott on 19/11/2013.
//  Copyright (c) 2013 Bestir Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LMAlertView.h"

@interface LMEmbeddedViewController : UIViewController

@property (weak, nonatomic) LMAlertView *alertView;

@end
