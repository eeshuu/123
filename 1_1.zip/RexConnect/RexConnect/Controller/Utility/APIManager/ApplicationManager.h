//
//  ApplicationManager.h
//  Workly
//
//  Created by cis on 12/5/14.
//  Copyright (c) 2014 cis. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
typedef void (^StringConsumer)(NSDictionary* , NSError *);

@interface ApplicationManager : NSObject

+ (id)sharedManagerInstance;

- (BOOL)emailAddressIsValid:(NSString *)emailAddress;
- (BOOL)isNetworkConnected;
- (BOOL)mobileNumberValidator:(NSString *)phone;
+ (void)setBackGroundImage:(id)view;
- (NSDateFormatter *)dateFormatter;
- (void)showAlert:(NSString *)message andTitle:(NSString *)title;

- (void)callMultipartWebService:(NSDictionary *)postData andURL:(NSString *)urlString andImageData:(NSArray *)imageArr andMultiplePicture:(BOOL)isMultiplePicture getData:(StringConsumer) consumer;
- (void)callPostWebService:(NSDictionary *)postData andURL:(NSString *)urlString andgetData:(StringConsumer) consumer;

- (void)callGetWebService:(NSString *)urlString andgetData:(StringConsumer) consumer;

- (NSMutableURLRequest *) multipartRequestWithURL:(NSURL *)url andImageData:(NSArray *)imageArr andDataDictionary:(NSDictionary *) dictionary andMultiplePictureTag:(BOOL)isMultiplePicture;
- (void ) multipartRequestWithURL:(NSURL *)url  andDataDictionary:(NSDictionary *) dictionary andgetData:(StringConsumer) consumer;
- (UIImage *)compressForUpload:(UIImage *)original scale:(CGFloat)scale;

@end
