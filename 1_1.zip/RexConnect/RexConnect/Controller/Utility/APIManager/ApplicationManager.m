//
//  ApplicationManager.m
//  Workly
//
//  Created by cis on 12/5/14.
//  Copyright (c) 2014 cis. All rights reserved.
//

#import "ApplicationManager.h"
#import "Constant.h"
#import "Reachability.h"
#import <UIKit/UIKit.h>
@implementation ApplicationManager

+ (id)sharedManagerInstance {
    
    static ApplicationManager *sharedManager = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[self alloc] init];
    });
    
    return sharedManager;
}



#pragma mark - Validation Methods

- (BOOL)emailAddressIsValid:(NSString *)emailAddress {
    
    NSString *emailRegex =
    @"(?:[a-z0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[a-z0-9!#$%\\&'*+/=?\\^_`{|}"
    @"~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\"
    @"x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-"
    @"z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5"
    @"]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-"
    @"9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21"
    @"-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES[c] %@", emailRegex];
    
    return [emailTest evaluateWithObject:emailAddress];
}

- (BOOL)isNetworkConnected {
    
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return networkStatus != NotReachable;
}

-(BOOL)mobileNumberValidator:(NSString *)phone {
    
    NSError *error = NULL;
    NSDataDetector *detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypePhoneNumber error:&error];
    
    NSRange inputRange = NSMakeRange(0, [phone length]);
    NSArray *matches = [detector matchesInString:phone options:0 range:inputRange];
    
    // no match at all
    if ([matches count] == 0) {
        return NO;
    }
    
    // found match but we need to check if it matched the whole string
    NSTextCheckingResult *result = (NSTextCheckingResult *)[matches objectAtIndex:0];
    
    if ([result resultType] == NSTextCheckingTypePhoneNumber && result.range.location == inputRange.location && result.range.length == inputRange.length) {
        // it matched the whole string
        return YES;
    }
    else {
        // it only matched partial string
        return NO;
    }
}

+ (void)setBackGroundImage:(UIView *)view
{
    if ([UIScreen mainScreen].bounds.size.height >=568) {
        [(UIView *)view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"loginbg_ip5"]]];
    }
    else{
        [(UIView *)view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"loginbg"]]];
    }
}

-(void)setLeftViewModeOfTextfield:(UIScrollView *)scrollView {
    
    for(id textField in [scrollView subviews])
    {
        if([textField isKindOfClass:[UITextField class]] )
        {
            UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 5, 35)];
            [textField setLeftViewMode:(UITextFieldViewModeAlways)];
            [textField setLeftView:leftView];
        }
    }
}

- (NSDateFormatter *)dateFormatter {
    NSDateFormatter *dateFormatterObj = [[NSDateFormatter alloc]init];
    [dateFormatterObj setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [dateFormatterObj setLocale:locale];
    return dateFormatterObj;
}

-(void)showAlert:(NSString *)message andTitle:(NSString *)title {
    
    [[[UIAlertView alloc]initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
}

#pragma mark - WebServices Methods
/*multi part data*/
- (void)callMultipartWebService:(NSDictionary *)postData andURL:(NSString *)urlString andImageData:(NSArray *)imageArr andMultiplePicture:(BOOL)isMultiplePicture getData:(StringConsumer) consumer {
    
    NSMutableURLRequest *request = [self multipartRequestWithURL:[NSURL URLWithString:urlString] andImageData:imageArr andDataDictionary:postData andMultiplePictureTag:isMultiplePicture];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue]  completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSString *responseString=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        //  NSLog(@"%@",responseString);
        if ([(NSHTTPURLResponse *)response statusCode]==200)
        {
            
            NSError* error;
            NSDictionary *json = [NSJSONSerialization
                                  JSONObjectWithData:data
                                  options:kNilOptions
                                  error:&error];
            
            consumer(json,nil);
            
        }
        else
        {
            consumer(nil,error);
        }
    }];
}


/*json post*/
- (void)callPostWebService:(NSDictionary *)postData andURL:(NSString *)urlString andgetData:(StringConsumer) consumer {
    
    NSError *error;
    NSData *postJsonData = [NSJSONSerialization dataWithJSONObject:postData options:0 error:&error];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:60];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setHTTPBody:postJsonData];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue]  completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSString *responseString=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        //  NSLog(@"%@",responseString);
        if ([(NSHTTPURLResponse *)response statusCode]==200)
        {
            
            NSError* error;
            NSDictionary *json = [NSJSONSerialization
                                  JSONObjectWithData:data
                                  options:kNilOptions
                                  error:&error];
            
            consumer(json,nil);
            
        }
        else
        {
            consumer(nil,error);
        }
    }];
}


/*json get*/
- (void)callGetWebService:(NSString *)urlString andgetData:(StringConsumer) consumer {
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue]  completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSString *responseString=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        //  NSLog(@"%@",responseString);
        if ([(NSHTTPURLResponse *)response statusCode]==200)
        {
            
            NSError* error;
            NSDictionary *json = [NSJSONSerialization
                                  JSONObjectWithData:data
                                  options:kNilOptions
                                  error:&error];
            
            consumer(json,nil);
            
        }
        else
        {
            consumer(nil,error);
        }
    }];
}

#pragma mark - Multipart Data

- (NSMutableURLRequest *) multipartRequestWithURL:(NSURL *)url andImageData:(NSArray *)imageArr andDataDictionary:(NSDictionary *) dictionary andMultiplePictureTag:(BOOL)isMultiplePicture
{
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:60];
    [request setHTTPMethod:@"POST"];
    
    NSDate *dt = [[NSDate alloc] initWithTimeIntervalSinceNow:0];
    int timestamp = [dt timeIntervalSince1970];
    
    NSString *boundary = [NSString stringWithFormat:@"BOUNDARY-%d-%@", timestamp, [[NSProcessInfo processInfo] globallyUniqueString]];
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    for (NSString *param in dictionary) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", param] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@\r\n", [dictionary objectForKey:param]] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    // add image data
    if (imageArr) {
        if (isMultiplePicture) {
            int i = 0;
            for (UIImage *img in imageArr) {
                i++;
                NSString *param = [NSString stringWithFormat:@"picture%d",i];
                
                [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
                [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"image.jpg\"\r\n",param] dataUsingEncoding:NSUTF8StringEncoding]];
                [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
                [body appendData:UIImageJPEGRepresentation(img, 0.1)];
                [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
            }
        }
        else {
            for (UIImage *img in imageArr) {
                NSString *param = @"picture";
                [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
                [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"image.jpg\"\r\n",param] dataUsingEncoding:NSUTF8StringEncoding]];
                [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
                [body appendData:UIImageJPEGRepresentation(img, 0.1)];
                [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
            }
        }
        
    }
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set URL
    [request setURL:url];
    
    return request;
}




- (void ) multipartRequestWithURL:(NSURL *)url  andDataDictionary:(NSDictionary *) dictionary andgetData:(StringConsumer) consumer
{
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:60];
    [request setHTTPMethod:@"POST"];
    
    NSDate *dt = [[NSDate alloc] initWithTimeIntervalSinceNow:0];
    int timestamp = [dt timeIntervalSince1970];
    
    NSString *boundary = [NSString stringWithFormat:@"BOUNDARY-%d-%@", timestamp, [[NSProcessInfo processInfo] globallyUniqueString]];
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    for (NSString *param in dictionary) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", param] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@\r\n", [dictionary objectForKey:param]] dataUsingEncoding:NSUTF8StringEncoding]];
    }
  
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set URL
    [request setURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue]  completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSString *responseString=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        responseString=[responseString stringByReplacingOccurrencesOfString:@"null" withString:@"\" \""];
        responseString=[responseString stringByReplacingOccurrencesOfString:@"<null>" withString:@" \"\""];
        
        //  NSLog(@"%@",responseString);
         if ([(NSHTTPURLResponse *)response statusCode]==200)
        {
            
            NSData *data = [responseString dataUsingEncoding:NSUTF8StringEncoding];
            
            
            NSError* error;
            NSDictionary *json = [NSJSONSerialization
                                  JSONObjectWithData: data
                                  options:kNilOptions
                                  error:&error];
            
            consumer(json,nil);
            
        }
        else
        {
            consumer(nil,error);
        }
    }];

}


- (UIImage *)compressForUpload:(UIImage *)original scale:(CGFloat)scale
{
    // Calculate new size given scale factor.
    CGSize originalSize = original.size;
    CGSize newSize = CGSizeMake(originalSize.width * scale, originalSize.height * scale);
    
    // Scale the original image to match the new size.
    UIGraphicsBeginImageContext(newSize);
    [original drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage* compressedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return compressedImage;
}

@end
