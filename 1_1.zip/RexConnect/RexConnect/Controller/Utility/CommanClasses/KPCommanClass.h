//
//  KPCommanClass.h
//  Kronopress
//
//  Created by cis on 4/17/15.
//  Copyright (c) 2015 cis. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface KPCommanClass : NSObject
/**
 Decorate UIButton with title, font, color.
 */
+ (void)putTitleToButton:(UIButton *)buttonToDecorate
                   Title:(NSString *)buttonTitle
                    font:(NSString *)titleFont
                    size:(CGFloat)titleFontSize
                   color:(UIColor *)titleTextColor;


/**
 Decorate UILabel with custom font
 */
+ (void)putTextToLabel:(UILabel *)label text:(NSString *)labelText
                  font:(NSString *)labelFontName
                  size:(CGFloat)labelFontSize
                 color:(UIColor *)labelTextColor;

/**
 Decorate UITextField with custom font
 */
+ (void)putTextToTextFiled:(UITextField *)textField placeholder:(NSString *)placeholderText
                      font:(NSString *)labelFontName
                      size:(CGFloat)labelFontSize color:(UIColor *)labelTextColor;

/**
 Decorate UITextView with custom font
 */
+ (void)putTextToTextView:(UITextView *)textView text:(NSString *)Text
                     font:(NSString *)labelFontName
                     size:(CGFloat)labelFontSize color:(UIColor *)labelTextColor;

+ (void)putImageToButton:(UIButton *)buttonToDecorate normalStateImage:(NSString *)imageN
       pressedStateImage:(NSString *)imageP;
@end
