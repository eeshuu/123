//
//  WLSharedImagePicker.h
//  Workly
//
//  Created by cis on 12/8/14.
//  Copyright (c) 2014 cis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WLSharedImagePicker : UIImagePickerController
+ (id)shareImagePickerController;
@end
