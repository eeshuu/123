//
//  BankListVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 02/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "BankListVC.h"

@interface BankListVC ()

@property (weak, nonatomic) IBOutlet UIImageView *imgUP;
@property (weak, nonatomic) IBOutlet UIButton *btnMenu;
@end

@implementation BankListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [_btnMenu setImageEdgeInsets:UIEdgeInsetsZero];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnMenuAction:(id)sender {
    if ([sender isSelected]) {
        [_imgUP setImage:[UIImage imageNamed:@"up.png"]];
        [sender setSelected:NO];
    }
    else{
        [_imgUP setImage:[UIImage imageNamed:@"down.png"]];
         [sender setSelected:YES];
    }
}
@end
