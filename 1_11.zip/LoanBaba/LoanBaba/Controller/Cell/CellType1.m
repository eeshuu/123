//
//  CellType1.m
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import "CellType1.h"

@implementation CellType1

- (void)awakeFromNib {
    // Initialization code
     [_lblQuestionType1 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
