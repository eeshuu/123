//
//  ViewController.h
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <GooglePlus/GooglePlus.h>
#import <GoogleOpenSource/GoogleOpenSource.h>
@class GPPSignInButton;
@interface LoginVC : UIViewController<GPPSignInDelegate>

//@property (retain, nonatomic) IBOutlet GPPSignInButton *signInButton;
- (IBAction)gPlusSignIn:(UIButton *)sender;
@end

