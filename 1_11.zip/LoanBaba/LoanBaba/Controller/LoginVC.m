//
//  ViewController.m
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "LoginVC.h"
#import "HomeVC.h"

@interface LoginVC ()
@property (weak, nonatomic) IBOutlet UITextField *txtuserName;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnRegister;
@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;
@property (weak, nonatomic) IBOutlet UILabel *lblLogin;
@property (weak, nonatomic) IBOutlet UIButton *btnForgotPassword;

@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
 
    
   
    
    
    //GPlus SetUp
    
    GPPSignIn *signIn = [GPPSignIn sharedInstance];
    signIn.shouldFetchGooglePlusUser = YES;
    signIn.shouldFetchGoogleUserEmail = YES;  // Uncomment to get the user's email
    
    // You previously set kClientId in the "Initialize the Google+ client" step
    signIn.clientID = kClientId;
    
    // Uncomment one of these two statements for the scope you chose in the previous step
    signIn.scopes = @[ kGTLAuthScopePlusLogin ];  // "https://www.googleapis.com/auth/plus.login" scope
    signIn.scopes = @[ @"profile" ];            // "profile" scope
    
    // Optional: declare signIn.actions, see "app activities"
    signIn.delegate = self;
    
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    [self setupUI];
}

- (void)viewWillAppear:(BOOL)animated {
    
    UIImageView *imgHeaderOld=(UIImageView *)[self.navigationController.navigationBar viewWithTag:100];
    [imgHeaderOld removeFromSuperview];
    
    UIImageView *imgHeader=[[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 180, 40)];
    [imgHeader setImage:[UIImage imageNamed:@"HeaderLogo.png"]];
    [imgHeader setCenter:CGPointMake(self.navigationController.navigationBar.center.x, 22)];
    imgHeader.tag=100;
    [imgHeader setContentMode:UIViewContentModeScaleAspectFit];
    [self.navigationController.navigationBar addSubview:imgHeader];
    
    if ([USER_PREF boolForKey:@"Registered"]) {
        [USER_PREF setBool:NO forKey:@"Registered"];
        [USER_PREF synchronize];
        HomeVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
        [self.navigationController pushViewController:vc animated:NO];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

#pragma mark - UIButton Actions

-(void)setupUI
{
    [_btnSubmit.layer setCornerRadius:_btnSubmit.frame.size.height/2];
    [_btnSubmit.layer setBorderWidth:1.5f];
    [_btnSubmit.layer setBorderColor:[[UIColor colorWithRed:24.0f/255.0f  green:88.0f/255.0f  blue:128.0f/255.0f alpha:.9] CGColor]];
    [_btnSubmit.titleLabel setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    [_btnForgotPassword.titleLabel setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    
    NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    [style setAlignment:NSTextAlignmentCenter];
    [style setLineBreakMode:NSLineBreakByWordWrapping];
    
    UIFont *font1 = [UIFont fontWithName:FONT_REGULAR size:14.0f];
    UIFont *font2 = [UIFont fontWithName:FONT_MEDIIUM  size:18.0f];
    NSDictionary *dict1 = @{NSUnderlineStyleAttributeName:@(NSUnderlineStyleNone),
                            NSFontAttributeName:font1,
                            NSParagraphStyleAttributeName:style,NSForegroundColorAttributeName:[UIColor whiteColor]}; // Added line
    NSDictionary *dict2 = @{NSUnderlineStyleAttributeName:@(NSUnderlineStyleNone),
                            NSFontAttributeName:font2,
                            NSParagraphStyleAttributeName:style,NSForegroundColorAttributeName:[UIColor whiteColor]}; // Added line
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] init];
    [attString appendAttributedString:[[NSAttributedString alloc] initWithString:@"NEW TO THE APP\n"    attributes:dict1]];
    [attString appendAttributedString:[[NSAttributedString alloc] initWithString:@"REGISTER NOW"      attributes:dict2]];
    [self.btnRegister setAttributedTitle:attString forState:UIControlStateNormal];
    [[self.btnRegister titleLabel] setNumberOfLines:0];
    [[self.btnRegister titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    [self.btnRegister setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.txtPassword.layer.borderColor=self.txtuserName.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtPassword.layer.borderWidth=self.txtuserName.layer.borderWidth=1.0f;
    self.txtPassword.layer.cornerRadius=self.txtuserName.layer.cornerRadius=0.0f;
    UIView *leftFirst=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    UIView *leftSecond=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.txtuserName.leftView=leftFirst;
    self.txtPassword.leftView=leftSecond;
    self.txtuserName.leftViewMode=self.txtPassword.leftViewMode=UITextFieldViewModeAlways;
    [_lblLogin setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    
}

-(BOOL)isValidate
{
    _txtuserName.text =[_txtuserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtPassword.text =[_txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (![SharedInstance emailAddressIsValid:_txtuserName.text]) {
        [SharedInstance showAlert:@"Please Enter Valid Email_Id." andTitle:alertTitle];
        return NO;
    }
    else if (!_txtPassword.text.length) {
        [SharedInstance showAlert:@"Please Enter Password." andTitle:alertTitle];
        return NO;
    }
    else{
        return true;
    }
    
}

- (IBAction)btnSubmitAction:(id)sender {
     [self.navigationController pushViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"BankListVC"] animated:YES];
    if ([self isValidate]) {
        if ([SharedInstance isNetworkConnected])
        {
            [self callLoginService:_txtuserName.text andpassWord:_txtPassword.text];
            
        }
        else {
            [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
            
        }
    }
//    HomeVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
//    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)btnForgotPasswordAction:(id)sender {
    
}
- (IBAction)btnFacebookLogin:(id)sender {
    if ([SharedInstance isNetworkConnected])
    {
        FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
        [login
         logInWithReadPermissions: @[@"public_profile", @"email", @"user_friends"]
         handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
             if (error) {
                 NSLog(@"Process error");
             } else if (result.isCancelled) {
                 NSLog(@"Cancelled");
             } else {
                 NSLog(@"Logged in");
                 if ([result.grantedPermissions containsObject:@"email"]) {
                     if ([FBSDKAccessToken currentAccessToken]) {
                         [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                         NSMutableDictionary* parameters = [NSMutableDictionary dictionary];
                         [parameters setValue:@"id,name,email,first_name, last_name,picture.type(large)" forKey:@"fields"];
                         [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:parameters]
                          startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                              [MBProgressHUD hideHUDForView:self.view animated:YES];
                              if (!error) {
                                  NSLog(@"fetched user:%@", result);
                                  [login logOut];
                                  //https://graph.facebook.com/%@/picture?type=large
                                  
                                  [self callLoginServiceFBGoogle:result[@"name"] andEmail:result[@"email"]];
                              }
                              else {
                                  [SharedInstance showAlert:error.description andTitle:alertTitle];
                              }
                          }];
                     }
                 }
             }
         }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
}

- (IBAction)btnGoogletplusLogin:(id)sender {
    if ([SharedInstance isNetworkConnected])
    {
        [[GPPSignIn sharedInstance]authenticate];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

- (IBAction)signOut {
    [[GPPSignIn sharedInstance] signOut];
}

- (IBAction)btnRegister:(id)sender {
    
}

#pragma mark - UITextField delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return YES;
}

#pragma mark - Google Plus Delegate

- (void)finishedWithAuth: (GTMOAuth2Authentication *)auth
                   error: (NSError *) error {
    NSLog(@"Received error %@ and auth object %@",error, auth);
    if (error) {
        // Do some error handling here.
    } else {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [[[GPPSignIn sharedInstance] plusService] executeQuery:[GTLQueryPlus queryForPeopleGetWithUserId:@"me"] completionHandler:^(GTLServiceTicket *ticket, GTLPlusPerson *person, NSError *error)
         {
             
             [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
             NSString *temp = [GPPSignIn sharedInstance].authentication.userEmail;
             NSLog(@"Email = %@",temp);
             NSLog(@"User Name = %@",person.displayName);
             NSLog(@"Image URL = %@",person.image.url);
             [[GPPSignIn sharedInstance] signOut];
             [self callLoginServiceFBGoogle:person.displayName andEmail:temp];
             
         }];
    }
}

#pragma mark - WebAPIs

- (void)callLoginServiceFBGoogle:(NSString *)userName andEmail:(NSString *)email {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostUserFBGoogle>\n"
                             "<tem:strName>%@</tem:strName>\n"
                             "<tem:strEmailId>%@</tem:strEmailId>\n"
                             "</tem:PostUserFBGoogle>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",userName,email];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:LOGIN_FB_GOOGLE_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostUserFBGoogleResponse"] objectForKey:@"PostUserFBGoogleResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            id values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            NSLog(@"arr %@",values);
            if ([values[0][0][@"Status"] isEqualToString:@"true"]) {
                [self.view endEditing:YES];
                [USER_PREF setValue:values[0][0][@"RId"] forKey:@"RId"];
                [USER_PREF synchronize];
                HomeVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
                [self.navigationController pushViewController:vc animated:YES];
            }
            else {
                [SharedInstance showAlert:values[0][0][@"Reason"] andTitle:alertTitle];
            }
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}


- (void)callLoginService:(NSString *)userName andpassWord:(NSString *)password {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:CheckUser>\n"
                             "<tem:strUser>%@</tem:strUser>\n"
                             "<tem:strPass>%@</tem:strPass>\n"
                             "</tem:CheckUser>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",userName,password];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:LOGIN_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"CheckUserResponse"] objectForKey:@"CheckUserResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            id values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            NSLog(@"arr %@",values);
            
            if ([values[0][0][@"Status"] isEqualToString:@"true"]) {
                [self.view endEditing:YES];
                [USER_PREF setValue:values[0][0][@"RId"] forKey:@"RId"];
                [USER_PREF setObject:values[0][0] forKey:@"UserDetails"];
                [USER_PREF synchronize];
                _txtPassword.text = @"";
                _txtuserName.text = @"";
                HomeVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
                [self.navigationController pushViewController:vc animated:YES];
            }
            else {
                [SharedInstance showAlert:@"Invalid Email Id or Password." andTitle:alertTitle];
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
