//
//  CellType1.h
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellType1 : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblQuestionType1;
@property (strong, nonatomic) IBOutlet UILabel *lblRadioButtonTitle;
@property (strong, nonatomic) IBOutlet UIButton *btnRadio;
-(void)setupIU;

@end
