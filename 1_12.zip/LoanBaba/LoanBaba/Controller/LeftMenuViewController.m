 //
//  LeftMenuViewController.m
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "LeftMenuViewController.h"
#import "HomeVC.h"
#import "SKSTableView.h"
#import "SKSTableViewCell.h"
#import "SKSTableViewCellIndicator.h"
#import "EMICalVC.h"
#import "EliCal.h"
#import "FAQVC.h"
#import "LoanVC.h"
#import "QuestionVC.h"
#import "BlogVC.h"
#import "UploadDocVC.h"
#import "TrackVC.h"
#import "MyAccountVC.h"
#import "AboutUs.h"
#import "ContactUS.h"
@implementation LeftMenuViewController
{
  NSArray *contents;
    NSString *strTitle;
}

#pragma mark - UIViewController Methods -

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self.slideOutAnimationEnabled = YES;
    
    return [super initWithCoder:aDecoder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.SKSTableViewDelegate = self;
   
//    contents=@[@[@[@"Home"],
//           @[@"Services", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property", @"Unsecured Business Loan", @"Lease Rental Discounting"],
//           @[@"About us"],@[@"Contact"],@[@"FAQ", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property",@"Lease Rental Discounting"],@[@"Track Application"],@[@"Finance Tools", @"EMI Calculator", @"Eligibility Calculator"],@[@"Blog"]]];
    
    contents = ((AppDelegate*)[UIApplication sharedApplication].delegate).arrContent;

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [contents count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [contents[section] count];
}

- (NSInteger)tableView:(SKSTableView *)tableView numberOfSubRowsAtIndexPath:(NSIndexPath *)indexPath
{
    return [contents[indexPath.section][indexPath.row] count] - 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"SKSTableViewCell";
    
    SKSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
        cell = [[SKSTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    [cell.textLabel setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    cell.textLabel.text = contents[indexPath.section][indexPath.row][0];
    
    
    if ((indexPath.section == 0 && (indexPath.row == 1 || indexPath.row == 4 || indexPath.row == 6)))
        cell.expandable = YES;
    else
        cell.expandable = NO;
    
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForSubRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"UITableViewCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    [cell.textLabel setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
    cell.textLabel.text = [NSString stringWithFormat:@"%@", contents[indexPath.section][indexPath.row][indexPath.subRow]];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     NSLog(@"Section: %ld, Row:%ld, Subrow:%ld", (long)indexPath.section, (long)indexPath.row, (long)indexPath.subRow);
    
    switch (indexPath.row)
    
    {
        case 0:
        {
            HomeVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                    bundle: nil] instantiateViewControllerWithIdentifier: @"HomeVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;
        case 2:
        {
            AboutUs *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                     bundle: nil] instantiateViewControllerWithIdentifier: @"AboutUs"];
            VC.isSlide = YES;
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;
        case 3:
        {
            ContactUS *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                     bundle: nil] instantiateViewControllerWithIdentifier: @"ContactUS"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;
        case 5:
        {
            TrackVC *vc = [[UIStoryboard storyboardWithName:@"Main"
                                                     bundle: nil] instantiateViewControllerWithIdentifier: @"TrackVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;
            
        case 7:
        {
            BlogVC *vc = [[UIStoryboard storyboardWithName:@"Main"
                                                    bundle: nil] instantiateViewControllerWithIdentifier: @"BlogVC"];
            vc.isSlide = YES;
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;
    }
    
}



- (void)tableView:(SKSTableView *)tableView didSelectSubRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Section: %ld, Row%ld, Subrow:%ld", (long)indexPath.section, (long) indexPath.row, (long)indexPath.subRow);
    
    if (indexPath.row == 6) {
        if (indexPath.subRow == 1) {
            EMICalVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                    bundle: nil] instantiateViewControllerWithIdentifier: @"EMICalVC"];
            VC.isSlide = YES;
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
        }
        else if (indexPath.subRow == 2) {
            EliCal *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                    bundle: nil] instantiateViewControllerWithIdentifier: @"EliCal"];
            VC.isSlide = YES;
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
        }
    }
    else if (indexPath.row == 4) {
        NSString *temp ;
        NSArray *tempArr = ((AppDelegate*)[UIApplication sharedApplication].delegate).arrCat ;
        
        for(int i = 0 ;i < tempArr.count;i++) {
            NSDictionary *dictTemp = tempArr[i];
            if ([dictTemp[@"CategoryName"]isEqualToString:contents[indexPath.section][indexPath.row][indexPath.subRow]]) {
                temp = dictTemp[@"CatId"];
                break;
            }
        }

        
        FAQVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                bundle: nil] instantiateViewControllerWithIdentifier: @"FAQVC"];
        VC.tempStr = temp;
        [[NSNotificationCenter defaultCenter] postNotificationName:NotifyUserloanID object:nil userInfo:@{@"loanID": temp}];
        [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                 withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                         andCompletion:nil];
    }
    else if (indexPath.row == 1) {
        NSString *temp ;
        NSArray *tempArr = ((AppDelegate*)[UIApplication sharedApplication].delegate).arrCat ;
        
        for(int i = 0 ;i < tempArr.count;i++) {
            NSDictionary *dictTemp = tempArr[i];
            if ([dictTemp[@"CategoryName"]isEqualToString:contents[indexPath.section][indexPath.row][indexPath.subRow]]) {
                temp = dictTemp[@"CatId"];
                strTitle = dictTemp[@"CategoryName"];
                break;
            }
        }
        [self callGetCategoryListService:temp];
        
        
    }
}

- (IBAction)btnUploadAction:(id)sender {
    UploadDocVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                          bundle: nil] instantiateViewControllerWithIdentifier: @"UploadDocVC"];
    VC.strApplicationId = @"";
    VC.isSlide = YES;
   
    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                     andCompletion:nil];
    
}
- (IBAction)btnAccountAction:(id)sender {
    
    MyAccountVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                 bundle: nil] instantiateViewControllerWithIdentifier: @"MyAccountVC"];
    
    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                     andCompletion:nil];
}
- (IBAction)btnSignoutAction:(id)sender {
    [USER_PREF setBool:NO forKey:@"LoggedIn"];
    [USER_PREF synchronize];
    [[SlideNavigationController sharedInstance] popToRootViewControllerAnimated:NO];
}

- (void)callGetCategoryListService:(NSString *)catId {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetCategoryList>\n"
                             "<tem:strParentId>%@</tem:strParentId>\n"
                             "</tem:GetCategoryList>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",catId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetCategoryList_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetCategoryListResponse"] objectForKey:@"GetCategoryListResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            NSLog(@"Data Category %@",arr);
            if (arr.count>0) {
                LoanVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                        bundle: nil] instantiateViewControllerWithIdentifier: @"LoanVC"];
                VC.isSlide = YES;
                VC.arrayMenu = [NSMutableArray arrayWithArray:arr];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"Nilesh" object:nil userInfo:@{@"Arr": arr}];
                [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                         withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                                 andCompletion:nil];
            }
            else {
                [self callGetQuestionByCatIdService:catId];
            }
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

- (void)callGetQuestionByCatIdService:(NSString *)catId {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetQuestionByCatId>\n"
                             "<tem:strCatId>%@</tem:strCatId>\n"
                             "</tem:GetQuestionByCatId>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",catId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetQuestionByCatId_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetQuestionByCatIdResponse"] objectForKey:@"GetQuestionByCatIdResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
            appDelegate.arrayQuestion=[[NSMutableArray alloc]initWithArray:arr];
            appDelegate.intQesCount=0;
            
            
            
            QuestionVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                    bundle: nil] instantiateViewControllerWithIdentifier: @"QuestionVC"];
            VC.isSlide = YES;
            VC.titleStr = strTitle;
            [[NSNotificationCenter defaultCenter] postNotificationName:@"NileshPal" object:nil userInfo:@{@"Arr": arr,@"count":@"0",@"Title":strTitle}];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
            NSLog(@"Data Category Question %@",arr);
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

- (IBAction)action_Social:(UIButton *)sender {
    switch (sender.tag) {
        case 201:
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.facebook.com/theloanbaba"]];
            break;
        case 202:
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.linkedin.com/company/loanbaba-com"]];
            break;
        case 203:
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://twitter.com/@LoanBaba"]];
            break;
            
        default:
            break;
    }
}
@end
