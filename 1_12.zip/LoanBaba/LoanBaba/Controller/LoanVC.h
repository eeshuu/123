//
//  LoanVC.h
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 19/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoanVC : UIViewController
{
    
    
    
}
@property (strong, nonatomic) NSString *loanType;
@property (strong, nonatomic) NSMutableArray *arrayMenu;
@property (nonatomic) BOOL isSlide;

@end
