//
//  Constant.h
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#ifndef LoanBaba_Constant_h
#define LoanBaba_Constant_h

//Custom font
#define FONT_BOLD @"Dosis-Bold"
#define FONT_EXTRABOLD @"Dosis-ExtraBold"
#define FONT_EXTRALIGHT @"Dosis-ExtraLight"
#define FONT_LIGHT @"Dosis-Light"
#define FONT_MEDIIUM @"Dosis-Medium"
#define FONT_REGULAR @"Dosis-Regular"
#define FONT_SEMIBOLD @"Dosis-SemiBold"
#define QUESTION_PLACEHOLDER @"PlaceHolderText"
// Alert Messages
#define networkNotConnected @"Internet connection not found, Please make sure that you are connected with internet"
#define serverNotResponding @"Something went wrong, Please try after some time"
#define alertTitle @"LoanBaba"

#define kClientId  @"14224776140-9dm66klousseojjvviacjjbdrr2g0e0c.apps.googleusercontent.com"

#define SharedInstance [ApplicationManager sharedManagerInstance]

#define USER_PREF [NSUserDefaults standardUserDefaults]

#define BASE_URL_IMAGE @"https://loanbaba.com/images/uploads/category/"
#define BASE_URL_IMAGE_BLOG @"https://loanbaba.com/images/blog/"
#define BASE_URL_IMAGE_BANK @"https://loanbaba.com/images/logo/"

#define NotifyUserloanID @"com.loanBaba.UserloanID"
#define NotifyUserLoan @"com.loanBaba.Userloan"




// Question TypeID

#define RADIO_BUTTON @"1"
#define DATE_TIME_PICKER @"2"
#define DROP_DOWN @"3"
#define MONEY_NUMBER @"4"
#define NORMAL_TEXT @"5"
#define NONE @"0"


// Webservice URLs

#define BASE_URL_CALLING @"http://momentumads.net/loanbabaweb/appservice.asmx"


#define BASE_URL @"http://tempuri.org/"

#define LOGIN_FB_GOOGLE_URL BASE_URL@"PostUserFBGoogle"

#define LOGIN_URL BASE_URL@"CheckUser"

#define REGISTER_URL BASE_URL@"PostUserRegister"

#define FORGOT_PWD_URL BASE_URL@"ForgotPassword"

#define GetCategoryList_URL BASE_URL@"GetCategoryList"

#define GetQuestionByCatId_URL BASE_URL@"GetQuestionByCatId"

#define GetFAQ_URL BASE_URL@"GetFAQ"

#define GetAnswerListByTypeId_URL BASE_URL @"GetAnswerListByTypeId"

#define PostQuestionAnswer_URL BASE_URL@"PostQuestionAnswer"

#define GetListOfBankWithDetails_URL BASE_URL@"GetListOfBankWithDetails"

#define GetSliderValues_URL BASE_URL@"GetSliderValues"

#define GetListOfBankWithDetailsAmt_URL BASE_URL@"GetListOfBankWithDetailsAmt"

#define PostUpdateBankAmountTenuer_URL BASE_URL@"PostUpdateBankAmountTenuer"

#define PostApplicationForm_URL BASE_URL@"PostApplicationForm"

#define UploadJpgFiles_URL BASE_URL@"UploadJpgFiles"

#define TrakLoanApp_URL BASE_URL@"TrakLoanApp"

#define GetBLOG_LIST_URL BASE_URL@"GetBlogList"

#define GetBlogDetails_URL BASE_URL@"GetBlogDetails"

#define GetBlogComments_URL BASE_URL@"GetBlogComments"

#define GetBlogListBySearch_URL BASE_URL@"GetBlogListBySearch"

#define PostBlogComment_URL BASE_URL@"PostBlogComment"

#define GetMyProfile_URL BASE_URL@"GetMyProfile"

#define PostUpdateMyProfile_URL BASE_URL@"PostUpdateMyProfile"

#define PostContactUs_URL BASE_URL@"PostContactUs"

#define PostUpdateChangePass_URL BASE_URL@"PostUpdateChangePass"

#define GetLoanHistory_URL BASE_URL@"GetLoanHistory"

#endif
