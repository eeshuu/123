//
//  CellComment.h
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 08/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellComment : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblComment;
@property (weak, nonatomic) IBOutlet UILabel *lblName;
-(void)setData:(NSMutableDictionary *)dict;
@end
