//
//  CellType4.m
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import "CellType4.h"

@implementation CellType4

- (void)awakeFromNib {
    // Initialization code
   
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setupIU
{
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.TxtQuestionType4.frame.size.height)];
    [rightView setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"rupee.png"]];
    [rightView addSubview:imageloanAmmount];
    [self.TxtQuestionType4 setRightViewMode:UITextFieldViewModeAlways];
    self.TxtQuestionType4.rightView=rightView ;
    
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.TxtQuestionType4.leftView=leftView;
    self.TxtQuestionType4.leftViewMode=UITextFieldViewModeAlways;
    self.TxtQuestionType4.layer.borderColor=[[UIColor grayColor] CGColor];
    self.TxtQuestionType4.layer.borderWidth=1.0f;
    
    
    [_lblQuestionType4 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    [_TxtQuestionType4 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
}

@end
