//
//  AboutUs.h
//  LoanBaba
//
//  Created by Nilesh Pal on 07/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUs : UIViewController

@property (nonatomic)BOOL isSlide;
@end
