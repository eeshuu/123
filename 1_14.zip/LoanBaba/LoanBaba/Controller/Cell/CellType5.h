//
//  CellType5.h
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellType5 : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblQuestionType5;
@property (strong, nonatomic) IBOutlet UITextField *TxtQuestionType5;
@end
