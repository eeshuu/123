//
//  CellBankList.m
//  iFishPocket
//
//  Created by cis on 10/3/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import "CellBankList.h"
#import "UIImageView+WebCache.h"
@implementation CellBankList

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setData:(NSMutableDictionary *)dict
{
    [_imgBankIcon sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL_IMAGE_BANK,dict [@"PhotoSmall"]]] placeholderImage:nil];//https://loanbaba.com/images/logo/
    [_lblLoanAmount setText:[NSString stringWithFormat:@"%.0f",[dict[@"PA"] floatValue]]];
    [_lblInterestRate setText:dict[@"RateOfInterest"]];
    [_lblProcessingFees setText:dict[@"ProcessingFee"]];
    [_lblEMI setText:[NSString stringWithFormat:@"%.0f",[dict[@"EMI"] floatValue]]];

}
@end
