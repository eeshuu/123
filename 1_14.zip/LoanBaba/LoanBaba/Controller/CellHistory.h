//
//  CellHistory.h
//  fish
//
//  Created by Nilesh on 10/7/15.
//  Copyright © 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellHistory : UITableViewCell


@property (nonatomic, weak)IBOutlet UILabel *lblAppNo;
@property (nonatomic, weak)IBOutlet UILabel *lblStatus;
@property (nonatomic, weak)IBOutlet UILabel *lblDate;
@property (nonatomic, weak)IBOutlet UILabel *lblBankName;
@property (nonatomic, weak)IBOutlet UILabel *lblLoanAmount;
@property (nonatomic, weak)IBOutlet UILabel *lblTenure;

-(void)setData:(NSMutableDictionary *)dict;

@end
