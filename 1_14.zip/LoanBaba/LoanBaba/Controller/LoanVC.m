//
//  LoanVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 19/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "LoanVC.h"
#import "CellLoanVC.h"
#import "UIImageView+WebCache.h"
#import "QuestionVC.h"
@interface LoanVC ()

@property (weak, nonatomic) IBOutlet UITableView *tblMenu;

@end

@implementation LoanVC
@synthesize arrayMenu;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_tblMenu setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    
    // Do any additional setup after loading the view.
    //    arrayMenu=[[NSMutableArray alloc]init];
    //    [arrayMenu addObject:@{@"Title":@"Car Loan",@"Icon":@"car.png"}];
    //    [arrayMenu addObject:@{@"Title":@"Unsecured Personal Loan",@"Icon":@"ico_unsecured_personal_loan.png"}];
    //    [arrayMenu addObject:@{@"Title":@"Unsecured Business Loan",@"Icon":@"ico_unsecured_business_loan.png"}];
    //    [arrayMenu addObject:@{@"Title":@"Home Loan",@"Icon":@"ico_home_loan.png"}];
    //    [arrayMenu addObject:@{@"Title":@"Loan Against Property",@"Icon":@"ico_loan_against_property.png"}];
    //    [arrayMenu addObject:@{@"Title":@"Lease Rental Discounting ",@"Icon":@"ico_lease_rental_discounting.png"}];
    //    [_tblMenu setTableFooterView:[[UIView alloc]initWithFrame:CGRectZero]];
    //    [_tblMenu reloadData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(loanIdChanged:)
                                                 name:@"Nilesh"
                                               object:nil];
    
    [self addHomeButton];

}

- (void)addHomeButton {
    UIButton *btnlog = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnlog setFrame:CGRectMake(0, 0, 30, 30)];
    [btnlog setImage:[UIImage imageNamed:@"home"] forState:UIControlStateNormal];
    [btnlog addTarget:self action:@selector(action_Home) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *right = [[UIBarButtonItem alloc]initWithCustomView:btnlog];
    self.navigationItem.rightBarButtonItem = right;
}

- (void)action_Home {
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex: 1] animated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //    UIImageView *imgHeaderOld=(UIImageView *)[self.navigationController.navigationBar viewWithTag:100];
    //    [imgHeaderOld removeFromSuperview];
    //    UIImageView *imgHeader=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 124, 20)];
    //    [imgHeader setImage:[UIImage imageNamed:@"header.png"]];
    //    [imgHeader setCenter:CGPointMake(self.navigationController.navigationBar.center.x, 22)];
    //    imgHeader.tag=100;
    //    [self.navigationController.navigationBar addSubview:imgHeader];
    [self setTitle:self.loanType];
    // Do any additional setup after loading the view.
    
    
    UIImageView *imgHeader=(UIImageView *)[self.navigationController.navigationBar viewWithTag:100];
    [imgHeader removeFromSuperview];
    
}

#pragma mark - UpdateList

- (void)loanIdChanged:(NSNotification*)notification {
    
    NSDictionary *temp = (NSDictionary *)notification.userInfo;
    arrayMenu = temp[@"Arr"];
    [_tblMenu reloadData];
    
//    [self callGetCategoryListService:temp[@"loanID"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    if (!self.isSlide) {
        return NO;
    }
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.arrayMenu count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellLoanVC *cell = [tableView dequeueReusableCellWithIdentifier:@"CellLoanVC"];
    
    //    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayMenu objectAtIndex:indexPath.row]];
    //    /*set*/
    //    [cell setData:dictData];

    [cell.lblTitle setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    
    cell.lblTitle.text = self.arrayMenu[indexPath.row][@"CategoryName"];
//    [cell.imgIcon  sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL_IMAGE,self.arrayMenu[indexPath.row][@"ImageFile"]]] placeholderImage:[UIImage imageNamed:@"image_not_found"]];
    
    [cell.imgIcon sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL_IMAGE,self.arrayMenu[indexPath.row][@"ImageFile"]]] placeholderImage:[UIImage imageNamed:@"image_not_found"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        CGImageRef tmpImgRef = image.CGImage;
        CGImageRef topImgRef = CGImageCreateWithImageInRect(tmpImgRef, CGRectMake(0, 0, image.size.width, image.size.height / 2.0));
        UIImage *topImage = [UIImage imageWithCGImage:topImgRef];
        [cell.imgIcon setImage:topImage];
    }];
    
    
  
  
//    [cell.imageView setImageURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL_IMAGE,self.arrayMenu[indexPath.row][@"ImageFile"]]]];
    
    [cell layoutIfNeeded];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ([SharedInstance isNetworkConnected])
    {
        self.loanType = self.arrayMenu[indexPath.row][@"CategoryName"];
        [self callGetCategoryListService:self.arrayMenu[indexPath.row][@"CatId"]];
        
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellLoanVC *cell = [tableView dequeueReusableCellWithIdentifier:@"CellLoanVC"];
    CGSize possibleSize = [self.arrayMenu[indexPath.row][@"CategoryName"] sizeWithFont:[cell.lblTitle font] //font you are using
                                                                     constrainedToSize:CGSizeMake(cell.lblTitle.frame.size.width,9999)
                                                                         lineBreakMode:NSLineBreakByWordWrapping];
    
    
    if (possibleSize.height+23 >44) {
        return possibleSize.height+23;
    }
    else{
        return 44;
    }
    
    
}


#pragma mark - WebAPIs

- (void)callGetCategoryListService:(NSString *)catId {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetCategoryList>\n"
                             "<tem:strParentId>%@</tem:strParentId>\n"
                             "</tem:GetCategoryList>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",catId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetCategoryList_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetCategoryListResponse"] objectForKey:@"GetCategoryListResult"];

            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            NSLog(@"Data Category %@",arr);

            if (arr.count>0) {
                LoanVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"LoanVC"];
                vc.arrayMenu = [NSMutableArray arrayWithArray:arr];
                vc.loanType = self.loanType;
                [self.navigationController pushViewController:vc animated:YES];
            }
            else {
                [self callGetQuestionByCatIdService:catId];
//                [SharedInstance showAlert:@"No Submenu" andTitle:alertTitle];
            }

        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

- (void)callGetQuestionByCatIdService:(NSString *)catId {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetQuestionByCatId>\n"
                             "<tem:strCatId>%@</tem:strCatId>\n"
                             "</tem:GetQuestionByCatId>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",catId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetQuestionByCatId_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetQuestionByCatIdResponse"] objectForKey:@"GetQuestionByCatIdResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
            appDelegate.arrayQuestion=[[NSMutableArray alloc]initWithArray:arr];
            appDelegate.intQesCount=0;
            appDelegate.strCatId = catId;
            QuestionVC *VC=[self.storyboard instantiateViewControllerWithIdentifier:@"QuestionVC"];
            VC.titleStr = self.loanType;
            [self.navigationController pushViewController:VC animated:YES];
           NSLog(@"Data Category Question %@",arr);
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}



@end
