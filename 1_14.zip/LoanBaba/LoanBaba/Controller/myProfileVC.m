//
//  myProfileVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 06/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "myProfileVC.h"
#import "SAMenuDropDown.h"
@interface myProfileVC ()<SAMenuDropDownDelegate>
{
    UIDatePicker *datePicker;
    NSArray *arrayGender;
    SAMenuDropDown *dropDowngender;
}
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtFname;
@property (weak, nonatomic) IBOutlet UITextField *txtSpouse;
@property (weak, nonatomic) IBOutlet UITextField *txtGender;
@property (weak, nonatomic) IBOutlet UITextField *txtDob;
@property (weak, nonatomic) IBOutlet UITextField *txtMobileNumber;
@property (weak, nonatomic) IBOutlet UITextField *txtPanNumber;

@property (weak, nonatomic) IBOutlet UITextField *txtHouseNo;
@property (weak, nonatomic) IBOutlet UITextField *txtStreet;
@property (weak, nonatomic) IBOutlet UITextField *txtLandmark;
@property (weak, nonatomic) IBOutlet UITextField *txtCity;
@property (weak, nonatomic) IBOutlet UITextField *txtArea;
@property (weak, nonatomic) IBOutlet UITextField *txtState;
@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;
@property (weak, nonatomic) IBOutlet UIButton *btnGender;

@end

@implementation myProfileVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    if ([SharedInstance isNetworkConnected])
    {
        [self callGetMyProfileService];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    for(id aSubView in [self.view subviews])
    {
        if([aSubView isKindOfClass:[UIScrollView class]] )
        {
            for (id bSubView in [aSubView subviews]) {
                    for (id cSubView in [bSubView subviews]) {
                        if([cSubView isKindOfClass:[UITextField class]] ){
                            UITextField *textField=(UITextField*)cSubView;
                            [textField.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
                            [textField.layer setBorderWidth:1.0f];
                            [textField setBorderStyle:UITextBorderStyleNone];
                            UIView *leftFirst=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
                            textField.leftView=leftFirst;
                            [textField setLeftViewMode:UITextFieldViewModeAlways];
                        }
                    }
            }
        }
    }
    
    [self setupUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark-SAMenuDropDown Deligate
- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex
{
    if (dropDowngender==menuSender) {
        [self.txtGender setText:[[arrayGender objectAtIndex:buttonIndex] objectForKey:@"Title"]];
        [dropDowngender hideSADropDownMenu];
    }
    
    
    
}
#pragma mark-Action

- (IBAction)action_submit:(id)sender {
    
    if ([SharedInstance isNetworkConnected])
    {
        if (_txtName.text.length>0 &&
            _txtFname.text.length>0 &&
            
            _txtGender.text.length>0 &&
            _txtDob.text.length>0 &&
            _txtMobileNumber.text.length>0 &&
            _txtPanNumber.text.length>0 &&
            _txtHouseNo.text.length>0 &&
            _txtStreet.text.length>0 &&
            _txtLandmark.text.length>0 &&
            _txtCity.text.length>0 &&
            _txtArea.text.length>0 &&
            _txtState.text.length>0) {
            
            [self callPostUpdateMyProfile];
            
        }
        else {
            [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
        }
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    
    
    
}

-(void)setupUI
{
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(8, 0, 35, self.txtDob.frame.size.height)];
    [rightView setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"cal.png"]];
    [rightView addSubview:imageloanAmmount];
    [self.txtDob setRightViewMode:UITextFieldViewModeAlways];
    self.txtDob.rightView=rightView ;
    
    datePicker = [[UIDatePicker alloc]init];
    [datePicker setDate:[NSDate date]];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker addTarget:self action:@selector(dateTextField:) forControlEvents:UIControlEventValueChanged];
    [self.txtDob setInputView:datePicker];
    UIToolbar *timePickerToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    
    NSMutableArray *buttonsArray = [[NSMutableArray alloc] init];
    
    UIBarButtonItem *flex = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    [buttonsArray addObject:flex];
    
    UIBarButtonItem *Cancel = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(cancelDatePicker:)];
    [buttonsArray addObject:Cancel];
    [timePickerToolBar setItems:buttonsArray];
    
    self.txtDob.inputAccessoryView = timePickerToolBar;
    
    
    UIView *rightViewGender=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.txtGender.frame.size.height)];
    [rightViewGender setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmountGender=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmountGender setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmountGender setImage:[UIImage imageNamed:@"Expand_Arrow.png"]];
    [rightViewGender addSubview:imageloanAmmountGender];
    [self.txtGender setRightViewMode:UITextFieldViewModeAlways];
    self.txtGender.rightView=rightViewGender ;
    [self.txtGender setText:@"Male"];
    
   
    
    arrayGender=@[@{@"Title":@"Male"},@{@"Title":@"Female"}];
    dropDowngender=[[SAMenuDropDown alloc] initWithWithSource:self.btnGender menuHeight:80 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropDowngender setDelegate:self];
    [dropDowngender setUpItemDataSourceWithNames:arrayGender subtitles:nil imageNames:nil];
    
    
    _btnSubmit.layer.borderWidth=_btnSubmit.layer.borderWidth=1.0;
    _btnSubmit.layer.cornerRadius=_btnSubmit.frame.size.height/2;
    _btnSubmit.layer.borderColor=[[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1] CGColor];
}


- (IBAction)btnGenderAction:(id)sender {
    [dropDowngender showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
}
-(void) cancelDatePicker:(id)sender
{
    //    [self.seg1TxtDOB setText:@""];
    [self.txtDob resignFirstResponder];
    
}

-(void) doneDatePicker:(id)sender
{
    [self.txtDob resignFirstResponder];
    
}

-(void) dateTextField:(id)sender
{
    UIDatePicker *picker = (UIDatePicker*)self.txtDob.inputView;
    [picker setMaximumDate:[NSDate date]];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDate *eventDate = picker.date;
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    
    NSString *dateString = [dateFormat stringFromDate:eventDate];
    self.txtDob.text = [NSString stringWithFormat:@"%@",dateString];
    
}

- (void)callGetMyProfileService {

    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetMyProfile>\n"
                             "<tem:strUserId>%@</tem:strUserId>\n"
                             "</tem:GetMyProfile>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",[USER_PREF valueForKey:@"RId"]];
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetMyProfile_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetMyProfileResponse"] objectForKey:@"GetMyProfileResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data Profile %@",arr);
            
            if (arr.count > 0) {
                _txtName.text = arr[0][@"strName"];
                _txtFname.text = arr[0][@"strFatherName"];
                _txtSpouse.text = arr[0][@"strSpouseName"];
                _txtGender.text = arr[0][@"strGender"];
                _txtDob.text = arr[0][@"strDOB"];
                _txtMobileNumber.text = arr[0][@"strMobile"];
                _txtPanNumber.text = arr[0][@"strPanNo"];
                _txtHouseNo.text = arr[0][@"strAptName"];
                _txtStreet.text = arr[0][@"strRoad"];
                _txtLandmark.text = arr[0][@"strLandMark"];
                _txtCity.text = arr[0][@"strCity"];
                _txtArea.text = arr[0][@"strArea"];
                _txtState.text = arr[0][@"strState"];
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

- (void)callPostUpdateMyProfile {
    NSString *strTemp;
    if (_txtSpouse.text.length == 0) {
        strTemp = @"";
    }
    else {
        strTemp = _txtSpouse.text;
    }
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostUpdateMyProfile>\n"
                             "<tem:strUserId>%@</tem:strUserId>\n"
                             "<tem:strName>%@</tem:strName>\n"
                             "<tem:strAptName>%@</tem:strAptName>\n"
                             "<tem:strRoad>%@</tem:strRoad>\n"
                             "<tem:strLandMark>%@</tem:strLandMark>\n"
                             "<tem:strState>%@</tem:strState>\n"
                             "<tem:strCity>%@</tem:strCity>\n"
                             "<tem:strFatherName>%@</tem:strFatherName>\n"
                             "<tem:strSpouseName>%@</tem:strSpouseName>\n"
                             "<tem:strGender>%@</tem:strGender>\n"
                             "<tem:strDOB>%@</tem:strDOB>\n"
                             "<tem:strPanNo>%@</tem:strPanNo>\n"
                             "<tem:strArea>%@</tem:strArea>\n"
                             "<tem:strMobile>%@</tem:strMobile>\n"
                             "</tem:PostUpdateMyProfile>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",[USER_PREF valueForKey:@"RId"],_txtName.text,_txtHouseNo.text,_txtStreet.text,_txtLandmark.text,_txtState.text,_txtCity.text,_txtFname.text,strTemp,_txtGender.text,_txtDob.text,_txtPanNumber.text,_txtArea.text,_txtMobileNumber.text];
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostUpdateMyProfile_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostUpdateMyProfileResponse"] objectForKey:@"PostUpdateMyProfileResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data Profile update %@",arr);
            
            if (arr.count > 0) {
                if ([arr[0][@"Status"] isEqualToString:@"true"]) {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                    [self.navigationController popViewControllerAnimated:YES];
                }
                else {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                }
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
