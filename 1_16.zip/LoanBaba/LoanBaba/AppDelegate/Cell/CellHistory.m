//
//  CellHistory.m
//  fish
//
//  Created by Nilesh on 10/7/15.
//  Copyright © 2015 Nilesh. All rights reserved.
//

#import "CellHistory.h"

@implementation CellHistory

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)setData:(NSMutableDictionary *)dict
{
    [_lblAppNo setText:dict[@"AppNo"]];
    [_lblBankName setText:dict[@"BankName"]];
    [_lblDate setText:dict[@"AppDate"]];
    [_lblLoanAmount setText:dict[@"LoanAmount"]];
    [_lblStatus setText:dict[@""]];
    [_lblTenure setText:dict[@"Tenure"]];
    
}

@end
