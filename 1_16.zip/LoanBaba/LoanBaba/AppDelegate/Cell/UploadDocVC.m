//
//  UploadDocVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 04/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "UploadDocVC.h"

@interface UploadDocVC ()
{
    NSString *strType;
    UIImage *selectedImage;
}
@end

@implementation UploadDocVC
@synthesize strApplicationId,isSlide;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _imgIncome.hidden = YES;
    _imgPan.hidden = YES;
    _imgSalary.hidden = YES;
    
    if (self.strApplicationId.length>0) {
        (        (UIButton *)[self.view viewWithTag:103]).hidden = NO;
    }
    else {
        (        (UIButton *)[self.view viewWithTag:103]).hidden = YES;
    }
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    if (!self.isSlide) {
        return NO;
    }
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)action_Upload:(UIButton *)sender {
    switch (sender.tag) {
        case 100: {
            strType = @"PanCard";
            [self showGalleryToTakePic];
            break;}
        case 101:{
            strType = @"LastThreeYearIncome";
            [self showGalleryToTakePic];
            break;}
        case 102:{
            strType = @"AnnualSalary";
            [self showGalleryToTakePic];
            break;}
        case 103:{
            NSString *strMsg = [NSString stringWithFormat:@"Your Application has been submitted.\nYour Application number is %@. You can track your application anytime from your account.",self.strApplicationId];
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Thank You" message:strMsg delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            [alert show];
            break;
        }
            
        default:
            break;
    }
    
    
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
   [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex: 1] animated:YES];
}

- (void)showGalleryToTakePic{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImagePickerController *objController = [[UIImagePickerController alloc]init];
        objController.delegate = self;
        objController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:objController animated:YES completion:nil];
    });
}

#pragma mark - UIImagePickerController Delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
   
    [self dismissViewControllerAnimated:YES completion:nil];
    
    if ([SharedInstance isNetworkConnected])
    {
        [self callUploadJpgFilesService];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
   
    
}

- (void)callUploadJpgFilesService {
    NSData *imgData = UIImageJPEGRepresentation(selectedImage, 0.8);
    NSString *base64String = [imgData base64EncodedStringWithOptions: NSDataBase64Encoding64CharacterLineLength];
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:UploadJpgFiles>\n"
                             "<tem:strUserId>%@</tem:strUserId>\n"
                             "<tem:strDocType>%@</tem:strDocType>\n"
                             "<tem:strBase64String>%@</tem:strBase64String>\n"
                             "</tem:UploadJpgFiles>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",[USER_PREF valueForKey:@"RId"],strType,base64String];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:UploadJpgFiles_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"UploadJpgFilesResponse"] objectForKey:@"UploadJpgFilesResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            if (arr.count > 0) {
                if ([arr[0][@"Status"] isEqualToString:@"true"]) {
                    if ([strType isEqualToString:@"PanCard"]) {
                        _imgPan.hidden = NO;
                    }
                    else if ([strType isEqualToString:@"LastThreeYearIncome"]) {
                        _imgIncome.hidden = NO;
                        
                    }
                    else if ([strType isEqualToString:@"AnnualSalary"]) {
                        _imgSalary.hidden = NO;
                    }
                    
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                }
                else {
                     [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                }
            }

            NSLog(@"Data upload image %@",arr);

            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
