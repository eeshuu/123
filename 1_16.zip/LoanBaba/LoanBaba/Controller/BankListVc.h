//
//  LoanInfoVC.h
//  iFishPocket
//
//  Created by cis on 10/3/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BankListVc : UIViewController

@property (strong, nonatomic)NSString *strRequestId;
@end
