//
//  BlogDetailVC.h
//  workly
//
//  Created by Nilesh Pal on 01/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlogDetailVC : UIViewController


@property (strong, nonatomic) NSString *strBlogId;
@property (nonatomic, weak)IBOutlet UITextField *txtName;
@property (nonatomic, weak)IBOutlet UITextField *txtEmail;
@property (nonatomic, weak)IBOutlet UITextField *txtComments;

- (IBAction)action_SUbmitComment:(id)sender;

@end
