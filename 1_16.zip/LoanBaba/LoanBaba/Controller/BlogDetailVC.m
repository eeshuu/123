//
//  BlogDetailVC.m
//  workly
//
//  Created by Nilesh Pal on 01/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "BlogDetailVC.h"

@interface BlogDetailVC ()

@end

@implementation BlogDetailVC
@synthesize strBlogId;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    if ([SharedInstance isNetworkConnected])
    {
        [self callGetBlogDetails];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)action_SUbmitComment:(id)sender {
    if ([SharedInstance isNetworkConnected])
    {
        if (_txtName.text.length > 0 && _txtComments.text.length > 0) {
            if ([SharedInstance emailAddressIsValid:_txtEmail.text]) {
                [self callPostBlogComment];
            }
            else {
                 [SharedInstance showAlert:@"Please enter valid EmailId." andTitle:alertTitle] ;
            }
        }
        else {
            [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
        }
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}


- (void)callGetBlogDetails {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetBlogDetails>\n"
                             "<tem:strBlogId>%@</tem:strBlogId>\n"
                             "</tem:GetBlogDetails>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",self.strBlogId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetBlogDetails_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetBlogDetailsResponse"] objectForKey:@"GetBlogDetailsResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            NSLog(@" Blog DEtails %@",arr);
            [self callGetBlogComments];
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

- (void)callGetBlogComments {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetBlogComments>\n"
                             "<tem:strBlogId>%@</tem:strBlogId>\n"
                             "</tem:GetBlogComments>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",self.strBlogId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetBlogComments_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetBlogCommentsResponse"] objectForKey:@"GetBlogCommentsResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            NSLog(@" Blog comment %@",arr);
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}


- (void)callPostBlogComment {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostBlogComment>\n"
                             "<tem:strName>%@</tem:strName>\n"
                             "<tem:strEmail>%@</tem:strEmail>\n"
                             "<tem:strComment>%@</tem:strComment>\n"
                             "<tem:strBlogId>%@</tem:strBlogId>\n"
                             "</tem:PostBlogComment>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",_txtName.text,_txtEmail.text,_txtComments.text,self.strBlogId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostBlogComment_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostBlogCommentResponse"] objectForKey:@"PostBlogCommentResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            NSLog(@" Blog Post %@",arr);

            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
