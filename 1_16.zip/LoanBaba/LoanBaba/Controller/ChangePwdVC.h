//
//  ChangePwdVC.h
//  LoanBaba
//
//  Created by Nilesh Pal on 07/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePwdVC : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txtoldPwd;
@property (weak, nonatomic) IBOutlet UITextField *txtNewPwd;
@property (weak, nonatomic) IBOutlet UITextField *txtConfirmPwd;
- (IBAction)action_Submit:(id)sender;
@end
