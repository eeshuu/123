//
//  ContactUS.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 07/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ContactUS.h"

@interface ContactUS ()
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtMobileNo;
@property (weak, nonatomic) IBOutlet UITextView *txtViewMessage;
@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;

@end

@implementation ContactUS

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    for(id aSubView in [self.view subviews])
    {
        if([aSubView isKindOfClass:[UIScrollView class]] )
        {
            for (id bSubView in [aSubView subviews]) {
                for (id cSubView in [bSubView subviews]) {
                    if([cSubView isKindOfClass:[UITextField class]] ){
                        UITextField *textField=(UITextField*)cSubView;
                        [textField.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
                        [textField.layer setBorderWidth:1.0f];
                        [textField setBorderStyle:UITextBorderStyleNone];
                        UIView *leftFirst=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
                        textField.leftView=leftFirst;
                        [textField setLeftViewMode:UITextFieldViewModeAlways];
                    }
                }
            }
        }
    }
    
    
    [_txtViewMessage.layer setBorderWidth:1.0f];
    [_txtViewMessage.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}


#pragma mark-Action
- (IBAction)btnSubmitAction:(id)sender {
    if ([SharedInstance isNetworkConnected])
    {
        if (_txtName.text.length>0 &&
            _txtMobileNo.text.length>0 &&
            _txtViewMessage.text.length>0) {
            if ([SharedInstance emailAddressIsValid:_txtEmail.text]) {
                [self callPostContactUs];
            }
            else {
                [SharedInstance showAlert:@"Please enter valid EmailId." andTitle:alertTitle] ;
            }
            
        }
        else {
            [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
        }
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}


- (void)callPostContactUs {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostContactUs>\n"
                             "<tem:strName>%@</tem:strName>\n"
                             "<tem:strEmail>%@</tem:strEmail>\n"
                             "<tem:strMobile>%@</tem:strMobile>\n"
                             "<tem:strMsg>%@</tem:strMsg>\n"
                             "</tem:PostContactUs>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",_txtName.text,_txtEmail.text,_txtMobileNo.text,_txtViewMessage.text];
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostContactUs_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostContactUsResponse"] objectForKey:@"PostContactUsResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data %@",arr);
            
            if (arr.count > 0) {
                if ([arr[0][@"Status"] isEqualToString:@"true"]) {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                    
                }
                else {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                }
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
