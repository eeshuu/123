//
//  FAQVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 21/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "FAQVC.h"
#import "SKSTableView.h"
#import "SKSTableViewCell.h"
#import "SKSTableViewCellIndicator.h"
@interface FAQVC ()
{
    NSArray *contents;
}
@end

@implementation FAQVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.SKSTableViewDelegate = self;
    
    self.tableView.estimatedRowHeight = 500.0; // for example. Set your average height
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    
    [self callGetFAQService:self.tempStr];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(loanIdChanged:)
                                                 name:NotifyUserloanID
                                               object:nil];
    
//    contents=@[@[@[@"Home"],
//                 @[@"Services", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property", @"Unsecured Business Loan", @"Lease Rental Discounting"],
//                 @[@"About us"],@[@"Contact"],@[@"FAQ", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property",@"Lease Rental Discounting"],@[@"Track Application"],@[@"Blog"]]];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UpdateList

- (void)loanIdChanged:(NSNotification*)notification {
    
    NSDictionary *temp = (NSDictionary *)notification.userInfo;
    [self callGetFAQService:temp[@"loanID"]];
}


#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [contents count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [contents[section] count];
}

- (NSInteger)tableView:(SKSTableView *)tableView numberOfSubRowsAtIndexPath:(NSIndexPath *)indexPath
{
    return [contents[indexPath.section][indexPath.row] count] - 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"SKSTableViewCell";
    
    SKSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
        cell = [[SKSTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    
    cell.textLabel.text = contents[indexPath.section][indexPath.row][0];
    cell.textLabel.numberOfLines = 0;
    
    cell.expandable = YES;
    
    
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForSubRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"UITableViewCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@", contents[indexPath.section][indexPath.row][indexPath.subRow]];
    cell.textLabel.numberOfLines = 0;
//    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell.textLabel setFont:[UIFont systemFontOfSize:12.0f]];
    return cell;
}


- (void)callGetFAQService:(NSString *)catId {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetFAQ>\n"
                             "<tem:strCatId>%@</tem:strCatId>\n"
                             "</tem:GetFAQ>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",catId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetFAQ_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetFAQResponse"] objectForKey:@"GetFAQResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                NSMutableArray *arrtemp= [NSMutableArray new];
                [arrtemp addObject:values[i][0][@"Question"]];
                [arrtemp addObject:values[i][0][@"Answer"]];
                [arr addObject:arrtemp];
            }

            NSMutableArray *rr = [NSMutableArray new];
            [rr addObject:arr];
            contents = rr;
            [_tableView reloadData];
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    if ([[tableView cellForRowAtIndexPath:indexPath] isKindOfClass:[SKSTableViewCell class]]) {
//        NSLog(@"If gya");
//    return 200.0f;
//    }
//    else {
//        NSLog(@"else gya");
//        return 100.0f;
//    }
//}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
