//
//  ForgotPwdVC.h
//  LoanBaba
//
//  Created by Nilesh Pal on 18/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotPwdVC : UIViewController

@end
