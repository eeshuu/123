//
//  LoanHistoryVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 07/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "LoanHistoryVC.h"
#import "CellHistory.h"
@interface LoanHistoryVC ()
{
    NSMutableArray *arrayLoanList;
}
@end

@implementation LoanHistoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tblLoanHistory.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    arrayLoanList= [NSMutableArray new];
    if ([SharedInstance isNetworkConnected])
    {
        [self callGetLoanHistory];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - UITableView DataSource & Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayLoanList count];

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentiFire = @"CellHistory";
    CellHistory *cell = (CellHistory *)[tableView dequeueReusableCellWithIdentifier:cellIdentiFire forIndexPath:indexPath];
    NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithDictionary:[arrayLoanList objectAtIndex:indexPath.row]];
    [cell setData:dict];
    return cell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}


- (void)callGetLoanHistory {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetLoanHistory>\n"
                             "<tem:strUserId>%@</tem:strUserId>\n"
                             "</tem:GetLoanHistory>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",[USER_PREF valueForKey:@"RId"]];
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetLoanHistory_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetLoanHistoryResponse"] objectForKey:@"GetLoanHistoryResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data History %@",arr);
            
            arrayLoanList = [NSMutableArray arrayWithArray:arr];
            [_tblLoanHistory reloadData];
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
