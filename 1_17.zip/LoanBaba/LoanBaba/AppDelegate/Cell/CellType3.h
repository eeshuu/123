//
//  CellType3.h
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellType3 : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblQuestionType3;
@property (strong, nonatomic) IBOutlet UITextField *TxtQuestionType3;
-(void)setupIU;
@end
