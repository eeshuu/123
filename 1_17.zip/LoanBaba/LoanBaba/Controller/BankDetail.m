//
//  BankDetail.m
//  iFishPocket
//
//  Created by cis on 10/3/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import "BankDetail.h"
#import "UIImageView+WebCache.h"
#import "ApplicationFormVC.h"
@interface BankDetail ()
@property (weak, nonatomic) IBOutlet UIImageView *imgBanklogo;
@property (weak, nonatomic) IBOutlet UILabel *lblLoadAmount;
@property (weak, nonatomic) IBOutlet UILabel *lblInterestRate;
@property (weak, nonatomic) IBOutlet UILabel *lblPrecessingFee;
@property (weak, nonatomic) IBOutlet UILabel *lblEMI;
@property (weak, nonatomic) IBOutlet UILabel *lblPrencipalAmount;
@property (weak, nonatomic) IBOutlet UILabel *lblMDP;
@property (weak, nonatomic) IBOutlet UILabel *lblTenure;
@property (weak, nonatomic) IBOutlet UILabel *lblOD;
@property (weak, nonatomic) IBOutlet UILabel *lblApprovalIN;
@property (weak, nonatomic) IBOutlet UILabel *lblPPPFees;
@property (weak, nonatomic) IBOutlet UILabel *lblTotalInterest;
@property (weak, nonatomic) IBOutlet UILabel *lblInterestType;

@end

@implementation BankDetail
@synthesize dict,strRequestId;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Loan Info";
    [self addHomeButton];
    [self setData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)addHomeButton {
    UIButton *btnlog = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnlog setFrame:CGRectMake(0, 0, 30, 30)];
    [btnlog setImage:[UIImage imageNamed:@"home"] forState:UIControlStateNormal];
    [btnlog addTarget:self action:@selector(action_Home) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *right = [[UIBarButtonItem alloc]initWithCustomView:btnlog];
    self.navigationItem.rightBarButtonItem = right;
}

- (void)action_Home {
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex: 1] animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark-Action
-(void)setData
{
    [self.lblLoadAmount setText:[NSString stringWithFormat:@"%.0f",[[dict objectForKey:@"PA"] floatValue]]];
    [self.lblInterestRate setText:[dict objectForKey:@"RateOfInterest"]];
    [self.lblPrecessingFee setText:[dict objectForKey:@"ProcessingFee"]];
    [self.lblEMI setText:[dict objectForKey:@"EMI"]];
    [self.lblPrencipalAmount setText:[dict objectForKey:@"PA"]];
    [self.lblMDP setText:[dict objectForKey:@"MinDownPayment"]];
    [self.lblTotalInterest setText:[dict objectForKey:@"TotalInt"]];
    [self.lblInterestType setText:[NSString stringWithFormat:@"%@ Interest",[dict objectForKey:@"InterestType"]]];
    [self.lblTenure setText:[dict objectForKey:@"Year"]];
    [self.lblOD setText:[dict objectForKey:@"OtherCharges"]];
    [self.lblApprovalIN setText:[dict objectForKey:@"ApprovalIn"]];
    [self.lblPPPFees setText:[dict objectForKey:@"PartPrePayment"]];
    
    [self.imgBanklogo sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://loanbaba.com/images/logo/%@",[dict objectForKey:@"PhotoBig"]]] placeholderImage:[UIImage imageNamed:@"image_not_found"] completed:nil];
    
}
- (IBAction)btnContinue:(id)sender {
    
    if ([SharedInstance isNetworkConnected])
    {
        [self callPostUpdateBankAmountTenuerService];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}




- (void)callPostUpdateBankAmountTenuerService {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostUpdateBankAmountTenuer>\n"
                             "<tem:strQuotReqId>%@</tem:strQuotReqId>\n"
                             "<tem:strBankId>%@</tem:strBankId>\n"
                             "<tem:strAmount>%@</tem:strAmount>\n"
                             "<tem:strTen>%@</tem:strTen>\n"
                             "</tem:PostUpdateBankAmountTenuer>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",self.strRequestId,self.dict[@"BankId"],self.dict[@"PA"],self.dict[@"Year"]];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostUpdateBankAmountTenuer_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostUpdateBankAmountTenuerResponse"] objectForKey:@"PostUpdateBankAmountTenuerResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
             NSLog(@"Data bank submit %@",arr);
            
            if (arr.count > 0) {
                if ([arr[0][@"Status"] isEqualToString:@"true"]) {
                    ApplicationFormVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ApplicationFormVC"];
                    vc.strRequestId = self.strRequestId;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                else {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                }
            }
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
