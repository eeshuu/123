//
//  BlogVC.m
//  workly
//
//  Created by Nilesh Pal on 29/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "BlogVC.h"
#import "CellBlog.h"
#import "UIImageView+WebCache.h"
#import "BlogDetailVC.h"
@interface BlogVC ()
{
    NSArray *arrBlog;
}
@end

@implementation BlogVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_tblBlog setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    
    [self callGetBlogList];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    if (!self.isSlide) {
        return NO;
    }
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark-TableView deligate

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrBlog count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellBlog *cell = [tableView dequeueReusableCellWithIdentifier:@"Blog"];
    [cell.imgBlog sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://loanbaba.com/images/blog/%@",arrBlog[indexPath.row][@"ImageFiles"]]]];
    cell.lblTitle.text = arrBlog[indexPath.row][@"Title"];
    [cell.btnDate setTitle:[self dateString:arrBlog[indexPath.row][@"PostDate"]] forState:UIControlStateNormal];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    BlogDetailVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"BlogDetailVC"];
    vc.strBlogId = arrBlog[indexPath.row][@"Id"];
    [self.navigationController pushViewController:vc animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSString *)dateString:(NSString *)date {

    NSDateFormatter *df = [[NSDateFormatter alloc]init];
    [df setDateFormat:@"MM/dd/yyyy HH:mm:ss a"];
    NSDate *dateObj =[df dateFromString:date];
    [df setDateFormat:@"MMM dd, yyyy"];
    return  [df stringFromDate:dateObj];
    
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    searchBar.showsCancelButton = YES;
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    if (searchBar.text.length>0) {
        [self callGetBlogListBySearch];
    }
}
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    searchBar.showsCancelButton = NO;
    [searchBar resignFirstResponder];
}
- (void)callGetBlogList {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetBlogList/>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n"];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetBLOG_LIST_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetBlogListResponse"] objectForKey:@"GetBlogListResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            arrBlog = [NSArray arrayWithArray:arr];
            [_tblBlog reloadData];
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

- (void)callGetBlogListBySearch {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetBlogListBySearch>\n"
                             "<tem:strSearch>%@</tem:strSearch>\n"
                             "</tem:GetBlogListBySearch>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",_searchBlog.text];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetBlogListBySearch_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetBlogListBySearchResponse"] objectForKey:@"GetBlogListBySearchResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            [self searchBarCancelButtonClicked:_searchBlog];
            _searchBlog.text = @"";
            if (arr.count>0) {
                arrBlog = [NSArray arrayWithArray:arr];
                [_tblBlog reloadData];
            }
            else {
                [SharedInstance showAlert:@"No data found." andTitle:alertTitle];
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
