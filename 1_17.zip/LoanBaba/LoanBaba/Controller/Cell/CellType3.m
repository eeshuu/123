//
//  CellType3.m
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import "CellType3.h"

@implementation CellType3

- (void)awakeFromNib {
    // Initialization code
    
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.TxtQuestionType3.leftView=leftView;
    self.TxtQuestionType3.leftViewMode=UITextFieldViewModeAlways;
    self.TxtQuestionType3.layer.borderColor=[[UIColor grayColor] CGColor];
    self.TxtQuestionType3.layer.borderWidth=1.0f;
    [_lblQuestionType3 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
