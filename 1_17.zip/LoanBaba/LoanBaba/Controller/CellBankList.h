//
//  CellBankList.h
//  iFishPocket
//
//  Created by cis on 10/3/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellBankList : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgBankIcon;
@property (strong, nonatomic) IBOutlet UILabel *lblLoanAmount;
@property (strong, nonatomic) IBOutlet UILabel *lblProcessingFees;
@property (strong, nonatomic) IBOutlet UILabel *lblInterestRate;
@property (strong, nonatomic) IBOutlet UILabel *lblEMI;
-(void)setData:(NSMutableDictionary *)dict;

@end
