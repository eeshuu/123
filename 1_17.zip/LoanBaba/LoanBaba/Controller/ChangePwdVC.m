//
//  ChangePwdVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 07/10/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ChangePwdVC.h"

@interface ChangePwdVC ()

@end

@implementation ChangePwdVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)action_Submit:(id)sender {
    if ([SharedInstance isNetworkConnected])
    {
        if (_txtoldPwd.text.length>0 &&
            _txtNewPwd.text.length>0 &&
            _txtConfirmPwd.text.length>0) {
            if ([_txtNewPwd.text isEqualToString:_txtConfirmPwd.text]) {
                [self callPostUpdateChangePass];
            }
            else {
                [SharedInstance showAlert:@"Password not matched." andTitle:alertTitle] ;
            }
            
        }
        else {
            [SharedInstance showAlert:@"All Fields are mandatory." andTitle:alertTitle] ;
        }
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

- (void)callPostUpdateChangePass {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostUpdateChangePass>\n"
                             "<tem:strUserId>%@</tem:strUserId>\n"
                             "<tem:strOldPass>%@</tem:strOldPass>\n"
                             "<tem:strNewPass>%@</tem:strNewPass>\n"
                             "</tem:PostUpdateChangePass>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",[USER_PREF valueForKey:@"RId"],_txtoldPwd.text,_txtNewPwd.text];
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:PostUpdateChangePass_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostUpdateChangePassResponse"] objectForKey:@"PostUpdateChangePassResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            
            NSLog(@"Data %@",arr);
            
            if (arr.count > 0) {
                if ([arr[0][@"Status"] isEqualToString:@"true"]) {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                    
                }
                else {
                    [SharedInstance showAlert:arr[0][@"Reason"] andTitle:alertTitle];
                }
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
