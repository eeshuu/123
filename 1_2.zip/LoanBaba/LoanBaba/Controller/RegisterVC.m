//
//  RegisterVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 16/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "RegisterVC.h"

@interface RegisterVC ()
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtPhoneNumber;
@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;

@end

@implementation RegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.title=@"REGISTRATION";
    // Do any additional setup after loading the view.
    [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1]];
    [self.navigationItem setHidesBackButton:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    UIImageView *imgHeaderOld=(UIImageView *)[self.navigationController.navigationBar viewWithTag:100];
    [imgHeaderOld removeFromSuperview];
    UIImageView *imgHeader=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 124, 20)];
    [imgHeader setImage:[UIImage imageNamed:@"header.png"]];
    [imgHeader setCenter:CGPointMake(self.navigationController.navigationBar.center.x, 22)];
    imgHeader.tag=100;
    [self.navigationController.navigationBar addSubview:imgHeader];
    
    [super viewWillAppear:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(BOOL)isValidate
{
    _txtName.text =[_txtName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtPassword.text =[_txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtEmail.text =[_txtEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    _txtPhoneNumber.text =[_txtPhoneNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
  
   if (!_txtName.text.length) {
        [SharedInstance showAlert:@"Please Enter User Name" andTitle:alertTitle];
        return NO;
    }
    else if (!_txtEmail.text.length) {
        [SharedInstance showAlert:@"Please Enter Email ID" andTitle:alertTitle];
        return NO;
    }
    else if (![SharedInstance emailAddressIsValid:_txtEmail.text]) {
        [SharedInstance showAlert:@"Please Enter Valid Email ID" andTitle:alertTitle];
        return NO;
    }
    else if (!_txtPassword.text.length) {
        [SharedInstance showAlert:@"Please Enter Password" andTitle:alertTitle];
        return NO;
    }
    else if (!_txtPhoneNumber.text.length) {
        [SharedInstance showAlert:@"Please Enter Phone Number Field" andTitle:alertTitle];
        return NO;
    }
       else{
        return true;
    }
    
}


- (IBAction)btnSumbitAction:(id)sender {
    
    if ([self isValidate]) {
        if ([SharedInstance isNetworkConnected])
        {
            [self callSignUpService];
        }
        else {
            [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
        }
    }
}

#pragma mark - UITextField delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return YES;
}

#pragma mark - WebAPIs

- (void)callSignUpService {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:PostUserRegister>\n"
                             "<tem:strName>%@</tem:strName>\n"
                             "<tem:strEmailId>%@</tem:strEmailId>\n"
                             "<tem:strPass>%@</tem:strPass>\n"
                             "<tem:strPhone>%@</tem:strPhone>\n"
                             "</tem:PostUserRegister>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",_txtName.text,_txtEmail.text,_txtPassword.text,_txtPhoneNumber.text];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:REGISTER_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"PostUserRegisterResponse"] objectForKey:@"PostUserRegisterResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            id values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            NSLog(@"arr %@",values);
            if ([values[0][0][@"Status"] isEqualToString:@"true"]) {
                [USER_PREF setValue:values[0][0][@"RId"] forKey:@"RId"];
                [USER_PREF setBool:YES forKey:@"Registered"];
                [USER_PREF synchronize];
                [self.navigationController popViewControllerAnimated:NO];
            }
            else {
                [SharedInstance showAlert:values[0][0][@"Reason"] andTitle:alertTitle];
            }
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

@end
