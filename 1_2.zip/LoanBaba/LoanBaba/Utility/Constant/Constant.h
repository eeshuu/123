//
//  Constant.h
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#ifndef LoanBaba_Constant_h
#define LoanBaba_Constant_h

// Alert Messages
#define networkNotConnected @"Internet connection not found, Please make sure that you are connected with internet"
#define serverNotResponding @"Something went wrong, Please try after some time"
#define alertTitle @"LoabBaba"

#define kClientId  @"14224776140-9dm66klousseojjvviacjjbdrr2g0e0c.apps.googleusercontent.com"

#define SharedInstance [ApplicationManager sharedManagerInstance]

#define USER_PREF [NSUserDefaults standardUserDefaults]

#define BASE_URL_IMAGE @"https://loanbaba.com/images/uploads/category/"

#define NotifyUserloanID @"com.loanBaba.UserloanID"
#define NotifyUserLoan @"com.loanBaba.Userloan"




// Question TypeID

#define RADIO_BUTTON @"1"
#define DATE_TIME_PICKER @"2"
#define DROP_DOWN @"3"
#define MONEY_NUMBER @"4"
#define NORMAL_TEXT @"5"
#define NONE @"0"


// Webservice URLs

#define BASE_URL @"http://tempuri.org/"

#define LOGIN_FB_GOOGLE_URL BASE_URL@"PostUserFBGoogle"

#define LOGIN_URL BASE_URL@"CheckUser"

#define REGISTER_URL BASE_URL@"PostUserRegister"

#define FORGOT_PWD_URL BASE_URL@"ForgotPassword"

#define GetCategoryList_URL BASE_URL@"GetCategoryList"

#define GetQuestionByCatId_URL BASE_URL@"GetQuestionByCatId"

#define GetFAQ_URL BASE_URL@"GetFAQ"

#endif
