 //
//  LeftMenuViewController.m
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "LeftMenuViewController.h"
#import "HomeVC.h"
#import "SKSTableView.h"
#import "SKSTableViewCell.h"
#import "SKSTableViewCellIndicator.h"
@implementation LeftMenuViewController
{
  NSArray *contents;
}

#pragma mark - UIViewController Methods -

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self.slideOutAnimationEnabled = YES;
    
    return [super initWithCoder:aDecoder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.SKSTableViewDelegate = self;
    
    
    
//    contents=[[NSMutableArray alloc]init];
    
//        [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Home",@"key",nil]];
//    //
//        [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Services",@"key",@[@{@"Title":@"Car Loan"},@{@"Title":@"Unsecured Personal Loan"},@{@"Title":@"Unsecured Business Loan"},@{@"Title":@"Home Loan"},@{@"Title":@"loan Against Property"},@{@"Title":@"Lease Rental "},@{@"Title":@"Lease Rental Discounting "}],@"array",nil]];
//    //    [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"About us",@"key",nil]];
//    //    [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Contact",@"key",nil]];
//    //
//        [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"FAQ",@"key", @[@{@"Title":@"Car Loan"},@{@"Title":@"Unsecured Personal Loan"},@{@"Title":@"Unsecured Business Loan"},@{@"Title":@"Home Loan"},@{@"Title":@"Loan Against Property"},@{@"Title":@"Lease Rental Discounting "}], @"array",nil]];
//    //
//        [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Finance Tools",@"key", @[@{@"Title":@"EMI Calculater"},@{@"Title":@"Eligibilty Calculater"}], @"array",nil]];
//    //    [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Track Application",@"key",nil]];
//    //    [contents addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Blog",@"key",nil]];
//    
    contents=@[@[@[@"Home"],
           @[@"Services", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property", @"Unsecured Business Loan", @"Lease Rental Discounting"],
           @[@"About us"],@[@"Contact"],@[@"FAQ", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property",@"Lease Rental Discounting"],@[@"Track Application"],@[@"Finance Tools", @"EMI Calculator", @"Eligibility Calculator"],@[@"Blog"]]];
    
    
//    contents=@[@[@[@"Section0_Row0", @"Row0_Subrow1",@"Row0_Subrow2"],
//                 @[@"Section0_Row1", @"Row1_Subrow1", @"Row1_Subrow2", @"Row1_Subrow3", @"Row1_Subrow4", @"Row1_Subrow5", @"Row1_Subrow6", @"Row1_Subrow7", @"Row1_Subrow8", @"Row1_Subrow9", @"Row1_Subrow10", @"Row1_Subrow11", @"Row1_Subrow12"],
//                 @[@"Section0_Row2"]]];
    
//    contents=@[@[@[@"Home"],
//                 @[@"Section0_Row1", @"Row1_Subrow1", @"Row1_Subrow2", @"Row1_Subrow3", @"Row1_Subrow4", @"Row1_Subrow5", @"Row1_Subrow6", @"Row1_Subrow7", @"Row1_Subrow8", @"Row1_Subrow9", @"Row1_Subrow10", @"Row1_Subrow11", @"Row1_Subrow12"],
//                 @[@"Section0_Row2"]]];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [contents count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [contents[section] count];
}

- (NSInteger)tableView:(SKSTableView *)tableView numberOfSubRowsAtIndexPath:(NSIndexPath *)indexPath
{
    return [contents[indexPath.section][indexPath.row] count] - 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"SKSTableViewCell";
    
    SKSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
        cell = [[SKSTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    
    cell.textLabel.text = contents[indexPath.section][indexPath.row][0];
    
    
    if ((indexPath.section == 0 && (indexPath.row == 1 || indexPath.row == 4 || indexPath.row == 6)))
        cell.isExpandable = YES;
    else
        cell.isExpandable = NO;
    
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForSubRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"UITableViewCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell)
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@", contents[indexPath.section][indexPath.row][indexPath.subRow]];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell.textLabel setFont:[UIFont systemFontOfSize:12.0f]];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row)
    {
        case 0:
        {
            HomeVC *VC = [[UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil] instantiateViewControllerWithIdentifier: @"HomeVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:VC
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            
        }
            break;
        case 1:
        {
            
            
        }
            break;
    }
    
}

- (IBAction)btnUploadAction:(id)sender {
}
- (IBAction)btnAccountAction:(id)sender {
}
- (IBAction)btnSignoutAction:(id)sender {
    [[SlideNavigationController sharedInstance] popToRootViewControllerAnimated:NO];
}


@end
