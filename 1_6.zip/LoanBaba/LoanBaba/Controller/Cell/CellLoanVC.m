//
//  CellLoanVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 19/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "CellLoanVC.h"

@implementation CellLoanVC

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setData:(NSMutableDictionary *)dict
{
    [self.lblTitle setText:[dict objectForKey:@"Title"]];
    [self.imgIcon setImage:[UIImage imageNamed:[dict objectForKey:@"Icon"]]];
}

@end
