//
//  EMICalVC.h
//  LoanBaba
//
//  Created by Nilesh Pal on 21/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMICalVC : UIViewController

@property (nonatomic)BOOL isSlide;
@end
