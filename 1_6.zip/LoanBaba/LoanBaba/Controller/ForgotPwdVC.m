//
//  ForgotPwdVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 18/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ForgotPwdVC.h"

@interface ForgotPwdVC ()

@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@end

@implementation ForgotPwdVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)isValidate
{

    _txtEmail.text =[_txtEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

    if (![SharedInstance emailAddressIsValid:_txtEmail.text]) {
        [SharedInstance showAlert:@"Please Enter Valid Email ID" andTitle:alertTitle];
        return NO;
    }
    else{
        return true;
    }
    
}


- (IBAction)btnSumbitAction:(id)sender {
    
    if ([self isValidate]) {
        if ([SharedInstance isNetworkConnected])
        {
            [self callForgotPwdService];
        }
        else {
            [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
        }
    }
}


#pragma mark - WebAPIs

- (void)callForgotPwdService {
    
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:ForgotPassword>\n"
                             "<tem:strUserEmailId>%@</tem:strUserEmailId>\n"
                             "</tem:ForgotPassword>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",_txtEmail.text];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:FORGOT_PWD_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"ForgotPasswordResponse"] objectForKey:@"ForgotPasswordResult"];
            //[[{"Status":"true","Reason":"Check your mail for Password."}]]
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            id values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            NSLog(@"arr %@",values);
            if ([values[0][0][@"Status"] isEqualToString:@"true"]) {
                [SharedInstance showAlert:values[0][0][@"Reason"] andTitle:alertTitle];
                [self.navigationController popViewControllerAnimated:YES];
            }
            else {
                [SharedInstance showAlert:values[0][0][@"Reason"] andTitle:alertTitle];
            }
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
