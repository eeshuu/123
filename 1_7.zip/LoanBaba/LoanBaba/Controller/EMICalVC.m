//
//  EMICalVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 21/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "EMICalVC.h"
#import <math.h>
@interface EMICalVC ()

@property (weak, nonatomic) IBOutlet UITextField *txtLoanAmount;
@property (weak, nonatomic) IBOutlet UITextField *txtInterestRate;
@property (weak, nonatomic) IBOutlet UIButton *btnYear;
@property (weak, nonatomic) IBOutlet UITextField *txtTenure;
@property (weak, nonatomic) IBOutlet UIButton *btnMonth;
@property (weak, nonatomic) IBOutlet UITableView *tblAnswer;
@property (weak, nonatomic) IBOutlet UIButton *btnCalculate;
@property (weak, nonatomic) IBOutlet UILabel *lblLoadAmount;
@property (weak, nonatomic) IBOutlet UILabel *lblInterestRate;
@property (weak, nonatomic) IBOutlet UILabel *lblTenure;
@end

@implementation EMICalVC
{
    NSMutableArray *arrayAnswer;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"EMI Calculator"];
    // Do any additional setup after loading the view.
    
    
    UIImageView *imgHeader=(UIImageView *)[self.navigationController.navigationBar viewWithTag:100];
    [imgHeader removeFromSuperview];
    
    [self setupUI];
    [_btnYear setSelected:YES];
    [self actionYearToggle:_btnYear];
    
    
    arrayAnswer=[[NSMutableArray alloc]init];
    
    NSMutableDictionary *dict0=[[NSMutableDictionary alloc]initWithDictionary:@{@"title":@"Monthly Payment",@"answer":@"1000"}];
     NSMutableDictionary *dict1=[[NSMutableDictionary alloc]initWithDictionary:@{@"title":@"Total Interest Payable",@"answer":@"1000"}];
     NSMutableDictionary *dict2=[[NSMutableDictionary alloc]initWithDictionary:@{@"title":@"Total of paments",@"answer":@"1000"}];
    [arrayAnswer addObject:dict0];
    [arrayAnswer addObject:dict1];
    [arrayAnswer addObject:dict2];
    _tblAnswer.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    if (!self.isSlide) {
        return NO;
    }
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - UITextField delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return YES;
}
#pragma mark-Action
-(void)setupUI
{
    /*set left view in all the textfield*/
    UIView *loanAmmount=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.txtLoanAmount.frame.size.height)];
    [loanAmmount setBackgroundColor:[UIColor colorWithRed:238.0f/255.0f green:238.0f/255.0f blue:238.0f/255.0f alpha:1]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"rupee.png"]];
    [loanAmmount addSubview:imageloanAmmount];
    [self.txtLoanAmount setRightViewMode:UITextFieldViewModeAlways];
    self.txtLoanAmount.rightView=loanAmmount ;
    
    UIView *loanPercent=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.txtLoanAmount.frame.size.height)];
    [loanPercent setBackgroundColor:[UIColor colorWithRed:238.0f/255.0f green:238.0f/255.0f blue:238.0f/255.0f alpha:1]];
    UIImageView *imageloanPercent=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanPercent setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanPercent setImage:[UIImage imageNamed:@"percentage.png"]];
    [loanPercent addSubview:imageloanPercent];
    [self.txtInterestRate setRightViewMode:UITextFieldViewModeAlways];
    self.txtInterestRate.rightView=loanPercent ;
    
    
    
   
    
    
    
    UIView *leftFirst=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    UIView *leftSecond=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    UIView *leftThird=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.txtInterestRate.leftView=leftFirst;
    self.txtLoanAmount.leftView=leftSecond;
    self.txtTenure.leftView=leftThird;
   
    
    self.txtInterestRate.leftViewMode=self.txtLoanAmount.leftViewMode=self.txtTenure.leftViewMode=UITextFieldViewModeAlways;
    
    
    [self.txtLoanAmount.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [self.txtLoanAmount.layer setBorderWidth:1.0f];
    self.txtLoanAmount.layer.borderColor=self.txtInterestRate.layer.borderColor=self.txtTenure.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtLoanAmount.layer.borderWidth=self.txtInterestRate.layer.borderWidth=self.txtTenure.layer.borderWidth=_btnCalculate.layer.borderWidth=1.0f;
    
    [_btnCalculate.layer setCornerRadius:4.0f];
    self.btnCalculate.layer.borderColor=[[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1] CGColor];
    
    
    
    [_lblLoadAmount setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
    [_lblInterestRate setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
    [_lblTenure setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
    
    
    
    
    [_btnCalculate.titleLabel setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
    [_btnYear.titleLabel setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
    [_btnMonth.titleLabel setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
    
 }

- (IBAction)actionYearToggle:(id)sender {
    
    
    
    if (sender == self.btnYear) {
        [self.btnYear setSelected:YES];
        [self.btnYear setBackgroundColor:[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1]];
        [self.btnMonth setBackgroundColor:[UIColor colorWithRed:238.0f/255.0f green:238.0f/255.0f blue:238.0f/255.0f alpha:1]];
        [self.btnMonth setSelected:NO];
    }
    else {
        
        [self.btnMonth setBackgroundColor:[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1]];
        [self.btnYear setBackgroundColor:[UIColor colorWithRed:238.0f/255.0f green:238.0f/255.0f blue:238.0f/255.0f alpha:1]];
        [self.btnYear setSelected:NO];
        [self.btnMonth setSelected:YES];
    }

    
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}


#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayAnswer count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CustomCell";
    UITableViewCell *cell = [[UITableViewCell alloc]init];
    
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    UILabel *lblTitle=[[UILabel alloc]initWithFrame:CGRectMake(10, 5,tableView.frame.size.width-10, 18)];
    [lblTitle setFont:[UIFont systemFontOfSize:15]];
    [lblTitle setTextColor:[UIColor whiteColor]];
    [lblTitle setText:[[arrayAnswer objectAtIndex:indexPath.row] objectForKey:@"title"]];
    
    
    UILabel *lblAnswer=[[UILabel alloc]initWithFrame:CGRectMake(10, 25,tableView.frame.size.width-10, 21)];
    [lblAnswer setFont:[UIFont boldSystemFontOfSize:16]];
    [lblAnswer setTextColor:[UIColor whiteColor]];
    [lblAnswer setText:[[arrayAnswer objectAtIndex:indexPath.row] objectForKey:@"answer"]];
    
    [cell addSubview:lblTitle];
    [cell addSubview:lblAnswer];
    [cell setBackgroundColor:[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1]];
    return cell;
}

- (IBAction)ActionBtnCalculate:(id)sender {
    
    if ([self isValidate]) {
        if ([_tblAnswer isHidden]) {
            [_tblAnswer setHidden:NO];
        }
        float p=[_txtLoanAmount.text floatValue];
        float r=[_txtInterestRate.text floatValue]/12/100;
        float n=0.0;
        
        if ([_btnMonth isSelected]) {
            n=12*[_txtTenure.text floatValue];
        }
        else{
            n=[_txtTenure.text floatValue];
        }
        
        float e=p*r*(pow((1+r), n)/(pow((1+r), n)-1));
        
        
        
        float inetest=roundf(e*n-p);
        p=roundf(e*n);
        
        if ([_btnMonth isSelected]) {
            [[arrayAnswer objectAtIndex:0]setValue:@"Monthly Payment" forKey:@"title"];
        }
        else{
            [[arrayAnswer objectAtIndex:0]setValue:@"Yearly Payment" forKey:@"title"];
        }
        
        
        [[arrayAnswer objectAtIndex:0]setValue:[NSString stringWithFormat:@"%.0f",e] forKey:@"answer"];
        [[arrayAnswer objectAtIndex:1]setValue:[NSString stringWithFormat:@"%.0f",inetest] forKey:@"answer"];
        [[arrayAnswer objectAtIndex:2]setValue:[NSString stringWithFormat:@"%.0f",p] forKey:@"answer"];
        [_tblAnswer reloadData];
 }
}

-(BOOL)isValidate
{
    if ([_txtLoanAmount.text length]== 0) {
        [[ApplicationManager sharedManagerInstance]showAlert:@"Load amount is empty." andTitle:@"Oops!"];
        return false;
    }
    else if ([_txtInterestRate.text length]== 0) {
        [[ApplicationManager sharedManagerInstance]showAlert:@"Rate is empty." andTitle:@"Oops!"];
        return false;
    }
    else if ([_txtTenure.text length]== 0)
    {
        [[ApplicationManager sharedManagerInstance]showAlert:@"Tenure is empty." andTitle:@"Oops!"];
        return false;
    }
    return true;
}


@end
