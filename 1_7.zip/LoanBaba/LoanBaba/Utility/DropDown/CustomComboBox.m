//
//  CustomComboBox.m
//  CharityDirectory
//
//  Created by abc on 6/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomComboBox.h"
#import <QuartzCore/QuartzCore.h>
//#import "CityDatabase.h"
#import "AppDelegate.h"


@implementation CustomComboBox

@synthesize listArray;
@synthesize delegate;



//-(void)loadList{
//    
//    listArray =nil;
//    listArray = [[NSArray alloc] initWithArray:[CityDatabase getCities]];
//    
//    if (listArray.count < 5) {
//        comboCurrentExtendedHeight = [listArray count] * comboHeight;
//    }else{
//        comboCurrentExtendedHeight = 5 * comboHeight;
//    }
//    
//    
//    [listTableView reloadData];
//    
//
//    
//}




-(void)initialize{
    

    

    previousVisibleRow = 0;
    currentVisibleRow = 0;
    
    
    listTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [listTableView setDelegate:self];
    [listTableView setDataSource:self];
    [listTableView setBackgroundColor:[UIColor clearColor]];
    [listTableView setBounces:NO];
    
    [listTableView.layer setCornerRadius:5.0f];
    [listTableView.layer setBorderWidth:.5f];
        [listTableView.layer setBorderColor:[[UIColor grayColor] CGColor]];
    [listTableView setClipsToBounds:YES];
    
    [listTableView setSeparatorStyle:(UITableViewCellSeparatorStyleSingleLine)];
    //[listTableView setSeparatorInset:(UIEdgeInsetsZero)];
    
    [self addSubview:listTableView];
    
    [self.layer setCornerRadius:5.0f];
    [self.layer setBorderWidth:1.0f];
    [self.layer setBorderColor:[UIColor clearColor].CGColor];
    [self setClipsToBounds:YES];
    
    
    [listTableView setScrollEnabled:NO];
    

    

    
}

-(id)initWithRect:(CGRect)rect list:(NSArray *)list{
//-(id)initWithOrigin:(CGPoint)origin list:(NSArray *)list{
    
    if (self = [super init]) {
        
        
        comboWidth = rect.size.width;
        comboHeight = rect.size.height;

        
        if (list.count > 4) {
            
            listArray = [[NSArray alloc] initWithArray:list];
            comboCurrentExtendedHeight = 5 * comboHeight;
            
        }else if(list.count > 0){
            
            listArray = [[NSArray alloc] initWithArray:list];
            comboCurrentExtendedHeight = list.count * comboHeight;   
            
        }else{
            listArray = [[NSArray alloc] initWithArray:list];
            comboCurrentExtendedHeight = comboHeight;
        }
        
        
        
        [self setFrame:rect];
        
        
               
        
        [self initialize];
    }
    
    return self;
}



-(void)closeCombobox{
 
   
    
    CGRect rect = listTableView.frame;
    
    rect.size.height = comboHeight;
    
    
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, rect.size.width, rect.size.height)];
    [listTableView setFrame:rect];
    
    //////
    
    
    rect.origin.y = comboHeight * previousVisibleRow;
    

    
    [listTableView scrollRectToVisible:rect animated:NO];
    [listTableView setScrollEnabled:NO];
    
    UITableViewCell *cell = [listTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:previousVisibleRow inSection:0]];

    
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:1];
    
    [imageView setImage:[UIImage imageNamed:@"arrow-down.png"]];
   
    
    
//    [delegate comboBox:self didSelectItem:[listArray objectAtIndex:indexPath.row]]; 

}


-(void)selectItemAtIndex:(NSInteger)index{
    if (listArray.count > index && index >= 0) {
        
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        [self tableView:listTableView didSelectRowAtIndexPath:indexPath];
        [listTableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:(UITableViewScrollPositionTop)];
    }
}



#pragma mark - Table View Delegate and data source...

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor whiteColor]];
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (listArray.count) {
        return [listArray count];
    }
    
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellIdentifier = @"Identifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
       
        
//        CAGradientLayer *gradient = [CAGradientLayer layer];
//        [gradient setAnchorPoint:CGPointMake(0, 0)];
//        gradient.position = CGPointMake(0.0f, 0.0f);
//        gradient.bounds = CGRectMake(0, 0, tableView.frame.size.width, comboHeight);
//        
//        
//        gradient.cornerRadius = 5.0;
//        
//        gradient.colors = [NSArray arrayWithObjects:
//                           (id)[UIColor colorWithRed:255.0f/255.0f
//                                               green:255.0f/255.0f
//                                                blue:255.0f/255.0f
//                                               alpha:1.0].CGColor,
//                           (id)[UIColor colorWithRed:255.0f/255.0f
//                                               green:255.0f/255.0f
//                                                blue:255.0f/255.0f
//                                               alpha:1.0].CGColor,
//                           (id)[UIColor colorWithRed:255.0f/255.0f
//                                               green:255.0f/255.0f
//                                                blue:255.0f/255.0f
//                                               alpha:1.0].CGColor,
//                           nil];
//        
//        
//       [cell.layer addSublayer:gradient];
        
       
               
        [cell.layer setBorderWidth:0.0f];
        [cell.layer setBorderColor:[UIColor whiteColor].CGColor];
        
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(tableView.frame.size.width - comboHeight+5, 0, comboHeight-5, comboHeight)];


        [imageView setTag:1];
        [cell addSubview:imageView];
        
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, tableView.frame.size.width - 49 - 5, comboHeight)];
        [label setTag:2];
        [label setBackgroundColor:[UIColor clearColor]];
        [label setTextColor:[UIColor blackColor]];
//        [label setFont:[UIFont boldSystemFontOfSize:15.0f]];
        
        
               
                
        [cell addSubview:label];
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:1];
    
    if (indexPath.row == currentVisibleRow) {
        [imageView setImage:[UIImage imageNamed:@"arrow-down.png"]];
    }else
        [imageView setImage:nil];
    
    UILabel *label = (UILabel *)[cell viewWithTag:2];
    
    
    if (listArray.count) {
        [label setFont:[UIFont fontWithName:FONT_REGULAR size:19.0f]];
        [label setText:[NSString stringWithString:[listArray objectAtIndex:indexPath.row]]];
    }else{
        [label setText:@"Empty"];
    }
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return comboHeight;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    [self.superview bringSubviewToFront:self];
    
    CGRect rect = tableView.frame;

    if (self.frame.size.height == comboHeight) {
        
        // combo will expand here............
        

        rect.size.height = comboCurrentExtendedHeight;

        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5f];
        
        [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, rect.size.height)];
        [tableView setFrame:rect];
        
        [UIView commitAnimations];
        

        
        [tableView setScrollEnabled:YES];
        
        
        previousVisibleRow = indexPath.row;

        currentVisibleRow = -1;
        
        if (listArray.count == 1) {
            
            [delegate comboBox:self didSelectItem:[listArray objectAtIndex:indexPath.row] atIndex:indexPath.row];

        }else{
            [delegate comboBoxDidExpand:self];
        }

        
    }
    //combo will shrink here........
    else{
        

        rect.size.height = comboHeight;
        
        
        [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, rect.size.width, rect.size.height)];
        [tableView setFrame:rect];
        
        
        previousVisibleRow = indexPath.row;

        currentVisibleRow = indexPath.row;

        [tableView setScrollEnabled:NO];

      
        
        [delegate comboBox:self didSelectItem:[listArray objectAtIndex:indexPath.row]atIndex:indexPath.row];

    }
    
   
    
    [tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];


    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:1];

    if (tableView.frame.size.height == comboHeight) {
        [imageView setImage:[UIImage imageNamed:@"arrow-down.png"]];
    }else{
        [imageView setImage:nil];
    }
    
    
    

}


-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}





@end
