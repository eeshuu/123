//
//  CellType2.m
//  iFishPocket
//
//  Created by cis on 9/29/15.
//  Copyright (c) 2015 Nilesh. All rights reserved.
//

#import "CellType2.h"

@implementation CellType2

- (void)awakeFromNib {
    // Initialization code
    

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setupIU{
    [_lblQuestionType2 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.TxtQuestionType2.frame.size.height)];
    [rightView setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"cal.png"]];
    [rightView addSubview:imageloanAmmount];
    [self.TxtQuestionType2 setRightViewMode:UITextFieldViewModeAlways];
    self.TxtQuestionType2.rightView=rightView ;
    
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.TxtQuestionType2.leftView=leftView;
    self.TxtQuestionType2.leftViewMode=UITextFieldViewModeAlways;
    self.TxtQuestionType2.layer.borderColor=[[UIColor grayColor] CGColor];
    self.TxtQuestionType2.layer.borderWidth=1.0f;
    [_lblQuestionType2 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    [_TxtQuestionType2 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
}

@end
