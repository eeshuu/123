//
//  AnswerVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 29/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "AnswerVC.h"
#import "AppDelegate.h"
#import "QuestionVC.h"
#import "CellType1.h"
#import "CellType2.h"
#import "CellType3.h"
#import "CellType4.h"
#import "CellType5.h"
@interface AnswerVC ()
{
    AppDelegate *appDelegate;
    NSMutableArray *arrayQuestion,*arrayAnswer;
}
@property (weak, nonatomic) IBOutlet UITableView *tblAnswer;
@end

@implementation AnswerVC

- (void)viewDidLoad {
    self.title=@"Review";
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    arrayQuestion=[[NSMutableArray alloc]initWithArray:appDelegate.arrayQuestion];
    arrayAnswer=[[NSMutableArray alloc]initWithArray:appDelegate.arrayAnswer];
    [_tblAnswer setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [_tblAnswer reloadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [appDelegate.arrayQuestion count];
    
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    NSMutableDictionary *dictCurrentQuestion=[[NSMutableDictionary alloc]initWithDictionary:[arrayQuestion objectAtIndex:indexPath.row]];
    int typeInt=[[dictCurrentQuestion  objectForKey:@"TypeId"] intValue];
    
    
    
    switch (typeInt) {
        case 1:
        {
            CellType1 *type1Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType1"];
            CGSize possibleSize = [arrayQuestion[indexPath.row][@"Title"] sizeWithFont:[type1Cell.lblQuestionType1 font] //font you are using
                                                                             constrainedToSize:CGSizeMake(type1Cell.lblQuestionType1.frame.size.width,9999)
                                                                                 lineBreakMode:NSLineBreakByWordWrapping];
            
            
            if (possibleSize.height+23 >90) {
                return possibleSize.height+23;
            }
            else{
                return 90;
            }

        }
            break;
        case 2:
        {
            CellType2 *type2Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType2"];
            CGSize possibleSize = [arrayQuestion[indexPath.row][@"Title"] sizeWithFont:[type2Cell.lblQuestionType2 font] //font you are using
                                                                     constrainedToSize:CGSizeMake(type2Cell.lblQuestionType2.frame.size.width,9999)
                                                                         lineBreakMode:NSLineBreakByWordWrapping];
            
            
            if (possibleSize.height+23 >90) {
                return possibleSize.height+60;
            }
            else{
                return 90;
            }
        }
            break;
        case 3:
        {
            CellType3 *type3Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType3"];
            CGSize possibleSize = [arrayQuestion[indexPath.row][@"Title"] sizeWithFont:[type3Cell.lblQuestionType3 font] //font you are using
                                                                     constrainedToSize:CGSizeMake(type3Cell.lblQuestionType3.frame.size.width,9999)
                                                                         lineBreakMode:NSLineBreakByWordWrapping];
            
            
            if (possibleSize.height+23 >90) {
                return possibleSize.height+60;
            }
            else{
                return 90;
            }

        }
            break;
        case 4:
        {
            CellType4 *type4Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType4"];
            CGSize possibleSize = [arrayQuestion[indexPath.row][@"Title"] sizeWithFont:[type4Cell.lblQuestionType4 font] //font you are using
                                                                     constrainedToSize:CGSizeMake(type4Cell.lblQuestionType4.frame.size.width,9999)
                                                                         lineBreakMode:NSLineBreakByWordWrapping];
            
            
            if (possibleSize.height+23 >90) {
                return possibleSize.height+60;
            }
            else{
                return 90;
            }
            
        }
            break;
        case 5:
        {
            CellType5 *type5Cell = [tableView dequeueReusableCellWithIdentifier:@"CellType5"];
            CGSize possibleSize = [arrayQuestion[indexPath.row][@"Title"] sizeWithFont:[type5Cell.lblQuestionType5 font] //font you are using
                                                                     constrainedToSize:CGSizeMake(type5Cell.lblQuestionType5.frame.size.width,9999)
                                                                         lineBreakMode:NSLineBreakByWordWrapping];
            
            
            if (possibleSize.height+23 >90) {
                return possibleSize.height+60;
            }
            else{
                return 90;
            }

        }
            break;
            
        default:
            break;
    }
    
    
    return 90;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSMutableDictionary *dictCurrentQuestion=[[NSMutableDictionary alloc]initWithDictionary:[arrayQuestion objectAtIndex:indexPath.row]];
    int typeInt=[[dictCurrentQuestion  objectForKey:@"TypeId"] intValue];
    
    QuestionVC *vc=(QuestionVC *)[arrayAnswer objectAtIndex:indexPath.row];
    
    
    switch (typeInt) {
        case 1:
        {
            CellType1 *type1Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType1"];
            [type1Cell.lblQuestionType1 setText:[dictCurrentQuestion objectForKey:@"Title"]];
            [type1Cell setupIU];
            return type1Cell;
        }
            break;
        case 2:
        {
            CellType2 *type2Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType2"];
            [type2Cell.TxtQuestionType2 setText:vc.txtType2.text];
            [type2Cell.lblQuestionType2 setText:[dictCurrentQuestion objectForKey:@"Title"]];
            [type2Cell setupIU];
            return type2Cell;
        }
            break;
        case 3:
        {
            CellType3 *type3Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType3"];
            [type3Cell.TxtQuestionType3 setText:vc.txtType3.text];
            [type3Cell.lblQuestionType3 setText:[dictCurrentQuestion objectForKey:@"Title"]];
            [type3Cell setupIU];
            return type3Cell;
        }
            break;
        case 4:
        {
            CellType4 *type4Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType4"];
            [type4Cell.lblQuestionType4 setText:[dictCurrentQuestion objectForKey:@"Title"]];
            [type4Cell.TxtQuestionType4 setText:vc.txtType4.text];
            [type4Cell setupIU];
            return type4Cell;
        }
            break;
        case 5:
        {
            CellType5 *type5Cell =[tableView dequeueReusableCellWithIdentifier:@"CellType5"];
            [type5Cell.TxtQuestionType5 setText:vc.txtType5.text];
            [type5Cell.lblQuestionType5 setText:[dictCurrentQuestion objectForKey:@"Title"]];
            [type5Cell setupIU];
            return type5Cell;
        }
            break;
            
        default:
            break;
    }
    

    
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

@end
