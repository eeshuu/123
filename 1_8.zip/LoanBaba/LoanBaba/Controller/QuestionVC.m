//
//  QuestionVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 22/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "QuestionVC.h"
#import "SAMenuDropDown.h"
#import "RadioButton.h"
#import "AnswerVC.h"
@interface QuestionVC ()<SAMenuDropDownDelegate>
{
    AppDelegate *appDelegate;
    NSMutableDictionary *dictCurrentQuestion;
    UIView *activeView;
    NSMutableArray *arrayType3,*arraySearchType3,*arrayType1;
    SAMenuDropDown *dropDownType3;
}
@property (weak, nonatomic) IBOutlet UIButton *btnPrevious;
@property (weak, nonatomic) IBOutlet UIButton *btnNext;
@property (weak, nonatomic) IBOutlet UIPageControl *pageController;


@property (weak, nonatomic) IBOutlet UIView *type1View;
@property (weak, nonatomic) IBOutlet UIView *type2View;
@property (weak, nonatomic) IBOutlet UIView *type3View;
@property (weak, nonatomic) IBOutlet UIView *type4View;
@property (weak, nonatomic) IBOutlet UIView *type5View;


@property (weak, nonatomic) IBOutlet UILabel *lbltype1Question;
@property (weak, nonatomic) IBOutlet UILabel *lbltype2Question;
@property (weak, nonatomic) IBOutlet UILabel *lbltype3Question;
@property (weak, nonatomic) IBOutlet UILabel *lbltype4Question;
@property (weak, nonatomic) IBOutlet UILabel *lbltype5Question;





@property (weak, nonatomic) IBOutlet UIButton *btnDropDownType3;


@property (weak, nonatomic) IBOutlet UIDatePicker *pickerType2;



@end

@implementation QuestionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Question's";
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [_pageController setNumberOfPages:[appDelegate.arrayQuestion count]];
    if (appDelegate.intQesCount == 0) {
        [self.btnPrevious setEnabled:NO];
        [self.btnPrevious setAlpha:.6];
    }
    else{
        [self.btnPrevious setEnabled:YES];
        [self.btnPrevious setAlpha:1];
    }
    
    
  
  
    
    [_pageController setCurrentPage:appDelegate.intQesCount];
    
    
    
    _btnNext.layer.cornerRadius=_btnNext.frame.size.height/2;
    _btnPrevious.layer.cornerRadius=_btnNext.frame.size.height/2;
    
    _btnNext.layer.borderWidth=_btnPrevious.layer.borderWidth=1.0;
    
    _btnNext.layer.borderColor=_btnPrevious.layer.borderColor=[[UIColor colorWithRed:30.0f/255.0f green:113.0f/255.0f blue:162.0f/255.0f alpha:1] CGColor];
    
    [self setupView];
    
    
    arrayType3=[[NSMutableArray alloc]init];
    arraySearchType3=[[NSMutableArray alloc]init];
    
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (appDelegate.intQesCount == 0) {
        [self.navigationItem setHidesBackButton:NO];
    }
    else{
        [self.navigationItem setHidesBackButton:YES];
    }

}

#pragma mark - Date picker Methods -

- (IBAction)dateChange:(id)sender {
 
    NSDateFormatter *dateFormater=[[NSDateFormatter alloc]init];
    dateFormater.dateFormat = @"dd-MMM-yyyy";
    [_txtType2 setText:[NSString stringWithFormat:@"%@",[dateFormater stringFromDate:_pickerType2.date]]];
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    if (!self.isSlide) {
        return NO;
    }
    UIImageView *imgHeader=(UIImageView *)[self.navigationController.navigationBar viewWithTag:100];
    [imgHeader removeFromSuperview];
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)btnNext:(id)sender {
    
    if ([self isValidate]) {
        
        
        [appDelegate.arrayAnswer addObject:[[self.navigationController viewControllers] lastObject]];
        dictCurrentQuestion=[appDelegate.arrayQuestion objectAtIndex:appDelegate.intQesCount];
        appDelegate.intQesCount++;
        if (appDelegate.arrayQuestion.count-appDelegate.intQesCount == 1) {
            
            AnswerVC *vc=[self.storyboard instantiateViewControllerWithIdentifier:@"AnswerVC"];
            [self.navigationController pushViewController:vc animated:NO];

        }
        else{
            
            QuestionVC *vc=[self.storyboard instantiateViewControllerWithIdentifier:@"QuestionVC"];
            [self.navigationController pushViewController:vc animated:NO];
        }
       

    }
    
}
- (IBAction)btnPrevious:(id)sender {
     [appDelegate.arrayAnswer removeLastObject];
    appDelegate.intQesCount--;
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma mark - UITextField delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField==_txtType2) {
        return false;
    }
     return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    // call an asynchronous HTTP reques
    
    
    if( textField == _txtType3 ) // lets say 3 chars mininum
    {
        NSString *strSearch=@"";
        if ([textField.text length]==1 && [string isEqualToString:@""]) {
            strSearch=@"";
        }
        else{
            strSearch = [textField.text stringByReplacingCharactersInRange:range withString:string];
        }
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.Title contains[c] %@)",strSearch];
        arraySearchType3 = [[NSMutableArray arrayWithArray:[arrayType3 filteredArrayUsingPredicate:predicate]] mutableCopy];
        [dropDownType3 setUpItemDataSourceWithNames:arraySearchType3 subtitles:nil imageNames:nil];
        [dropDownType3 self_showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
        
       
    }
    
    return YES;
}

#pragma mark-SAMenuDropDown Deligate
- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex
{
    if (dropDownType3==menuSender) {
         [_txtType3 setText:[[arraySearchType3 objectAtIndex:buttonIndex] objectForKey:@"Title"]];
        [dropDownType3 hideSADropDownMenu];
    }
   
}


#pragma mark-Action
-(void)setupView
{
    _type1View.hidden=_type2View.hidden=_type3View.hidden=_type4View.hidden=_type5View.hidden=YES;
       dictCurrentQuestion=[appDelegate.arrayQuestion objectAtIndex:appDelegate.intQesCount];
    switch ([[dictCurrentQuestion objectForKey:@"TypeId"] integerValue]) {
        case 1:
            [self setupType1];
            break;
        case 2:
            [self setupType2];
            break;
        case 3:
            [self setupType3];
            break;
        case 4:
            [self setupType4];
            break;
        case 5:
            [self setupType5];
            break;
        default:
            break;
    }
}


-(void)setupType1
{
    [self GetAnswerListByTypeId:[dictCurrentQuestion objectForKey:@"TypeId"] andQuesID:[dictCurrentQuestion objectForKey:@"Id"]];
    [_type1View setHidden:NO];
    [_type1View setFrame:CGRectMake(self.view.frame.size.width, _type1View.frame.origin.y, _type1View.frame.size.width, _type1View.frame.size.height)];
    [UIView animateWithDuration:.25 animations:^{
        _type1View.frame = CGRectMake(0, _type1View.frame.origin.y, _type1View.frame.size.width, _type1View.frame.size.height);
    }];
    [_lbltype1Question setText:[dictCurrentQuestion objectForKey:@"Title"]];
    [_lbltype1Question setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    
}

-(void)setupType1RadioButton
{
    int yRadio=_lbltype1Question.frame.origin.y+_lbltype1Question.frame.size.height;
    
    for (int i=0; i<[arrayType1 count]; i++) {
        RadioButton *btnRadio = [[RadioButton alloc] initWithGroupId:@"first group" index:i];
        btnRadio.frame = CGRectMake(10,yRadio*i+yRadio,22,22);
        [_type1View addSubview:btnRadio];
        
       
        UILabel *labelTitle =[[UILabel alloc] initWithFrame:CGRectMake(40, btnRadio.frame.origin.y, 300, 22)];
        labelTitle.backgroundColor = [UIColor clearColor];
        labelTitle.text = [[arrayType1 objectAtIndex:i] objectForKey:@"Title"];
        labelTitle.numberOfLines = 0;
        labelTitle.lineBreakMode = NSLineBreakByWordWrapping;
        [labelTitle setFont:[UIFont fontWithName:FONT_REGULAR size:17]];
        [_type1View addSubview:labelTitle];
    }
    [RadioButton addObserverForGroupId:@"first group" observer:self];

}


-(void)setupType2
{
    
    
    
    [_type2View setHidden:NO];
    [_type2View setFrame:CGRectMake(self.view.frame.size.width, _type2View.frame.origin.y, _type2View.frame.size.width, _type2View.frame.size.height)];
    [UIView animateWithDuration:.25 animations:^{
        _type2View.frame = CGRectMake(0, _type2View.frame.origin.y, _type2View.frame.size.width, _type2View.frame.size.height);
    }];

    
    /*set left view in all the textfield*/
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.txtType3.frame.size.height)];
    [rightView setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"cal.png"]];
    [rightView addSubview:imageloanAmmount];
    [self.txtType2 setRightViewMode:UITextFieldViewModeAlways];
    self.txtType2.rightView=rightView ;
    
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.txtType2.leftView=leftView;
    self.txtType2.leftViewMode=UITextFieldViewModeAlways;
    self.txtType2.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtType2.layer.borderWidth=1.0f;
    [_lbltype2Question setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    [_txtType2 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    
    
    [_pickerType2 setDatePickerMode:UIDatePickerModeDate];
    
    [_lbltype2Question setText:[dictCurrentQuestion objectForKey:@"Title"]];
}


-(void)setupType3
{
   
    [self GetAnswerListByTypeId:[dictCurrentQuestion objectForKey:@"TypeId"] andQuesID:[dictCurrentQuestion objectForKey:@"Id"]];
    
    
    
    [_type3View setHidden:NO];
    [_type3View setFrame:CGRectMake(self.view.frame.size.width, _type3View.frame.origin.y, _type3View.frame.size.width, _type3View.frame.size.height)];
    [UIView animateWithDuration:.25 animations:^{
        _type3View.frame = CGRectMake(0, _type3View.frame.origin.y, _type3View.frame.size.width, _type3View.frame.size.height);
    }];
    /*set left view in all the textfield*/
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.txtType3.frame.size.height)];
    [rightView setBackgroundColor:[UIColor whiteColor]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"Expand_Arrow.png"]];
    [rightView addSubview:imageloanAmmount];
    [self.txtType3 setRightViewMode:UITextFieldViewModeAlways];
    self.txtType3.rightView=rightView ;
    
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.txtType3.leftView=leftView;
    self.txtType3.leftViewMode=UITextFieldViewModeAlways;
    self.txtType3.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtType3.layer.borderWidth=1.0f;
    [_lbltype3Question setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    [_txtType3 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];

    dropDownType3=[[SAMenuDropDown alloc] initWithWithSource:_btnDropDownType3 menuHeight:150 itemNames:nil itemImagesName:nil itemSubtitles:nil];
    [dropDownType3 setDelegate:self];
    
    [_lbltype3Question setText:[dictCurrentQuestion objectForKey:@"Title"]];
}


-(void)setupType4
{
    
     [_type4View setHidden:NO];
    [_type4View setFrame:CGRectMake(self.view.frame.size.width, _type4View.frame.origin.y, _type4View.frame.size.width, _type3View.frame.size.height)];
    [UIView animateWithDuration:.25 animations:^{
        _type4View.frame = CGRectMake(0, _type4View.frame.origin.y, _type4View.frame.size.width, _type4View.frame.size.height);
    }];
    /*set up UI*/
    /*set left view in all the textfield*/
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(8, 2, 35, self.txtType4.frame.size.height)];
    [rightView setBackgroundColor:[UIColor colorWithRed:238.0f/255.0f green:238.0f/255.0f blue:238.0f/255.0f alpha:1]];
    UIImageView *imageloanAmmount=[[UIImageView alloc]initWithFrame:CGRectMake(7.5, 7.5, 20,20)];
    [imageloanAmmount setContentMode:(UIViewContentModeScaleAspectFit)];
    [imageloanAmmount setImage:[UIImage imageNamed:@"rupee.png"]];
    [rightView addSubview:imageloanAmmount];
    [self.txtType4 setRightViewMode:UITextFieldViewModeAlways];
    self.txtType4.rightView=rightView ;
    
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.txtType4.leftView=leftView;
    self.txtType4.leftViewMode=UITextFieldViewModeAlways;
    self.txtType4.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtType4.layer.borderWidth=1.0f;
    [_lbltype4Question setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
     [_txtType4 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    
    
    
    [_lbltype4Question setText:[dictCurrentQuestion objectForKey:@"Title"]];
}


-(void)setupType5
{
   
    [_type5View setHidden:NO];
    [_type5View setFrame:CGRectMake(self.view.frame.size.width, _type5View.frame.origin.y, _type5View.frame.size.width, _type5View.frame.size.height)];
    [UIView animateWithDuration:.25 animations:^{
        _type5View.frame = CGRectMake(0, _type5View.frame.origin.y, _type5View.frame.size.width, _type5View.frame.size.height);
    }];
    
    /*set up UI*/
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.txtType5.leftView=leftView;
    self.txtType5.leftViewMode=UITextFieldViewModeAlways;
    self.txtType5.layer.borderColor=[[UIColor grayColor] CGColor];
    self.txtType5.layer.borderWidth=1.0f;
    [_lbltype5Question setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    [_txtType5 setFont:[UIFont fontWithName:FONT_REGULAR size:19]];
    [_lbltype5Question setText:[dictCurrentQuestion objectForKey:@"Title"]];
    
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (!_type4View.isHidden) {
          [self.view endEditing:YES];
    }
}


- (void)GetAnswerListByTypeId:(NSString *)typeId andQuesID:(NSString *)quesId {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetAnswerListByTypeId>\n"
                             "<tem:strTypeId>%@</tem:strTypeId>\n"
                             "<tem:strQuestionId>%@</tem:strQuestionId>\n"
                             "</tem:GetAnswerListByTypeId>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",typeId,quesId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetAnswerListByTypeId_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetAnswerListByTypeIdResponse"] objectForKey:@"GetAnswerListByTypeIdResult"];
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            if ([typeId isEqualToString:@"3"]) {
                arrayType3=[[NSMutableArray alloc]init];
                for (int i = 0; i<values.count; i++) {
                    [arrayType3 addObject:values[i][0]];
                }

            }
            if ([typeId isEqualToString:@"1"]) {
                arrayType1=[[NSMutableArray alloc]init];
                for (int i = 0; i<values.count; i++) {
                    [arrayType1 addObject:values[i][0]];
                }
                [self setupType1RadioButton];
             }
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}

-(BOOL)isValidate
{
    switch ([[dictCurrentQuestion objectForKey:@"TypeId"] integerValue]) {
        case 1:
            
            break;
        case 2:{
            if ([_txtType2.text length]==0) {
                [[ApplicationManager sharedManagerInstance]showAlert:@"The field is required" andTitle:@"Oops!"];
                return NO;
            }
        }
            break;
        case 3:
        {
            if ([_txtType3.text length]==0) {
                [[ApplicationManager sharedManagerInstance]showAlert:@"The field is required" andTitle:@"Oops!"];
                return NO;
            }
        };
            break;
        case 4:
        {
            if ([_txtType4.text length]==0) {
                [[ApplicationManager sharedManagerInstance]showAlert:@"The field is required" andTitle:@"Oops!"];
                return NO;
            }
        };
            break;
        case 5:
        {
            if ([_txtType5.text length]==0) {
                [[ApplicationManager sharedManagerInstance]showAlert:@"The field is required" andTitle:@"Oops!"];
                return NO;
            }
        };
            break;
        default:
            break;
    }
    return YES;
}

@end
